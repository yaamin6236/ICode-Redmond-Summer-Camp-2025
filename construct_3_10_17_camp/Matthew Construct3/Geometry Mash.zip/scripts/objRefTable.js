const C3 = self.C3;
self.C3_GetObjectRefTable = function () {
	return [
		C3.Plugins.Sprite,
		C3.Behaviors.Platform,
		C3.Behaviors.scrollto,
		C3.Behaviors.solid,
		C3.Behaviors.MoveTo,
		C3.Plugins.Sprite.Cnds.OnCollision,
		C3.Plugins.Sprite.Acts.Destroy,
		C3.Plugins.Sprite.Cnds.OnDestroyed,
		C3.Plugins.System.Acts.RestartLayout,
		C3.Behaviors.Platform.Acts.SetDoubleJumpEnabled,
		C3.Plugins.System.Cnds.EveryTick,
		C3.Behaviors.MoveTo.Acts.MoveToObject,
		C3.Plugins.Sprite.Acts.InstanceSignal,
		C3.Plugins.Sprite.Cnds.OnInstanceSignal,
		C3.Plugins.System.Acts.GoToLayoutByName
	];
};
self.C3_JsPropNameTable = [
	{Platform: 0},
	{ScrollTo: 0},
	{JamesStickMan: 0},
	{Solid: 0},
	{platform: 0},
	{Tree: 0},
	{Sprite: 0},
	{bush: 0},
	{Sprite2: 0},
	{Sprite3: 0},
	{Sprite4: 0},
	{Sprite5: 0},
	{Sprite6: 0},
	{pad2: 0},
	{MoveTo: 0},
	{Boss: 0},
	{Sprite7: 0},
	{Sprite8: 0},
	{Sprite9: 0}
];

self.InstanceType = {
	JamesStickMan: class extends self.ISpriteInstance {},
	platform: class extends self.ISpriteInstance {},
	Tree: class extends self.ISpriteInstance {},
	Sprite: class extends self.ISpriteInstance {},
	bush: class extends self.ISpriteInstance {},
	Sprite2: class extends self.ISpriteInstance {},
	Sprite3: class extends self.ISpriteInstance {},
	Sprite4: class extends self.ISpriteInstance {},
	Sprite5: class extends self.ISpriteInstance {},
	Sprite6: class extends self.ISpriteInstance {},
	pad2: class extends self.ISpriteInstance {},
	Boss: class extends self.ISpriteInstance {},
	Sprite7: class extends self.ISpriteInstance {},
	Sprite8: class extends self.ISpriteInstance {},
	Sprite9: class extends self.ISpriteInstance {}
}