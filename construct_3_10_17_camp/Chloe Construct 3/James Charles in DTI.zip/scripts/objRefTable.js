const C3 = self.C3;
self.C3_GetObjectRefTable = function () {
	return [
		C3.Plugins.Sprite,
		C3.Behaviors.Platform,
		C3.Behaviors.scrollto,
		C3.Behaviors.solid,
		C3.Plugins.Text,
		C3.Behaviors.MoveTo,
		C3.Plugins.Sprite.Cnds.OnCollision,
		C3.Plugins.Sprite.Acts.Destroy,
		C3.Plugins.Sprite.Cnds.OnDestroyed,
		C3.Plugins.System.Acts.RestartLayout,
		C3.Plugins.System.Cnds.EveryTick,
		C3.Behaviors.MoveTo.Acts.MoveToObject
	];
};
self.C3_JsPropNameTable = [
	{Platform: 0},
	{ScrollTo: 0},
	{Solid: 0},
	{JamesCharles: 0},
	{dti: 0},
	{URMOMMA: 0},
	{BIGJUCIYBUSH: 0},
	{Sprite: 0},
	{LANASHOUSE: 0},
	{CAESOE: 0},
	{FIREEEEE: 0},
	{TEXT: 0},
	{LANATEXT: 0},
	{DEDCHILDREN: 0},
	{WIND: 0},
	{MoveTo: 0},
	{DOGR: 0},
	{CAT: 0}
];

self.InstanceType = {
	JamesCharles: class extends self.ISpriteInstance {},
	dti: class extends self.ISpriteInstance {},
	URMOMMA: class extends self.ISpriteInstance {},
	BIGJUCIYBUSH: class extends self.ISpriteInstance {},
	Sprite: class extends self.ISpriteInstance {},
	LANASHOUSE: class extends self.ISpriteInstance {},
	CAESOE: class extends self.ISpriteInstance {},
	FIREEEEE: class extends self.ISpriteInstance {},
	TEXT: class extends self.ISpriteInstance {},
	LANATEXT: class extends self.ITextInstance {},
	DEDCHILDREN: class extends self.ISpriteInstance {},
	WIND: class extends self.ISpriteInstance {},
	DOGR: class extends self.ISpriteInstance {},
	CAT: class extends self.ISpriteInstance {}
}