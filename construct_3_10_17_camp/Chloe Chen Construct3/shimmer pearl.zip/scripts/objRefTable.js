const C3 = self.C3;
self.C3_GetObjectRefTable = function () {
	return [
		C3.Plugins.Sprite,
		C3.Behaviors.Platform,
		C3.Behaviors.scrollto,
		C3.Behaviors.solid,
		C3.Plugins.Sprite.Cnds.OnCollision
	];
};
self.C3_JsPropNameTable = [
	{kiki: 0},
	{Platform: 0},
	{ScrollTo: 0},
	{Sprite: 0},
	{Solid: 0},
	{platform: 0},
	{hunter: 0}
];

self.InstanceType = {
	kiki: class extends self.ISpriteInstance {},
	Sprite: class extends self.ISpriteInstance {},
	platform: class extends self.ISpriteInstance {},
	hunter: class extends self.ISpriteInstance {}
}