const C3 = self.C3;
self.C3_GetObjectRefTable = function () {
	return [
		C3.Plugins.Sprite,
		C3.Behaviors.Platform,
		C3.Behaviors.jumpthru,
		C3.Plugins.Dictionary,
		C3.Behaviors.solid,
		C3.Behaviors.scrollto,
		C3.Behaviors.MoveTo,
		C3.Plugins.Sprite.Cnds.OnCollision,
		C3.Plugins.Sprite.Acts.Destroy,
		C3.Plugins.Sprite.Cnds.OnDestroyed,
		C3.Plugins.System.Acts.RestartLayout,
		C3.Plugins.System.Cnds.EveryTick,
		C3.Behaviors.MoveTo.Acts.MoveToObject
	];
};
self.C3_JsPropNameTable = [
	{sprite: 0},
	{Platform: 0},
	{Jumpthru: 0},
	{sprite4: 0},
	{poopi: 0},
	{Solid: 0},
	{sprite23: 0},
	{Sprite2: 0},
	{ScrollTo: 0},
	{Sprite3: 0},
	{sprite5: 0},
	{sprite90: 0},
	{sprite6: 0},
	{Sprite7: 0},
	{sprite8: 0},
	{sprite9: 0},
	{sprite09: 0},
	{MoveTo: 0},
	{sprite70: 0}
];

self.InstanceType = {
	sprite: class extends self.ISpriteInstance {},
	sprite4: class extends self.ISpriteInstance {},
	poopi: class extends self.IDictionaryInstance {},
	sprite23: class extends self.ISpriteInstance {},
	Sprite2: class extends self.ISpriteInstance {},
	Sprite3: class extends self.ISpriteInstance {},
	sprite5: class extends self.ISpriteInstance {},
	sprite90: class extends self.IDictionaryInstance {},
	sprite6: class extends self.ISpriteInstance {},
	Sprite7: class extends self.ISpriteInstance {},
	sprite8: class extends self.ISpriteInstance {},
	sprite9: class extends self.ISpriteInstance {},
	sprite09: class extends self.ISpriteInstance {},
	sprite70: class extends self.ISpriteInstance {}
}