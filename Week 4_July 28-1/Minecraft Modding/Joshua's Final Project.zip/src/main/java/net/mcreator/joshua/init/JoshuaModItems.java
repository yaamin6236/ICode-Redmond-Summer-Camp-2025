/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.joshua.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.joshua.item.WerItem;
import net.mcreator.joshua.item.UrururirorirtotItem;
import net.mcreator.joshua.item.TheItem;
import net.mcreator.joshua.item.ThItem;
import net.mcreator.joshua.item.SItem;
import net.mcreator.joshua.item.HhItem;
import net.mcreator.joshua.item.DumItem;
import net.mcreator.joshua.item.DItem;
import net.mcreator.joshua.JoshuaMod;

import java.util.function.Function;

public class JoshuaModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(JoshuaMod.MODID);
	public static final DeferredItem<Item> QUICKSAND = block(JoshuaModBlocks.QUICKSAND);
	public static final DeferredItem<Item> HI = block(JoshuaModBlocks.HI);
	public static final DeferredItem<Item> DIE = block(JoshuaModBlocks.DIE);
	public static final DeferredItem<Item> EEE = block(JoshuaModBlocks.EEE);
	public static final DeferredItem<Item> GR = block(JoshuaModBlocks.GR);
	public static final DeferredItem<Item> FHGH = block(JoshuaModBlocks.FHGH);
	public static final DeferredItem<Item> MMHMIUKMH = block(JoshuaModBlocks.MMHMIUKMH);
	public static final DeferredItem<Item> KRIJUHGFRIGHTIT = block(JoshuaModBlocks.KRIJUHGFRIGHTIT);
	public static final DeferredItem<Item> ONEDOLLARBLOCK = block(JoshuaModBlocks.ONEDOLLARBLOCK);
	public static final DeferredItem<Item> TENDOLRBLOK = block(JoshuaModBlocks.TENDOLRBLOK);
	public static final DeferredItem<Item> HUNGIDDOLRBLOK = block(JoshuaModBlocks.HUNGIDDOLRBLOK);
	public static final DeferredItem<Item> HH = register("hh", HhItem::new);
	public static final DeferredItem<Item> J = block(JoshuaModBlocks.J);
	public static final DeferredItem<Item> URURURIRORIRTOT = register("urururirorirtot", UrururirorirtotItem::new);
	public static final DeferredItem<Item> WER = register("wer", WerItem::new);
	public static final DeferredItem<Item> ETR = block(JoshuaModBlocks.ETR);
	public static final DeferredItem<Item> THE = register("the", TheItem::new);
	public static final DeferredItem<Item> TH = register("th", ThItem::new);
	public static final DeferredItem<Item> TEM = block(JoshuaModBlocks.TEM);
	public static final DeferredItem<Item> DUM = register("dum", DumItem::new);
	public static final DeferredItem<Item> D = register("d", DItem::new);
	public static final DeferredItem<Item> S = register("s", SItem::new);
	public static final DeferredItem<Item> DSSSS_SPAWN_EGG = register("dssss_spawn_egg", properties -> new SpawnEggItem(JoshuaModEntities.DSSSS.get(), properties));
	public static final DeferredItem<Item> JJ_SPAWN_EGG = register("jj_spawn_egg", properties -> new SpawnEggItem(JoshuaModEntities.JJ.get(), properties));

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}