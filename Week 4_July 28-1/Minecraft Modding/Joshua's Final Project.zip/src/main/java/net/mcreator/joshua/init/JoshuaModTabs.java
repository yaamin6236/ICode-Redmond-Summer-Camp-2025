/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.joshua.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.joshua.JoshuaMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class JoshuaModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, JoshuaMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(JoshuaModBlocks.QUICKSAND.get().asItem());
			tabData.accept(JoshuaModItems.URURURIRORIRTOT.get());
			tabData.accept(JoshuaModItems.WER.get());
			tabData.accept(JoshuaModBlocks.ETR.get().asItem());
			tabData.accept(JoshuaModBlocks.TEM.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(JoshuaModItems.HH.get());
			tabData.accept(JoshuaModItems.TH.get());
			tabData.accept(JoshuaModItems.DUM.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(JoshuaModItems.DUM.get());
			tabData.accept(JoshuaModItems.D.get());
			tabData.accept(JoshuaModItems.S.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(JoshuaModItems.DSSSS_SPAWN_EGG.get());
			tabData.accept(JoshuaModItems.JJ_SPAWN_EGG.get());
		}
	}
}