/*
*	MCreator note: This file will be REGENERATED on each build.
*/
package net.mcreator.joshua.init;

import net.neoforged.neoforge.event.village.VillagerTradesEvent;
import net.neoforged.neoforge.common.BasicItemListing;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.npc.VillagerProfession;

@EventBusSubscriber
public class JoshuaModTrades {
	@SubscribeEvent
	public static void registerTrades(VillagerTradesEvent event) {
		if (event.getType() == VillagerProfession.CLERIC) {
			event.getTrades().get(1).add(new BasicItemListing(new ItemStack(Blocks.SPRUCE_LEAVES), new ItemStack(Blocks.REPEATING_COMMAND_BLOCK, 99), 118, 5, 0f));
			event.getTrades().get(1).add(new BasicItemListing(new ItemStack(Blocks.SPRUCE_LEAVES), new ItemStack(Blocks.BARRIER, 99), 56, 5, 0f));
			event.getTrades().get(1).add(new BasicItemListing(new ItemStack(Blocks.SPRUCE_LEAVES), new ItemStack(Items.IRON_GOLEM_SPAWN_EGG, 99), 44, 5, 0f));
			event.getTrades().get(1).add(new BasicItemListing(new ItemStack(Blocks.SPRUCE_LEAVES), new ItemStack(Items.ENDER_DRAGON_SPAWN_EGG), 11, 5, 0.05f));
		}
	}
}