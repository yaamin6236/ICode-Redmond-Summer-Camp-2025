package net.mcreator.joshua.item;

import net.minecraft.world.item.Item;

public class WerItem extends Item {
	public WerItem(Item.Properties properties) {
		super(properties);
	}
}