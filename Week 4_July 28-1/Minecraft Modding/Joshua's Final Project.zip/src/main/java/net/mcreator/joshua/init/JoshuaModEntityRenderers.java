/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.joshua.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.joshua.client.renderer.JjRenderer;
import net.mcreator.joshua.client.renderer.DssssRenderer;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class JoshuaModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(JoshuaModEntities.DSSSS.get(), DssssRenderer::new);
		event.registerEntityRenderer(JoshuaModEntities.JJ.get(), JjRenderer::new);
	}
}