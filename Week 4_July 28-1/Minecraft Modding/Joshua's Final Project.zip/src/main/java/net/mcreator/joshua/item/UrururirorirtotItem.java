package net.mcreator.joshua.item;

import net.minecraft.world.item.Item;

public class UrururirorirtotItem extends Item {
	public UrururirorirtotItem(Item.Properties properties) {
		super(properties);
	}
}