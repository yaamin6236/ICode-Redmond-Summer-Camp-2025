/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.joshua.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.joshua.block.TendolrblokBlock;
import net.mcreator.joshua.block.TemBlock;
import net.mcreator.joshua.block.QuicksandBlock;
import net.mcreator.joshua.block.OnedollarblockBlock;
import net.mcreator.joshua.block.MmhmiukmhBlock;
import net.mcreator.joshua.block.KrijuhgfrightitBlock;
import net.mcreator.joshua.block.JBlock;
import net.mcreator.joshua.block.HungiddolrblokBlock;
import net.mcreator.joshua.block.HiBlock;
import net.mcreator.joshua.block.GrBlock;
import net.mcreator.joshua.block.FhghBlock;
import net.mcreator.joshua.block.EtrBlock;
import net.mcreator.joshua.block.EeeBlock;
import net.mcreator.joshua.block.DieBlock;
import net.mcreator.joshua.JoshuaMod;

import java.util.function.Function;

public class JoshuaModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(JoshuaMod.MODID);
	public static final DeferredBlock<Block> QUICKSAND = register("quicksand", QuicksandBlock::new);
	public static final DeferredBlock<Block> HI = register("hi", HiBlock::new);
	public static final DeferredBlock<Block> DIE = register("die", DieBlock::new);
	public static final DeferredBlock<Block> EEE = register("eee", EeeBlock::new);
	public static final DeferredBlock<Block> GR = register("gr", GrBlock::new);
	public static final DeferredBlock<Block> FHGH = register("fhgh", FhghBlock::new);
	public static final DeferredBlock<Block> MMHMIUKMH = register("mmhmiukmh", MmhmiukmhBlock::new);
	public static final DeferredBlock<Block> KRIJUHGFRIGHTIT = register("krijuhgfrightit", KrijuhgfrightitBlock::new);
	public static final DeferredBlock<Block> ONEDOLLARBLOCK = register("onedollarblock", OnedollarblockBlock::new);
	public static final DeferredBlock<Block> TENDOLRBLOK = register("tendolrblok", TendolrblokBlock::new);
	public static final DeferredBlock<Block> HUNGIDDOLRBLOK = register("hungiddolrblok", HungiddolrblokBlock::new);
	public static final DeferredBlock<Block> J = register("j", JBlock::new);
	public static final DeferredBlock<Block> ETR = register("etr", EtrBlock::new);
	public static final DeferredBlock<Block> TEM = register("tem", TemBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}