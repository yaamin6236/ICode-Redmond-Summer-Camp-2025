package net.mcreator.joshua.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

public class SItem extends PickaxeItem {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_WOODEN_TOOL, 999, 999f, 0, 999, TagKey.create(Registries.ITEM, ResourceLocation.parse("joshua:s_repair_items")));

	public SItem(Item.Properties properties) {
		super(TOOL_MATERIAL, 998f, -3f, properties);
	}
}