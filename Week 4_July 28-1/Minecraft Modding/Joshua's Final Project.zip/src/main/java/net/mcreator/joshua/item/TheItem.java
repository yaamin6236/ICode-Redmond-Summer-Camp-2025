package net.mcreator.joshua.item;

import net.minecraft.world.item.Item;

public class TheItem extends Item {
	public TheItem(Item.Properties properties) {
		super(properties);
	}
}