package net.mcreator.joshua.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

public class DItem extends PickaxeItem {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_NETHERITE_TOOL, 100, 999f, 0, 999, TagKey.create(Registries.ITEM, ResourceLocation.parse("joshua:d_repair_items")));

	public DItem(Item.Properties properties) {
		super(TOOL_MATERIAL, 998f, -3f, properties);
	}
}