/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.aayanshworkspace.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.aayanshworkspace.item.TenDollarBillItem;
import net.mcreator.aayanshworkspace.item.SteelSwordItem;
import net.mcreator.aayanshworkspace.item.SteelItem;
import net.mcreator.aayanshworkspace.item.OneHundredDollarBillItem;
import net.mcreator.aayanshworkspace.item.OneDollarBillItem;
import net.mcreator.aayanshworkspace.AayanshWorkspaceMod;

import java.util.function.Function;

public class AayanshWorkspaceModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(AayanshWorkspaceMod.MODID);
	public static final DeferredItem<Item> FIREBLOCK = block(AayanshWorkspaceModBlocks.FIREBLOCK);
	public static final DeferredItem<Item> EARTH_BLOCK = block(AayanshWorkspaceModBlocks.EARTH_BLOCK);
	public static final DeferredItem<Item> WATER_BLOCK = block(AayanshWorkspaceModBlocks.WATER_BLOCK);
	public static final DeferredItem<Item> ONEDOLLERBLOCK = block(AayanshWorkspaceModBlocks.ONEDOLLERBLOCK);
	public static final DeferredItem<Item> TENDOLLERBLOCK = block(AayanshWorkspaceModBlocks.TENDOLLERBLOCK);
	public static final DeferredItem<Item> HUNDREDDOLLERBLOCK = block(AayanshWorkspaceModBlocks.HUNDREDDOLLERBLOCK);
	public static final DeferredItem<Item> TNTBLOCK = block(AayanshWorkspaceModBlocks.TNTBLOCK);
	public static final DeferredItem<Item> ONE_HUNDRED_DOLLAR_BILL = register("one_hundred_dollar_bill", OneHundredDollarBillItem::new);
	public static final DeferredItem<Item> TEN_DOLLAR_BILL = register("ten_dollar_bill", TenDollarBillItem::new);
	public static final DeferredItem<Item> ONE_DOLLAR_BILL = register("one_dollar_bill", OneDollarBillItem::new);
	public static final DeferredItem<Item> STEEL = register("steel", SteelItem::new);
	public static final DeferredItem<Item> STEEL_SWORD = register("steel_sword", SteelSwordItem::new);
	public static final DeferredItem<Item> AT_MBLOCK = block(AayanshWorkspaceModBlocks.AT_MBLOCK);
	public static final DeferredItem<Item> ULTIMATE_PIG_SPAWN_EGG = register("ultimate_pig_spawn_egg", properties -> new SpawnEggItem(AayanshWorkspaceModEntities.ULTIMATE_PIG.get(), properties));

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}