/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.aayanshworkspace.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.aayanshworkspace.block.WaterBlockBlock;
import net.mcreator.aayanshworkspace.block.TntblockBlock;
import net.mcreator.aayanshworkspace.block.TendollerblockBlock;
import net.mcreator.aayanshworkspace.block.OnedollerblockBlock;
import net.mcreator.aayanshworkspace.block.HundreddollerblockBlock;
import net.mcreator.aayanshworkspace.block.FireblockBlock;
import net.mcreator.aayanshworkspace.block.EarthBlockBlock;
import net.mcreator.aayanshworkspace.block.ATMblockBlock;
import net.mcreator.aayanshworkspace.AayanshWorkspaceMod;

import java.util.function.Function;

public class AayanshWorkspaceModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(AayanshWorkspaceMod.MODID);
	public static final DeferredBlock<Block> FIREBLOCK = register("fireblock", FireblockBlock::new);
	public static final DeferredBlock<Block> EARTH_BLOCK = register("earth_block", EarthBlockBlock::new);
	public static final DeferredBlock<Block> WATER_BLOCK = register("water_block", WaterBlockBlock::new);
	public static final DeferredBlock<Block> ONEDOLLERBLOCK = register("onedollerblock", OnedollerblockBlock::new);
	public static final DeferredBlock<Block> TENDOLLERBLOCK = register("tendollerblock", TendollerblockBlock::new);
	public static final DeferredBlock<Block> HUNDREDDOLLERBLOCK = register("hundreddollerblock", HundreddollerblockBlock::new);
	public static final DeferredBlock<Block> TNTBLOCK = register("tntblock", TntblockBlock::new);
	public static final DeferredBlock<Block> AT_MBLOCK = register("at_mblock", ATMblockBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}