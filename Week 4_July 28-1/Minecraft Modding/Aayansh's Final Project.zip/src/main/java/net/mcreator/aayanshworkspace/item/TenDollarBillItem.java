package net.mcreator.aayanshworkspace.item;

import net.minecraft.world.item.Item;

public class TenDollarBillItem extends Item {
	public TenDollarBillItem(Item.Properties properties) {
		super(properties);
	}
}