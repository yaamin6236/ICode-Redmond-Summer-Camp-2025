package net.mcreator.aayanshworkspace.item;

import net.minecraft.world.item.Item;

public class OneHundredDollarBillItem extends Item {
	public OneHundredDollarBillItem(Item.Properties properties) {
		super(properties);
	}
}