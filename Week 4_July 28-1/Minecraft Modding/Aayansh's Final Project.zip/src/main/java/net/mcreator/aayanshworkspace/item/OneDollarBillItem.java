package net.mcreator.aayanshworkspace.item;

import net.minecraft.world.item.Item;

public class OneDollarBillItem extends Item {
	public OneDollarBillItem(Item.Properties properties) {
		super(properties);
	}
}