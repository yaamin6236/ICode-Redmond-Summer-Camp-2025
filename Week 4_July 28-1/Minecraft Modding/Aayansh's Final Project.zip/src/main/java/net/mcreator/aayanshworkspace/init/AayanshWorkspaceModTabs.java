/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.aayanshworkspace.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.aayanshworkspace.AayanshWorkspaceMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class AayanshWorkspaceModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, AayanshWorkspaceMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(AayanshWorkspaceModBlocks.FIREBLOCK.get().asItem());
			tabData.accept(AayanshWorkspaceModBlocks.EARTH_BLOCK.get().asItem());
			tabData.accept(AayanshWorkspaceModBlocks.WATER_BLOCK.get().asItem());
			tabData.accept(AayanshWorkspaceModBlocks.ONEDOLLERBLOCK.get().asItem());
			tabData.accept(AayanshWorkspaceModBlocks.TENDOLLERBLOCK.get().asItem());
			tabData.accept(AayanshWorkspaceModBlocks.HUNDREDDOLLERBLOCK.get().asItem());
			tabData.accept(AayanshWorkspaceModBlocks.TNTBLOCK.get().asItem());
			tabData.accept(AayanshWorkspaceModItems.ONE_HUNDRED_DOLLAR_BILL.get());
			tabData.accept(AayanshWorkspaceModItems.TEN_DOLLAR_BILL.get());
			tabData.accept(AayanshWorkspaceModItems.ONE_DOLLAR_BILL.get());
			tabData.accept(AayanshWorkspaceModBlocks.AT_MBLOCK.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(AayanshWorkspaceModItems.STEEL_SWORD.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(AayanshWorkspaceModItems.ULTIMATE_PIG_SPAWN_EGG.get());
		}
	}
}