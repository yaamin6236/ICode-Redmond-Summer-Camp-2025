package net.mcreator.aayanshworkspace.item;

import net.minecraft.world.item.Item;

public class SteelItem extends Item {
	public SteelItem(Item.Properties properties) {
		super(properties);
	}
}