package net.mcreator.asher.item;

import net.minecraft.world.item.Item;

public class HundreddollarbillItem extends Item {
	public HundreddollarbillItem(Item.Properties properties) {
		super(properties);
	}
}