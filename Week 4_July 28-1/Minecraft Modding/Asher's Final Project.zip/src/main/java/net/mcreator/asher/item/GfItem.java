package net.mcreator.asher.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class GfItem extends Item {
	public GfItem(Item.Properties properties) {
		super(properties.rarity(Rarity.UNCOMMON));
	}
}