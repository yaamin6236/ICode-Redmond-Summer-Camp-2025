/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.asher.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.asher.item.TrgItem;
import net.mcreator.asher.item.SaberItem;
import net.mcreator.asher.item.HundreddollarbillItem;
import net.mcreator.asher.item.GhItem;
import net.mcreator.asher.item.GfItem;
import net.mcreator.asher.item.FivehundreddollarbillItem;
import net.mcreator.asher.item.EItem;
import net.mcreator.asher.item.DfghjkItem;
import net.mcreator.asher.item.DffgItem;
import net.mcreator.asher.item.DfffItem;
import net.mcreator.asher.item.DffItem;
import net.mcreator.asher.AsherMod;

import java.util.function.Function;

public class AsherModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(AsherMod.MODID);
	public static final DeferredItem<Item> WATERBLOCK = block(AsherModBlocks.WATERBLOCK);
	public static final DeferredItem<Item> LAVABLOCK = block(AsherModBlocks.LAVABLOCK);
	public static final DeferredItem<Item> HUNDREDDOLLAR = block(AsherModBlocks.HUNDREDDOLLAR);
	public static final DeferredItem<Item> ONE_DOLLAR = block(AsherModBlocks.ONE_DOLLAR);
	public static final DeferredItem<Item> TENDOLLAR = block(AsherModBlocks.TENDOLLAR);
	public static final DeferredItem<Item> ELETRICITY = block(AsherModBlocks.ELETRICITY);
	public static final DeferredItem<Item> FRAME = block(AsherModBlocks.FRAME);
	public static final DeferredItem<Item> MINICITY = block(AsherModBlocks.MINICITY);
	public static final DeferredItem<Item> CITY = block(AsherModBlocks.CITY);
	public static final DeferredItem<Item> HUNDREDDOLLARBILL = register("hundreddollarbill", HundreddollarbillItem::new);
	public static final DeferredItem<Item> FIVEHUNDREDDOLLARBILL = register("fivehundreddollarbill", FivehundreddollarbillItem::new);
	public static final DeferredItem<Item> FAKETNT = block(AsherModBlocks.FAKETNT);
	public static final DeferredItem<Item> TRG = register("trg", TrgItem::new);
	public static final DeferredItem<Item> DFGHJK = register("dfghjk", DfghjkItem::new);
	public static final DeferredItem<Item> DFF = register("dff", DffItem::new);
	public static final DeferredItem<Item> DFFF = register("dfff", DfffItem::new);
	public static final DeferredItem<Item> E = register("e", EItem::new);
	public static final DeferredItem<Item> DFFG = register("dffg", DffgItem::new);
	public static final DeferredItem<Item> GF = register("gf", GfItem::new);
	public static final DeferredItem<Item> DFFFFFFFFF = block(AsherModBlocks.DFFFFFFFFF);
	public static final DeferredItem<Item> SABER = register("saber", SaberItem::new);
	public static final DeferredItem<Item> F_SPAWN_EGG = register("f_spawn_egg", properties -> new SpawnEggItem(AsherModEntities.F.get(), properties));
	public static final DeferredItem<Item> GH = register("gh", GhItem::new);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}