/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.asher.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.asher.AsherMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class AsherModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, AsherMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(AsherModBlocks.WATERBLOCK.get().asItem());
			tabData.accept(AsherModBlocks.LAVABLOCK.get().asItem());
			tabData.accept(AsherModBlocks.HUNDREDDOLLAR.get().asItem());
			tabData.accept(AsherModBlocks.ONE_DOLLAR.get().asItem());
			tabData.accept(AsherModBlocks.TENDOLLAR.get().asItem());
			tabData.accept(AsherModBlocks.ELETRICITY.get().asItem());
			tabData.accept(AsherModBlocks.FRAME.get().asItem());
			tabData.accept(AsherModBlocks.MINICITY.get().asItem());
			tabData.accept(AsherModBlocks.CITY.get().asItem());
			tabData.accept(AsherModItems.HUNDREDDOLLARBILL.get());
			tabData.accept(AsherModItems.FIVEHUNDREDDOLLARBILL.get());
			tabData.accept(AsherModBlocks.FAKETNT.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(AsherModItems.TRG.get());
			tabData.accept(AsherModItems.E.get());
			tabData.accept(AsherModItems.DFFG.get());
			tabData.accept(AsherModItems.SABER.get());
			tabData.accept(AsherModItems.GH.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(AsherModItems.DFGHJK.get());
			tabData.accept(AsherModItems.DFFF.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(AsherModItems.DFF.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
			tabData.accept(AsherModBlocks.DFFFFFFFFF.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(AsherModItems.F_SPAWN_EGG.get());
		}
	}
}