/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.asher.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.client.event.RegisterColorHandlersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.asher.block.WaterblockBlock;
import net.mcreator.asher.block.TendollarBlock;
import net.mcreator.asher.block.OneDollarBlock;
import net.mcreator.asher.block.MinicityBlock;
import net.mcreator.asher.block.LavablockBlock;
import net.mcreator.asher.block.HundreddollarBlock;
import net.mcreator.asher.block.FrameBlock;
import net.mcreator.asher.block.FaketntBlock;
import net.mcreator.asher.block.EletricityBlock;
import net.mcreator.asher.block.DfffffffffBlock;
import net.mcreator.asher.block.CityBlock;
import net.mcreator.asher.AsherMod;

import java.util.function.Function;

public class AsherModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(AsherMod.MODID);
	public static final DeferredBlock<Block> WATERBLOCK = register("waterblock", WaterblockBlock::new);
	public static final DeferredBlock<Block> LAVABLOCK = register("lavablock", LavablockBlock::new);
	public static final DeferredBlock<Block> HUNDREDDOLLAR = register("hundreddollar", HundreddollarBlock::new);
	public static final DeferredBlock<Block> ONE_DOLLAR = register("one_dollar", OneDollarBlock::new);
	public static final DeferredBlock<Block> TENDOLLAR = register("tendollar", TendollarBlock::new);
	public static final DeferredBlock<Block> ELETRICITY = register("eletricity", EletricityBlock::new);
	public static final DeferredBlock<Block> FRAME = register("frame", FrameBlock::new);
	public static final DeferredBlock<Block> MINICITY = register("minicity", MinicityBlock::new);
	public static final DeferredBlock<Block> CITY = register("city", CityBlock::new);
	public static final DeferredBlock<Block> FAKETNT = register("faketnt", FaketntBlock::new);
	public static final DeferredBlock<Block> DFFFFFFFFF = register("dfffffffff", DfffffffffBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}

	@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class BlocksClientSideHandler {
		@SubscribeEvent
		public static void blockColorLoad(RegisterColorHandlersEvent.Block event) {
			EletricityBlock.blockColorLoad(event);
			FrameBlock.blockColorLoad(event);
		}
	}
}