/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.skanda.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.skanda.block.TendollerBlock;
import net.mcreator.skanda.block.TROLLBlock;
import net.mcreator.skanda.block.SwedenBlock;
import net.mcreator.skanda.block.SvyBlock;
import net.mcreator.skanda.block.SfvBlock;
import net.mcreator.skanda.block.SetroamarecablokeBlock;
import net.mcreator.skanda.block.SetroBlock;
import net.mcreator.skanda.block.SVTBlock;
import net.mcreator.skanda.block.SVRBlock;
import net.mcreator.skanda.block.SVFBlock;
import net.mcreator.skanda.block.SERBlock;
import net.mcreator.skanda.block.QWERTYUIOPPBlock;
import net.mcreator.skanda.block.OnehundreddollarblockBlock;
import net.mcreator.skanda.block.OneDollarBlockBlock;
import net.mcreator.skanda.block.NEWYORKBlock;
import net.mcreator.skanda.block.MAINEBlock;
import net.mcreator.skanda.block.LaquintBlock;
import net.mcreator.skanda.block.ILLUNOIBlock;
import net.mcreator.skanda.block.HundreddolerblokeBlock;
import net.mcreator.skanda.block.CICAGOBlock;
import net.mcreator.skanda.SkandaMod;

import java.util.function.Function;

public class SkandaModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(SkandaMod.MODID);
	public static final DeferredBlock<Block> SETROAMARECABLOKE = register("setroamarecabloke", SetroamarecablokeBlock::new);
	public static final DeferredBlock<Block> ONEHUNDREDDOLLARBLOCK = register("onehundreddollarblock", OnehundreddollarblockBlock::new);
	public static final DeferredBlock<Block> SETRO = register("setro", SetroBlock::new);
	public static final DeferredBlock<Block> HUNDREDDOLERBLOKE = register("hundreddolerbloke", HundreddolerblokeBlock::new);
	public static final DeferredBlock<Block> SWEDEN = register("sweden", SwedenBlock::new);
	public static final DeferredBlock<Block> TENDOLLER = register("tendoller", TendollerBlock::new);
	public static final DeferredBlock<Block> ONE_DOLLAR_BLOCK = register("one_dollar_block", OneDollarBlockBlock::new);
	public static final DeferredBlock<Block> CICAGO = register("cicago", CICAGOBlock::new);
	public static final DeferredBlock<Block> SVR = register("svr", SVRBlock::new);
	public static final DeferredBlock<Block> TROLL = register("troll", TROLLBlock::new);
	public static final DeferredBlock<Block> ILLUNOI = register("illunoi", ILLUNOIBlock::new);
	public static final DeferredBlock<Block> NEWYORK = register("newyork", NEWYORKBlock::new);
	public static final DeferredBlock<Block> SVT = register("svt", SVTBlock::new);
	public static final DeferredBlock<Block> SVF = register("svf", SVFBlock::new);
	public static final DeferredBlock<Block> SER = register("ser", SERBlock::new);
	public static final DeferredBlock<Block> MAINE = register("maine", MAINEBlock::new);
	public static final DeferredBlock<Block> QWERTYUIOPP = register("qwertyuiopp", QWERTYUIOPPBlock::new);
	public static final DeferredBlock<Block> SFV = register("sfv", SfvBlock::new);
	public static final DeferredBlock<Block> SVY = register("svy", SvyBlock::new);
	public static final DeferredBlock<Block> ATM = register("atm", LaquintBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}