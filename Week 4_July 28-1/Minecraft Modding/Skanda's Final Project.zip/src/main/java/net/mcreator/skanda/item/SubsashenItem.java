package net.mcreator.skanda.item;

import net.minecraft.world.item.Item;

public class SubsashenItem extends Item {
	public SubsashenItem(Item.Properties properties) {
		super(properties);
	}
}