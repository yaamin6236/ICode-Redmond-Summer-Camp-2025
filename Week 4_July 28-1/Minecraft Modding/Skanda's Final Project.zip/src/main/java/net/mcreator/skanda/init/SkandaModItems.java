/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.skanda.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.skanda.item.VgbhItem;
import net.mcreator.skanda.item.SubsashenItem;
import net.mcreator.skanda.item.StashenItem;
import net.mcreator.skanda.SkandaMod;

import java.util.function.Function;

public class SkandaModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(SkandaMod.MODID);
	public static final DeferredItem<Item> SETROAMARECABLOKE = block(SkandaModBlocks.SETROAMARECABLOKE);
	public static final DeferredItem<Item> ONEHUNDREDDOLLARBLOCK = block(SkandaModBlocks.ONEHUNDREDDOLLARBLOCK);
	public static final DeferredItem<Item> SETRO = block(SkandaModBlocks.SETRO);
	public static final DeferredItem<Item> HUNDREDDOLERBLOKE = block(SkandaModBlocks.HUNDREDDOLERBLOKE);
	public static final DeferredItem<Item> SWEDEN = block(SkandaModBlocks.SWEDEN);
	public static final DeferredItem<Item> TENDOLLER = block(SkandaModBlocks.TENDOLLER);
	public static final DeferredItem<Item> ONE_DOLLAR_BLOCK = block(SkandaModBlocks.ONE_DOLLAR_BLOCK);
	public static final DeferredItem<Item> SUBSASHEN = register("subsashen", SubsashenItem::new);
	public static final DeferredItem<Item> STASHEN = register("stashen", StashenItem::new);
	public static final DeferredItem<Item> CICAGO = block(SkandaModBlocks.CICAGO);
	public static final DeferredItem<Item> SVR = block(SkandaModBlocks.SVR);
	public static final DeferredItem<Item> TROLL = block(SkandaModBlocks.TROLL);
	public static final DeferredItem<Item> ILLUNOI = block(SkandaModBlocks.ILLUNOI);
	public static final DeferredItem<Item> NEWYORK = block(SkandaModBlocks.NEWYORK);
	public static final DeferredItem<Item> SVT = block(SkandaModBlocks.SVT);
	public static final DeferredItem<Item> SVF = block(SkandaModBlocks.SVF);
	public static final DeferredItem<Item> SER = block(SkandaModBlocks.SER);
	public static final DeferredItem<Item> MAINE = block(SkandaModBlocks.MAINE);
	public static final DeferredItem<Item> QWERTYUIOPP = block(SkandaModBlocks.QWERTYUIOPP);
	public static final DeferredItem<Item> VGBH = register("vgbh", VgbhItem::new);
	public static final DeferredItem<Item> SFV = block(SkandaModBlocks.SFV);
	public static final DeferredItem<Item> SVY = block(SkandaModBlocks.SVY);
	public static final DeferredItem<Item> ATM = block(SkandaModBlocks.ATM);
	public static final DeferredItem<Item> LAQUINTA_SPAWN_EGG = register("laquinta_spawn_egg", properties -> new SpawnEggItem(SkandaModEntities.LAQUINTA.get(), properties));

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}