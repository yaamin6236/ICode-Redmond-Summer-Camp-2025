/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.skanda.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.skanda.SkandaMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class SkandaModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, SkandaMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(SkandaModBlocks.SETROAMARECABLOKE.get().asItem());
			tabData.accept(SkandaModBlocks.ONEHUNDREDDOLLARBLOCK.get().asItem());
			tabData.accept(SkandaModBlocks.SETRO.get().asItem());
			tabData.accept(SkandaModBlocks.HUNDREDDOLERBLOKE.get().asItem());
			tabData.accept(SkandaModBlocks.SWEDEN.get().asItem());
			tabData.accept(SkandaModBlocks.TENDOLLER.get().asItem());
			tabData.accept(SkandaModBlocks.ONE_DOLLAR_BLOCK.get().asItem());
			tabData.accept(SkandaModItems.SUBSASHEN.get());
			tabData.accept(SkandaModItems.STASHEN.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(SkandaModItems.VGBH.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(SkandaModItems.LAQUINTA_SPAWN_EGG.get());
		}
	}
}