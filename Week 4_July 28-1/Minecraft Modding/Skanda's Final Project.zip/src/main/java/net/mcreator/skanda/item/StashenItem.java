package net.mcreator.skanda.item;

import net.minecraft.world.item.Item;

public class StashenItem extends Item {
	public StashenItem(Item.Properties properties) {
		super(properties);
	}
}