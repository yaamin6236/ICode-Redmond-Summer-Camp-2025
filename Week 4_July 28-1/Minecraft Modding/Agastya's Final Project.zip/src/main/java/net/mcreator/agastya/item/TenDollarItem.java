package net.mcreator.agastya.item;

import net.minecraft.world.item.Item;

public class TenDollarItem extends Item {
	public TenDollarItem(Item.Properties properties) {
		super(properties);
	}
}