package net.mcreator.agastya.item;

import net.minecraft.world.item.Item;

public class OneDollarItem extends Item {
	public OneDollarItem(Item.Properties properties) {
		super(properties);
	}
}