/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.agastya.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.agastya.block.SdalofBlock;
import net.mcreator.agastya.block.PoloBlock;
import net.mcreator.agastya.block.PalofBlock;
import net.mcreator.agastya.block.IopoBlock;
import net.mcreator.agastya.block.IoloBlock;
import net.mcreator.agastya.block.HoloBlock;
import net.mcreator.agastya.block.GaberBlock;
import net.mcreator.agastya.block.BoloBlock;
import net.mcreator.agastya.block.ATMblockBlock;
import net.mcreator.agastya.AgastyaMod;

import java.util.function.Function;

public class AgastyaModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(AgastyaMod.MODID);
	public static final DeferredBlock<Block> SDALOF = register("sdalof", SdalofBlock::new);
	public static final DeferredBlock<Block> HOLO = register("holo", HoloBlock::new);
	public static final DeferredBlock<Block> GABER = register("gaber", GaberBlock::new);
	public static final DeferredBlock<Block> POLO = register("polo", PoloBlock::new);
	public static final DeferredBlock<Block> BOLO = register("bolo", BoloBlock::new);
	public static final DeferredBlock<Block> IOLO = register("iolo", IoloBlock::new);
	public static final DeferredBlock<Block> IOPO = register("iopo", IopoBlock::new);
	public static final DeferredBlock<Block> PALOF = register("palof", PalofBlock::new);
	public static final DeferredBlock<Block> AT_MBLOCK = register("at_mblock", ATMblockBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}