package net.mcreator.agastya.item;

import net.minecraft.world.item.Item;

public class HundredDollarItem extends Item {
	public HundredDollarItem(Item.Properties properties) {
		super(properties);
	}
}