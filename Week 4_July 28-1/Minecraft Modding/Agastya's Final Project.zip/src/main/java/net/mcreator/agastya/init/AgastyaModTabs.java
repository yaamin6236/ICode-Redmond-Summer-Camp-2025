/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.agastya.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.agastya.AgastyaMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class AgastyaModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, AgastyaMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(AgastyaModBlocks.SDALOF.get().asItem());
			tabData.accept(AgastyaModBlocks.HOLO.get().asItem());
			tabData.accept(AgastyaModBlocks.GABER.get().asItem());
			tabData.accept(AgastyaModBlocks.POLO.get().asItem());
			tabData.accept(AgastyaModBlocks.BOLO.get().asItem());
			tabData.accept(AgastyaModBlocks.IOLO.get().asItem());
			tabData.accept(AgastyaModBlocks.IOPO.get().asItem());
			tabData.accept(AgastyaModBlocks.PALOF.get().asItem());
			tabData.accept(AgastyaModBlocks.AT_MBLOCK.get().asItem());
		}
	}
}