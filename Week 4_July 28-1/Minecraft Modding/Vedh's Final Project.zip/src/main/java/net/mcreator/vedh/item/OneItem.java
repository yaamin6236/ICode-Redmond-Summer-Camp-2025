package net.mcreator.vedh.item;

import net.minecraft.world.item.Item;

public class OneItem extends Item {
	public OneItem(Item.Properties properties) {
		super(properties);
	}
}