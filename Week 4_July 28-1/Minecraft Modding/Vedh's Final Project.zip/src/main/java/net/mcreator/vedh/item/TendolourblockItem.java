package net.mcreator.vedh.item;

import net.minecraft.world.item.Item;

public class TendolourblockItem extends Item {
	public TendolourblockItem(Item.Properties properties) {
		super(properties);
	}
}