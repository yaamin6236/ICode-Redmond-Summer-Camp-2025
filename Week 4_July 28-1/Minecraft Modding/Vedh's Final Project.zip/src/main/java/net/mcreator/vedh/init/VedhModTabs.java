/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.vedh.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.vedh.VedhMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class VedhModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, VedhMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(VedhModBlocks.DIMMAND.get().asItem());
			tabData.accept(VedhModBlocks.COAL.get().asItem());
			tabData.accept(VedhModBlocks.ONEDOLLARBLOCK.get().asItem());
			tabData.accept(VedhModBlocks.TENDOLORBLOCK.get().asItem());
			tabData.accept(VedhModBlocks.ONEHUNDREDDOLORBLOCK.get().asItem());
			tabData.accept(VedhModBlocks.NETRITE.get().asItem());
			tabData.accept(VedhModBlocks.IRON.get().asItem());
			tabData.accept(VedhModBlocks.STEEL.get().asItem());
			tabData.accept(VedhModItems.NETRIT.get());
			tabData.accept(VedhModItems.ONE.get());
			tabData.accept(VedhModItems.TENDOLOURBLOCK.get());
			tabData.accept(VedhModItems.ONEHUNDREDDOLOURBLOCK.get());
			tabData.accept(VedhModBlocks.ATM.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(VedhModItems.TITANIUM_SWORD.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(VedhModItems.TITANIUM.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(VedhModItems.EEE_SPAWN_EGG.get());
		}
	}
}