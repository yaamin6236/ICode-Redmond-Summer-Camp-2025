/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.vedh.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.vedh.item.TitaniumSwordItem;
import net.mcreator.vedh.item.TitaniumItem;
import net.mcreator.vedh.item.TendolourblockItem;
import net.mcreator.vedh.item.OnehundreddolourblockItem;
import net.mcreator.vedh.item.OneItem;
import net.mcreator.vedh.item.NetritItem;
import net.mcreator.vedh.VedhMod;

import java.util.function.Function;

public class VedhModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(VedhMod.MODID);
	public static final DeferredItem<Item> DIMMAND = block(VedhModBlocks.DIMMAND);
	public static final DeferredItem<Item> COAL = block(VedhModBlocks.COAL);
	public static final DeferredItem<Item> ONEDOLLARBLOCK = block(VedhModBlocks.ONEDOLLARBLOCK);
	public static final DeferredItem<Item> TENDOLORBLOCK = block(VedhModBlocks.TENDOLORBLOCK);
	public static final DeferredItem<Item> ONEHUNDREDDOLORBLOCK = block(VedhModBlocks.ONEHUNDREDDOLORBLOCK);
	public static final DeferredItem<Item> NETRITE = block(VedhModBlocks.NETRITE);
	public static final DeferredItem<Item> IRON = block(VedhModBlocks.IRON);
	public static final DeferredItem<Item> STEEL = block(VedhModBlocks.STEEL);
	public static final DeferredItem<Item> NETRIT = register("netrit", NetritItem::new);
	public static final DeferredItem<Item> ONE = register("one", OneItem::new);
	public static final DeferredItem<Item> TENDOLOURBLOCK = register("tendolourblock", TendolourblockItem::new);
	public static final DeferredItem<Item> ONEHUNDREDDOLOURBLOCK = register("onehundreddolourblock", OnehundreddolourblockItem::new);
	public static final DeferredItem<Item> ATM = block(VedhModBlocks.ATM);
	public static final DeferredItem<Item> TITANIUM_SWORD = register("titanium_sword", TitaniumSwordItem::new);
	public static final DeferredItem<Item> TITANIUM = register("titanium", TitaniumItem::new);
	public static final DeferredItem<Item> EEE_SPAWN_EGG = register("eee_spawn_egg", properties -> new SpawnEggItem(VedhModEntities.EEE.get(), properties));

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}