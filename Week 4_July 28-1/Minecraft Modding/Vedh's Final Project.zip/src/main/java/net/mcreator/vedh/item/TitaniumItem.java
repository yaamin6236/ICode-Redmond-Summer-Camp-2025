package net.mcreator.vedh.item;

import net.minecraft.world.item.Item;

public class TitaniumItem extends Item {
	public TitaniumItem(Item.Properties properties) {
		super(properties);
	}
}