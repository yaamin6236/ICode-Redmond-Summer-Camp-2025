package net.mcreator.vedh.item;

import net.minecraft.world.item.Item;

public class NetritItem extends Item {
	public NetritItem(Item.Properties properties) {
		super(properties);
	}
}