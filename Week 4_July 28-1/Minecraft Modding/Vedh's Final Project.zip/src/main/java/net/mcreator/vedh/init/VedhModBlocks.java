/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.vedh.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.vedh.block.TENDOLORBLOCKBlock;
import net.mcreator.vedh.block.SteelBlock;
import net.mcreator.vedh.block.ONEHUNDREDDOLORBLOCKBlock;
import net.mcreator.vedh.block.ONEDOLLARBLOCKBlock;
import net.mcreator.vedh.block.NetriteBlock;
import net.mcreator.vedh.block.IornBlock;
import net.mcreator.vedh.block.DIMMANDBlock;
import net.mcreator.vedh.block.COALBlock;
import net.mcreator.vedh.block.ATMBlock;
import net.mcreator.vedh.VedhMod;

import java.util.function.Function;

public class VedhModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(VedhMod.MODID);
	public static final DeferredBlock<Block> DIMMAND = register("dimmand", DIMMANDBlock::new);
	public static final DeferredBlock<Block> COAL = register("coal", COALBlock::new);
	public static final DeferredBlock<Block> ONEDOLLARBLOCK = register("onedollarblock", ONEDOLLARBLOCKBlock::new);
	public static final DeferredBlock<Block> TENDOLORBLOCK = register("tendolorblock", TENDOLORBLOCKBlock::new);
	public static final DeferredBlock<Block> ONEHUNDREDDOLORBLOCK = register("onehundreddolorblock", ONEHUNDREDDOLORBLOCKBlock::new);
	public static final DeferredBlock<Block> NETRITE = register("netrite", NetriteBlock::new);
	public static final DeferredBlock<Block> IRON = register("iron", IornBlock::new);
	public static final DeferredBlock<Block> STEEL = register("steel", SteelBlock::new);
	public static final DeferredBlock<Block> ATM = register("atm", ATMBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}