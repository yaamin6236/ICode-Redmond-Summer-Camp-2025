package net.mcreator.vedh.item;

import net.minecraft.world.item.Item;

public class OnehundreddolourblockItem extends Item {
	public OnehundreddolourblockItem(Item.Properties properties) {
		super(properties);
	}
}