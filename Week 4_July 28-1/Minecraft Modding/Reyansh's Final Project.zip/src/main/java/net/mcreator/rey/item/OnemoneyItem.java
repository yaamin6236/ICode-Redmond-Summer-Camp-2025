package net.mcreator.rey.item;

import net.minecraft.world.item.Item;

public class OnemoneyItem extends Item {
	public OnemoneyItem(Item.Properties properties) {
		super(properties);
	}
}