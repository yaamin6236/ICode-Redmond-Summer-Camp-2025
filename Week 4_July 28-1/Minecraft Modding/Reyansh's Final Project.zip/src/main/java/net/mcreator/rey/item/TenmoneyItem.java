package net.mcreator.rey.item;

import net.minecraft.world.item.Item;

public class TenmoneyItem extends Item {
	public TenmoneyItem(Item.Properties properties) {
		super(properties);
	}
}