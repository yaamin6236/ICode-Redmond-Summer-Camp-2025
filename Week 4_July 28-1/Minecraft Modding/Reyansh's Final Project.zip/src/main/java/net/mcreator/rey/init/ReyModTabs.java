/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.rey.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.rey.ReyMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class ReyModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ReyMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(ReyModBlocks.EMBER.get().asItem());
			tabData.accept(ReyModBlocks.DOOMSTONE.get().asItem());
			tabData.accept(ReyModBlocks.AQUABLOCK.get().asItem());
			tabData.accept(ReyModBlocks.COSMO.get().asItem());
			tabData.accept(ReyModBlocks.MAGICBLOCK.get().asItem());
			tabData.accept(ReyModBlocks.FIRESTRIKE.get().asItem());
			tabData.accept(ReyModBlocks.SUPERSTEEL.get().asItem());
			tabData.accept(ReyModBlocks.DIAMONDGLASS.get().asItem());
			tabData.accept(ReyModItems.ONEMONEY.get());
			tabData.accept(ReyModItems.TENMONEY.get());
			tabData.accept(ReyModItems.HUNDREDMONEY.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
			tabData.accept(ReyModBlocks.ATMBLOCK.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(ReyModItems.STEELINGOT.get());
			tabData.accept(ReyModItems.STEELPICKAXE.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(ReyModItems.SEAHAWKSPIG_SPAWN_EGG.get());
		}
	}
}