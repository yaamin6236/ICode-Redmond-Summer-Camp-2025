/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.rey.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.rey.item.TenmoneyItem;
import net.mcreator.rey.item.SteelpickaxeItem;
import net.mcreator.rey.item.SteelingotItem;
import net.mcreator.rey.item.OnemoneyItem;
import net.mcreator.rey.item.HundredmoneyItem;
import net.mcreator.rey.ReyMod;

import java.util.function.Function;

public class ReyModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(ReyMod.MODID);
	public static final DeferredItem<Item> EMBER = block(ReyModBlocks.EMBER);
	public static final DeferredItem<Item> DOOMSTONE = block(ReyModBlocks.DOOMSTONE);
	public static final DeferredItem<Item> AQUABLOCK = block(ReyModBlocks.AQUABLOCK);
	public static final DeferredItem<Item> COSMO = block(ReyModBlocks.COSMO);
	public static final DeferredItem<Item> ONE_DOLLAR_BLOCK = block(ReyModBlocks.ONE_DOLLAR_BLOCK);
	public static final DeferredItem<Item> TEN_DOLLAR_BLOCK = block(ReyModBlocks.TEN_DOLLAR_BLOCK);
	public static final DeferredItem<Item> HUNDREDDOLLARBLOCK = block(ReyModBlocks.HUNDREDDOLLARBLOCK);
	public static final DeferredItem<Item> MAGICBLOCK = block(ReyModBlocks.MAGICBLOCK);
	public static final DeferredItem<Item> FIRESTRIKE = block(ReyModBlocks.FIRESTRIKE);
	public static final DeferredItem<Item> SUPERSTEEL = block(ReyModBlocks.SUPERSTEEL);
	public static final DeferredItem<Item> DIAMONDGLASS = block(ReyModBlocks.DIAMONDGLASS);
	public static final DeferredItem<Item> ONEMONEY = register("onemoney", OnemoneyItem::new);
	public static final DeferredItem<Item> TENMONEY = register("tenmoney", TenmoneyItem::new);
	public static final DeferredItem<Item> HUNDREDMONEY = register("hundredmoney", HundredmoneyItem::new);
	public static final DeferredItem<Item> ATMBLOCK = block(ReyModBlocks.ATMBLOCK);
	public static final DeferredItem<Item> STEELINGOT = register("steelingot", SteelingotItem::new);
	public static final DeferredItem<Item> STEELPICKAXE = register("steelpickaxe", SteelpickaxeItem::new);
	public static final DeferredItem<Item> SEAHAWKSPIG_SPAWN_EGG = register("seahawkspig_spawn_egg", properties -> new SpawnEggItem(ReyModEntities.SEAHAWKSPIG.get(), properties));

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}