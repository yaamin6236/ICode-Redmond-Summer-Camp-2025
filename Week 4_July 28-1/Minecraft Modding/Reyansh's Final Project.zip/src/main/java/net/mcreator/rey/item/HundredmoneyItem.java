package net.mcreator.rey.item;

import net.minecraft.world.item.Item;

public class HundredmoneyItem extends Item {
	public HundredmoneyItem(Item.Properties properties) {
		super(properties);
	}
}