/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.rey.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.rey.block.TenDollarBlockBlock;
import net.mcreator.rey.block.SupersteelBlock;
import net.mcreator.rey.block.OneDollarBlockBlock;
import net.mcreator.rey.block.MagicblockBlock;
import net.mcreator.rey.block.HundreddollarblockBlock;
import net.mcreator.rey.block.FirestrikeBlock;
import net.mcreator.rey.block.EmberBlock;
import net.mcreator.rey.block.DoomstoneBlock;
import net.mcreator.rey.block.DiamondglassBlock;
import net.mcreator.rey.block.CosmoBlock;
import net.mcreator.rey.block.AtmblockBlock;
import net.mcreator.rey.block.AquablockBlock;
import net.mcreator.rey.ReyMod;

import java.util.function.Function;

public class ReyModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(ReyMod.MODID);
	public static final DeferredBlock<Block> EMBER = register("ember", EmberBlock::new);
	public static final DeferredBlock<Block> DOOMSTONE = register("doomstone", DoomstoneBlock::new);
	public static final DeferredBlock<Block> AQUABLOCK = register("aquablock", AquablockBlock::new);
	public static final DeferredBlock<Block> COSMO = register("cosmo", CosmoBlock::new);
	public static final DeferredBlock<Block> ONE_DOLLAR_BLOCK = register("one_dollar_block", OneDollarBlockBlock::new);
	public static final DeferredBlock<Block> TEN_DOLLAR_BLOCK = register("ten_dollar_block", TenDollarBlockBlock::new);
	public static final DeferredBlock<Block> HUNDREDDOLLARBLOCK = register("hundreddollarblock", HundreddollarblockBlock::new);
	public static final DeferredBlock<Block> MAGICBLOCK = register("magicblock", MagicblockBlock::new);
	public static final DeferredBlock<Block> FIRESTRIKE = register("firestrike", FirestrikeBlock::new);
	public static final DeferredBlock<Block> SUPERSTEEL = register("supersteel", SupersteelBlock::new);
	public static final DeferredBlock<Block> DIAMONDGLASS = register("diamondglass", DiamondglassBlock::new);
	public static final DeferredBlock<Block> ATMBLOCK = register("atmblock", AtmblockBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}