package net.mcreator.ryan.item;

import net.minecraft.world.item.Item;

public class LItem extends Item {
	public LItem(Item.Properties properties) {
		super(properties);
	}
}