/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.ryan.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.ryan.RyanMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class RyanModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, RyanMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(RyanModItems.ONEDOLLAR.get());
			tabData.accept(RyanModItems.TENDOLLAR.get());
			tabData.accept(RyanModItems.HUNDREDDOLLAR.get());
			tabData.accept(RyanModBlocks.ENDER_BLOCK.get().asItem());
			tabData.accept(RyanModBlocks.HIGURBLOCK.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(RyanModItems.TNTSORD.get());
			tabData.accept(RyanModItems.TNTSWORD.get());
			tabData.accept(RyanModItems.POISION_SWORD.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
			tabData.accept(RyanModBlocks.ATM.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(RyanModItems.TYU_SPAWN_EGG.get());
		}
	}
}