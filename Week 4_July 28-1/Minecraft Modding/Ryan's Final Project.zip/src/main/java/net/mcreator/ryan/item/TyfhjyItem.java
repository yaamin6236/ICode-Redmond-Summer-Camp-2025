package net.mcreator.ryan.item;

import net.minecraft.world.item.Item;

public class TyfhjyItem extends Item {
	public TyfhjyItem(Item.Properties properties) {
		super(properties);
	}
}