/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.ryan.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.ryan.block.UgiioBlock;
import net.mcreator.ryan.block.HudeeBlock;
import net.mcreator.ryan.block.HigurblockBlock;
import net.mcreator.ryan.block.EnderBlockBlock;
import net.mcreator.ryan.block.DfghjklBlock;
import net.mcreator.ryan.block.ATMBlock;
import net.mcreator.ryan.RyanMod;

import java.util.function.Function;

public class RyanModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(RyanMod.MODID);
	public static final DeferredBlock<Block> ENDER_BLOCK = register("ender_block", EnderBlockBlock::new);
	public static final DeferredBlock<Block> HIGURBLOCK = register("higurblock", HigurblockBlock::new);
	public static final DeferredBlock<Block> ATM = register("atm", ATMBlock::new);
	public static final DeferredBlock<Block> HUDEE = register("hudee", HudeeBlock::new);
	public static final DeferredBlock<Block> UGIIO = register("ugiio", UgiioBlock::new);
	public static final DeferredBlock<Block> DFGHJKL = register("dfghjkl", DfghjklBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}