/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.ryan.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.ryan.item.TyfhjyItem;
import net.mcreator.ryan.item.TntsordItem;
import net.mcreator.ryan.item.TendollarItem;
import net.mcreator.ryan.item.TNTSWORDItem;
import net.mcreator.ryan.item.PoisionSwordItem;
import net.mcreator.ryan.item.OnedollarItem;
import net.mcreator.ryan.item.LItem;
import net.mcreator.ryan.item.IDontReallyKnowItem;
import net.mcreator.ryan.item.HundreddollarItem;
import net.mcreator.ryan.RyanMod;

import java.util.function.Function;

public class RyanModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(RyanMod.MODID);
	public static final DeferredItem<Item> ONEDOLLAR = register("onedollar", OnedollarItem::new);
	public static final DeferredItem<Item> TENDOLLAR = register("tendollar", TendollarItem::new);
	public static final DeferredItem<Item> HUNDREDDOLLAR = register("hundreddollar", HundreddollarItem::new);
	public static final DeferredItem<Item> ENDER_BLOCK = block(RyanModBlocks.ENDER_BLOCK);
	public static final DeferredItem<Item> HIGURBLOCK = block(RyanModBlocks.HIGURBLOCK);
	public static final DeferredItem<Item> TNTSORD = register("tntsord", TntsordItem::new);
	public static final DeferredItem<Item> TNTSWORD = register("tntsword", TNTSWORDItem::new);
	public static final DeferredItem<Item> POISION_SWORD = register("poision_sword", PoisionSwordItem::new);
	public static final DeferredItem<Item> ATM = block(RyanModBlocks.ATM);
	public static final DeferredItem<Item> TYU_SPAWN_EGG = register("tyu_spawn_egg", properties -> new SpawnEggItem(RyanModEntities.TYU.get(), properties));
	public static final DeferredItem<Item> I_DONT_REALLY_KNOW = register("i_dont_really_know", IDontReallyKnowItem::new);
	public static final DeferredItem<Item> TYFHJY = register("tyfhjy", TyfhjyItem::new);
	public static final DeferredItem<Item> L = register("l", LItem::new);
	public static final DeferredItem<Item> HUDEE = block(RyanModBlocks.HUDEE);
	public static final DeferredItem<Item> UGIIO = block(RyanModBlocks.UGIIO);
	public static final DeferredItem<Item> DFGHJKL = block(RyanModBlocks.DFGHJKL);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}