package net.mcreator.ryan.item;

import net.minecraft.world.item.Item;

public class TNTSWORDItem extends Item {
	public TNTSWORDItem(Item.Properties properties) {
		super(properties);
	}
}