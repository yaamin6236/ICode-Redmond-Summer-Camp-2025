
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.nicolas.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.core.registries.BuiltInRegistries;

import net.mcreator.nicolas.block.TenDollarBlockBlock;
import net.mcreator.nicolas.block.SteelBlock;
import net.mcreator.nicolas.block.SafeBlock;
import net.mcreator.nicolas.block.OdbBlock;
import net.mcreator.nicolas.block.HdbBlock;
import net.mcreator.nicolas.block.AtmBlock;
import net.mcreator.nicolas.block.AirBlock;
import net.mcreator.nicolas.NicolasMod;

public class NicolasModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(BuiltInRegistries.BLOCK, NicolasMod.MODID);
	public static final DeferredHolder<Block, Block> SAFE = REGISTRY.register("safe", () -> new SafeBlock());
	public static final DeferredHolder<Block, Block> ODB = REGISTRY.register("odb", () -> new OdbBlock());
	public static final DeferredHolder<Block, Block> TEN_DOLLAR_BLOCK = REGISTRY.register("ten_dollar_block", () -> new TenDollarBlockBlock());
	public static final DeferredHolder<Block, Block> HDB = REGISTRY.register("hdb", () -> new HdbBlock());
	public static final DeferredHolder<Block, Block> AIR = REGISTRY.register("air", () -> new AirBlock());
	public static final DeferredHolder<Block, Block> STEEL = REGISTRY.register("steel", () -> new SteelBlock());
	public static final DeferredHolder<Block, Block> ATM = REGISTRY.register("atm", () -> new AtmBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
