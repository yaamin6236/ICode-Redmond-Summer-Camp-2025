
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.nicolas.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.bus.api.IEventBus;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraft.core.registries.BuiltInRegistries;

import net.mcreator.nicolas.item.UraniumSwordItem;
import net.mcreator.nicolas.item.UraniumItem;
import net.mcreator.nicolas.item.TdItem;
import net.mcreator.nicolas.item.ODItem;
import net.mcreator.nicolas.item.HdItem;
import net.mcreator.nicolas.NicolasMod;

public class NicolasModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(BuiltInRegistries.ITEM, NicolasMod.MODID);
	public static final DeferredHolder<Item, Item> SAFE = block(NicolasModBlocks.SAFE);
	public static final DeferredHolder<Item, Item> ODB = block(NicolasModBlocks.ODB);
	public static final DeferredHolder<Item, Item> TEN_DOLLAR_BLOCK = block(NicolasModBlocks.TEN_DOLLAR_BLOCK);
	public static final DeferredHolder<Item, Item> HDB = block(NicolasModBlocks.HDB);
	public static final DeferredHolder<Item, Item> AIR = block(NicolasModBlocks.AIR);
	public static final DeferredHolder<Item, Item> STEEL = block(NicolasModBlocks.STEEL);
	public static final DeferredHolder<Item, Item> OD = REGISTRY.register("od", () -> new ODItem());
	public static final DeferredHolder<Item, Item> TD = REGISTRY.register("td", () -> new TdItem());
	public static final DeferredHolder<Item, Item> HD = REGISTRY.register("hd", () -> new HdItem());
	public static final DeferredHolder<Item, Item> URANIUM = REGISTRY.register("uranium", () -> new UraniumItem());
	public static final DeferredHolder<Item, Item> URANIUM_SWORD = REGISTRY.register("uranium_sword", () -> new UraniumSwordItem());
	public static final DeferredHolder<Item, Item> ATM = block(NicolasModBlocks.ATM);
	public static final DeferredHolder<Item, Item> WARDENPIG_SPAWN_EGG = REGISTRY.register("wardenpig_spawn_egg", () -> new DeferredSpawnEggItem(NicolasModEntities.WARDENPIG, -1, -1, new Item.Properties()));

	// Start of user code block custom items
	// End of user code block custom items
	public static void register(IEventBus bus) {
		REGISTRY.register(bus);
	}

	private static DeferredHolder<Item, Item> block(DeferredHolder<Block, Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
