
package net.mcreator.nicolas.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class ODItem extends Item {
	public ODItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
