
package net.mcreator.nicolas.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class TdItem extends Item {
	public TdItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
