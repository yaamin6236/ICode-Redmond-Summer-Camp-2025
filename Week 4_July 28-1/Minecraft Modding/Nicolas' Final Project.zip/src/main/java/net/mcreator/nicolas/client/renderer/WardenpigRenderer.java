
package net.mcreator.nicolas.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.PigModel;

import net.mcreator.nicolas.entity.WardenpigEntity;

public class WardenpigRenderer extends MobRenderer<WardenpigEntity, PigModel<WardenpigEntity>> {
	public WardenpigRenderer(EntityRendererProvider.Context context) {
		super(context, new PigModel(context.bakeLayer(ModelLayers.PIG)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(WardenpigEntity entity) {
		return new ResourceLocation("nicolas:textures/entities/warden.png");
	}
}
