
package net.mcreator.ishaan.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class HundreddollarItem extends Item {
	public HundreddollarItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
