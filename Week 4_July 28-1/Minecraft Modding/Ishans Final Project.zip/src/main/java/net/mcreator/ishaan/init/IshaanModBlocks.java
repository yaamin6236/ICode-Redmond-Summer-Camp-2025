
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.ishaan.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.client.event.RegisterColorHandlersEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;
import net.minecraft.core.registries.BuiltInRegistries;

import net.mcreator.ishaan.block.TENDOLLERBLOCKBlock;
import net.mcreator.ishaan.block.ONEDOLLARBLOCKBlock;
import net.mcreator.ishaan.block.FASTBlock;
import net.mcreator.ishaan.block.COTVERBlock;
import net.mcreator.ishaan.IshaanMod;

public class IshaanModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(BuiltInRegistries.BLOCK, IshaanMod.MODID);
	public static final DeferredHolder<Block, Block> COTVER = REGISTRY.register("cotver", () -> new COTVERBlock());
	public static final DeferredHolder<Block, Block> FAST = REGISTRY.register("fast", () -> new FASTBlock());
	public static final DeferredHolder<Block, Block> ONEDOLLARBLOCK = REGISTRY.register("onedollarblock", () -> new ONEDOLLARBLOCKBlock());
	public static final DeferredHolder<Block, Block> TENDOLLERBLOCK = REGISTRY.register("tendollerblock", () -> new TENDOLLERBLOCKBlock());

	// Start of user code block custom blocks
	// End of user code block custom blocks
	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ClientSideHandler {
		@SubscribeEvent
		public static void blockColorLoad(RegisterColorHandlersEvent.Block event) {
			COTVERBlock.blockColorLoad(event);
		}
	}
}
