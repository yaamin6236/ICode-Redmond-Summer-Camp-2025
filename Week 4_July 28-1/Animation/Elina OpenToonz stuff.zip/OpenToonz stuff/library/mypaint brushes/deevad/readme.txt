 __//|
/oo |
\mm\_ . . . . . . . D E E V A D brushkit V6 . . . . . . . . . . . . . . . . . . . . . .
 
This is Deevad's brushset version 6 done for Mypaint version 1.1.0
This brush kit is released in public domain, so feel free to create
what you want with it.

If you accept this license, a new brush group named 'deevad-v6' will 
be created. More infos on the brushes on my blog, or my deviant-art 
account , under the resources category.

Released in end october 2012


###########################################
### WARNING ! INCOMPATIBLE WITH MYPAINT 1.0.0 AND BEFORE ###
###########################################

Creative Commons Zero
Public Domain

Website and blog : http://www.davidrevoy.com
deviantART : http://deevad.deviantart.com/