/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.icodemod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.icodemod.IcodeModMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class IcodeModModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, IcodeModMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(IcodeModModItems.DOLLARBILL.get());
			tabData.accept(IcodeModModItems.HUNDREDDOLLAR.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.FOOD_AND_DRINKS) {
			tabData.accept(IcodeModModItems.DOLLARBILL.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(IcodeModModBlocks.ROADBLOCK.get().asItem());
			tabData.accept(IcodeModModBlocks.LEVATATEBLOCK.get().asItem());
			tabData.accept(IcodeModModBlocks.AT_MBLOCK.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(IcodeModModItems.PICKAXE.get());
			tabData.accept(IcodeModModItems.OPSWORD.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(IcodeModModItems.MYMOB_SPAWN_EGG.get());
			tabData.accept(IcodeModModItems.DOGGY_SPAWN_EGG.get());
		}
	}
}