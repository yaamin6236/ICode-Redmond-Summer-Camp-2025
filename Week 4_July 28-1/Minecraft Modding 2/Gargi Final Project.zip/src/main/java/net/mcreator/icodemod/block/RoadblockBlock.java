package net.mcreator.icodemod.block;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;

public class RoadblockBlock extends Block {
	public RoadblockBlock(BlockBehaviour.Properties properties) {
		super(properties.sound(SoundType.GRAVEL).strength(1.5f, 6f).speedFactor(1.3f));
	}

	@Override
	public int getLightBlock(BlockState state) {
		return 15;
	}
}