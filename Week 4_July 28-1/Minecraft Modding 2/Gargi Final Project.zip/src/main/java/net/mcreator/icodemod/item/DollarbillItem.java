package net.mcreator.icodemod.item;

import net.minecraft.world.item.Item;

public class DollarbillItem extends Item {
	public DollarbillItem(Item.Properties properties) {
		super(properties);
	}
}