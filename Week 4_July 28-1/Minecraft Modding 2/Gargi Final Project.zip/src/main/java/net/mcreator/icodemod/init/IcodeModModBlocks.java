/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.icodemod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.icodemod.block.RoadblockBlock;
import net.mcreator.icodemod.block.LEVATATEBlock;
import net.mcreator.icodemod.block.LEVATATEBLOCKBlock;
import net.mcreator.icodemod.block.CastleBlock;
import net.mcreator.icodemod.block.ATMblockBlock;
import net.mcreator.icodemod.IcodeModMod;

import java.util.function.Function;

public class IcodeModModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(IcodeModMod.MODID);
	public static final DeferredBlock<Block> ROADBLOCK = register("roadblock", RoadblockBlock::new);
	public static final DeferredBlock<Block> LEVATATE = register("levatate", LEVATATEBlock::new);
	public static final DeferredBlock<Block> LEVATATEBLOCK = register("levatateblock", LEVATATEBLOCKBlock::new);
	public static final DeferredBlock<Block> AT_MBLOCK = register("at_mblock", ATMblockBlock::new);
	public static final DeferredBlock<Block> CASTLE = register("castle", CastleBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}