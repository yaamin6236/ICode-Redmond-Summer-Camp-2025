package net.mcreator.icodemod.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.state.FelineRenderState;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.OcelotModel;

import net.mcreator.icodemod.entity.DoggyEntity;

public class DoggyRenderer extends MobRenderer<DoggyEntity, FelineRenderState, OcelotModel> {
	private DoggyEntity entity = null;

	public DoggyRenderer(EntityRendererProvider.Context context) {
		super(context, new OcelotModel(context.bakeLayer(ModelLayers.OCELOT)), 0.5f);
	}

	@Override
	public FelineRenderState createRenderState() {
		return new FelineRenderState();
	}

	@Override
	public void extractRenderState(DoggyEntity entity, FelineRenderState state, float partialTicks) {
		super.extractRenderState(entity, state, partialTicks);
		this.entity = entity;
	}

	@Override
	public ResourceLocation getTextureLocation(FelineRenderState state) {
		return ResourceLocation.parse("icode_mod:textures/entities/download_2.png");
	}
}