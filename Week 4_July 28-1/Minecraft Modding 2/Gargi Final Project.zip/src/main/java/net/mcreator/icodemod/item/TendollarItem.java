package net.mcreator.icodemod.item;

import net.minecraft.world.item.Item;

public class TendollarItem extends Item {
	public TendollarItem(Item.Properties properties) {
		super(properties);
	}
}