package net.mcreator.icodemod.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;

import net.mcreator.icodemod.init.IcodeModModMenus;
import net.mcreator.icodemod.init.IcodeModModItems;

public class ATMCODEProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if ((entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof IcodeModModMenus.MenuAccessor _menu0 ? _menu0.getSlots().get(0).getItem() : ItemStack.EMPTY).getItem() == IcodeModModItems.DOLLARBILL.get()) {
			if (getAmountInGUISlot(entity, 0) >= 10) {
				if (entity instanceof Player _player && _player.containerMenu instanceof IcodeModModMenus.MenuAccessor _menu) {
					_menu.getSlots().get(0).remove(10);
					_player.containerMenu.broadcastChanges();
				}
				if (entity instanceof Player _player && _player.containerMenu instanceof IcodeModModMenus.MenuAccessor _menu) {
					ItemStack _setstack = new ItemStack(IcodeModModItems.TENDOLLAR.get()).copy();
					_setstack.setCount(1 + getAmountInGUISlot(entity, 1));
					_menu.getSlots().get(1).set(_setstack);
					_player.containerMenu.broadcastChanges();
				}
			}
		}
		if ((entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof IcodeModModMenus.MenuAccessor _menu6 ? _menu6.getSlots().get(0).getItem() : ItemStack.EMPTY).getItem() == IcodeModModItems.TENDOLLAR.get()) {
			if (getAmountInGUISlot(entity, 0) >= 10) {
				if (entity instanceof Player _player && _player.containerMenu instanceof IcodeModModMenus.MenuAccessor _menu) {
					_menu.getSlots().get(0).remove(10);
					_player.containerMenu.broadcastChanges();
				}
				if (entity instanceof Player _player && _player.containerMenu instanceof IcodeModModMenus.MenuAccessor _menu) {
					ItemStack _setstack = new ItemStack(IcodeModModItems.HUNDREDDOLLAR.get()).copy();
					_setstack.setCount(1 + getAmountInGUISlot(entity, 1));
					_menu.getSlots().get(1).set(_setstack);
					_player.containerMenu.broadcastChanges();
				}
			}
		}
	}

	private static int getAmountInGUISlot(Entity entity, int sltid) {
		if (entity instanceof Player player && player.containerMenu instanceof IcodeModModMenus.MenuAccessor menuAccessor) {
			ItemStack stack = menuAccessor.getSlots().get(sltid).getItem();
			if (stack != null)
				return stack.getCount();
		}
		return 0;
	}
}