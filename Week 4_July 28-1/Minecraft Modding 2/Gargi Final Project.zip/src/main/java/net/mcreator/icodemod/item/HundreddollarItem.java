package net.mcreator.icodemod.item;

import net.minecraft.world.item.Item;

public class HundreddollarItem extends Item {
	public HundreddollarItem(Item.Properties properties) {
		super(properties);
	}
}