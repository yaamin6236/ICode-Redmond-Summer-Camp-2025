/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.icodemod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.icodemod.item.TendollarItem;
import net.mcreator.icodemod.item.PICKAXEItem;
import net.mcreator.icodemod.item.OpswordItem;
import net.mcreator.icodemod.item.HundreddollarItem;
import net.mcreator.icodemod.item.DollarbillItem;
import net.mcreator.icodemod.IcodeModMod;

import java.util.function.Function;

public class IcodeModModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(IcodeModMod.MODID);
	public static final DeferredItem<Item> DOLLARBILL = register("dollarbill", DollarbillItem::new);
	public static final DeferredItem<Item> ROADBLOCK = block(IcodeModModBlocks.ROADBLOCK);
	public static final DeferredItem<Item> TENDOLLAR = register("tendollar", TendollarItem::new);
	public static final DeferredItem<Item> HUNDREDDOLLAR = register("hundreddollar", HundreddollarItem::new);
	public static final DeferredItem<Item> PICKAXE = register("pickaxe", PICKAXEItem::new);
	public static final DeferredItem<Item> LEVATATE = block(IcodeModModBlocks.LEVATATE);
	public static final DeferredItem<Item> LEVATATEBLOCK = block(IcodeModModBlocks.LEVATATEBLOCK);
	public static final DeferredItem<Item> AT_MBLOCK = block(IcodeModModBlocks.AT_MBLOCK);
	public static final DeferredItem<Item> MYMOB_SPAWN_EGG = register("mymob_spawn_egg", properties -> new SpawnEggItem(IcodeModModEntities.MYMOB.get(), properties));
	public static final DeferredItem<Item> CASTLE = block(IcodeModModBlocks.CASTLE);
	public static final DeferredItem<Item> OPSWORD = register("opsword", OpswordItem::new);
	public static final DeferredItem<Item> DOGGY_SPAWN_EGG = register("doggy_spawn_egg", properties -> new SpawnEggItem(IcodeModModEntities.DOGGY.get(), properties));

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}