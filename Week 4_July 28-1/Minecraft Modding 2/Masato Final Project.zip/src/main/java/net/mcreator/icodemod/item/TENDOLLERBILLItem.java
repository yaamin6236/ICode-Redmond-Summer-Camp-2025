package net.mcreator.icodemod.item;

import net.minecraft.world.item.Item;

public class TENDOLLERBILLItem extends Item {
	public TENDOLLERBILLItem(Item.Properties properties) {
		super(properties);
	}
}