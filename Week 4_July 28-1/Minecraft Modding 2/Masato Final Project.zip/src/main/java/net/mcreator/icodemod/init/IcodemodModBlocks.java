/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.icodemod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.icodemod.block.SucearityBlock;
import net.mcreator.icodemod.block.RoadblockBlock;
import net.mcreator.icodemod.block.LevetashonBlock;
import net.mcreator.icodemod.block.Block9Block;
import net.mcreator.icodemod.block.Block4Block;
import net.mcreator.icodemod.block.Block1Block;
import net.mcreator.icodemod.block.Block10Block;
import net.mcreator.icodemod.IcodemodMod;

import java.util.function.Function;

public class IcodemodModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(IcodemodMod.MODID);
	public static final DeferredBlock<Block> ROADBLOCK = register("roadblock", RoadblockBlock::new);
	public static final DeferredBlock<Block> BLOCK_1 = register("block_1", Block1Block::new);
	public static final DeferredBlock<Block> BLOCK_4 = register("block_4", Block4Block::new);
	public static final DeferredBlock<Block> BLOCK_9 = register("block_9", Block9Block::new);
	public static final DeferredBlock<Block> BLOCK_10 = register("block_10", Block10Block::new);
	public static final DeferredBlock<Block> LEVETASHON = register("levetashon", LevetashonBlock::new);
	public static final DeferredBlock<Block> SUCEARITY = register("sucearity", SucearityBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}