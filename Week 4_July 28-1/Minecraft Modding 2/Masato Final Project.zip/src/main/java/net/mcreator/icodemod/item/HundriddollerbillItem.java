package net.mcreator.icodemod.item;

import net.minecraft.world.item.Item;

public class HundriddollerbillItem extends Item {
	public HundriddollerbillItem(Item.Properties properties) {
		super(properties);
	}
}