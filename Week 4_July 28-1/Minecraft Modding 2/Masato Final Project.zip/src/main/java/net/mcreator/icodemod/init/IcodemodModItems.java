/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.icodemod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.icodemod.item.TENDOLLERBILLItem;
import net.mcreator.icodemod.item.SorwdItem;
import net.mcreator.icodemod.item.Sorwd2Item;
import net.mcreator.icodemod.item.PItem;
import net.mcreator.icodemod.item.P1Item;
import net.mcreator.icodemod.item.HundriddollerbillItem;
import net.mcreator.icodemod.item.DollarbillItem;
import net.mcreator.icodemod.IcodemodMod;

import java.util.function.Function;

public class IcodemodModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(IcodemodMod.MODID);
	public static final DeferredItem<Item> DOLLARBILL = register("dollarbill", DollarbillItem::new);
	public static final DeferredItem<Item> ROADBLOCK = block(IcodemodModBlocks.ROADBLOCK);
	public static final DeferredItem<Item> HUNDRIDDOLLERBILL = register("hundriddollerbill", HundriddollerbillItem::new);
	public static final DeferredItem<Item> TENDOLLERBILL = register("tendollerbill", TENDOLLERBILLItem::new);
	public static final DeferredItem<Item> P = register("p", PItem::new);
	public static final DeferredItem<Item> SORWD = register("sorwd", SorwdItem::new);
	public static final DeferredItem<Item> BLOCK_1 = block(IcodemodModBlocks.BLOCK_1);
	public static final DeferredItem<Item> BLOCK_4 = block(IcodemodModBlocks.BLOCK_4);
	public static final DeferredItem<Item> MYMOB_SPAWN_EGG = register("mymob_spawn_egg", properties -> new SpawnEggItem(IcodemodModEntities.MYMOB.get(), properties));
	public static final DeferredItem<Item> BLOCK_9 = block(IcodemodModBlocks.BLOCK_9);
	public static final DeferredItem<Item> BLOCK_10 = block(IcodemodModBlocks.BLOCK_10);
	public static final DeferredItem<Item> LEVETASHON = block(IcodemodModBlocks.LEVETASHON);
	public static final DeferredItem<Item> SORWD_2 = register("sorwd_2", Sorwd2Item::new);
	public static final DeferredItem<Item> SUCEARITY = block(IcodemodModBlocks.SUCEARITY);
	public static final DeferredItem<Item> P_1 = register("p_1", P1Item::new);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}