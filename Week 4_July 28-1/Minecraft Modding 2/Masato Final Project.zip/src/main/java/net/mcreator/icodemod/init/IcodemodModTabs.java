/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.icodemod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.icodemod.IcodemodMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class IcodemodModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, IcodemodMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(IcodemodModItems.DOLLARBILL.get());
			tabData.accept(IcodemodModItems.HUNDRIDDOLLERBILL.get());
			tabData.accept(IcodemodModItems.TENDOLLERBILL.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(IcodemodModBlocks.ROADBLOCK.get().asItem());
			tabData.accept(IcodemodModBlocks.BLOCK_1.get().asItem());
			tabData.accept(IcodemodModBlocks.BLOCK_4.get().asItem());
			tabData.accept(IcodemodModBlocks.BLOCK_10.get().asItem());
			tabData.accept(IcodemodModBlocks.LEVETASHON.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(IcodemodModItems.P.get());
			tabData.accept(IcodemodModItems.SORWD.get());
			tabData.accept(IcodemodModItems.SORWD_2.get());
			tabData.accept(IcodemodModItems.P_1.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(IcodemodModItems.SORWD.get());
			tabData.accept(IcodemodModItems.SORWD_2.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(IcodemodModItems.MYMOB_SPAWN_EGG.get());
		}
	}
}