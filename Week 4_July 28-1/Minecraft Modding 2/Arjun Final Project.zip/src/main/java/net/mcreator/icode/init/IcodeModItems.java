/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.icode.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.icode.item.XpswordItem;
import net.mcreator.icode.item.OnedollarItem;
import net.mcreator.icode.item.FireaxItem;
import net.mcreator.icode.item.DirtpixaxeItem;
import net.mcreator.icode.IcodeMod;

import java.util.function.Function;

public class IcodeModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(IcodeMod.MODID);
	public static final DeferredItem<Item> ONEDOLLAR = register("onedollar", OnedollarItem::new);
	public static final DeferredItem<Item> ROAD = block(IcodeModBlocks.ROAD);
	public static final DeferredItem<Item> VBN = block(IcodeModBlocks.VBN);
	public static final DeferredItem<Item> PIG_SPAWN_EGG = register("pig_spawn_egg", properties -> new SpawnEggItem(IcodeModEntities.PIG.get(), properties));
	public static final DeferredItem<Item> BRAINROT = block(IcodeModBlocks.BRAINROT);
	public static final DeferredItem<Item> XPSWORD = register("xpsword", XpswordItem::new);
	public static final DeferredItem<Item> FIREAX = register("fireax", FireaxItem::new);
	public static final DeferredItem<Item> DIRTPIXAXE = register("dirtpixaxe", DirtpixaxeItem::new);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}