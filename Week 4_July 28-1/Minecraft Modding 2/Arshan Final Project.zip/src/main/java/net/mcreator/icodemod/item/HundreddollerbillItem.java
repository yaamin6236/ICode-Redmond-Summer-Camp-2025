package net.mcreator.icodemod.item;

import net.minecraft.world.item.Item;

public class HundreddollerbillItem extends Item {
	public HundreddollerbillItem(Item.Properties properties) {
		super(properties);
	}
}