/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.icodemod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.icodemod.item.TendollerbillItem;
import net.mcreator.icodemod.item.SowrdItem;
import net.mcreator.icodemod.item.RedItem;
import net.mcreator.icodemod.item.PicaxeItem;
import net.mcreator.icodemod.item.MwaItem;
import net.mcreator.icodemod.item.HundreddollerbillItem;
import net.mcreator.icodemod.item.DollerbillItem;
import net.mcreator.icodemod.ICodeModMod;

import java.util.function.Function;

public class ICodeModModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(ICodeModMod.MODID);
	public static final DeferredItem<Item> DOLLERBILL = register("dollerbill", DollerbillItem::new);
	public static final DeferredItem<Item> ROADBLOCK = block(ICodeModModBlocks.ROADBLOCK);
	public static final DeferredItem<Item> TENDOLLERBILL = register("tendollerbill", TendollerbillItem::new);
	public static final DeferredItem<Item> HUNDREDDOLLERBILL = register("hundreddollerbill", HundreddollerbillItem::new);
	public static final DeferredItem<Item> PICAXE = register("picaxe", PicaxeItem::new);
	public static final DeferredItem<Item> EMMY = block(ICodeModModBlocks.EMMY);
	public static final DeferredItem<Item> ATMBLOCK = block(ICodeModModBlocks.ATMBLOCK);
	public static final DeferredItem<Item> MYMOB_SPAWN_EGG = register("mymob_spawn_egg", properties -> new SpawnEggItem(ICodeModModEntities.MYMOB.get(), properties));
	public static final DeferredItem<Item> SOWRD = register("sowrd", SowrdItem::new);
	public static final DeferredItem<Item> MWA = register("mwa", MwaItem::new);
	public static final DeferredItem<Item> BLOOK = block(ICodeModModBlocks.BLOOK);
	public static final DeferredItem<Item> BLEK = block(ICodeModModBlocks.BLEK);
	public static final DeferredItem<Item> RED = register("red", RedItem::new);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}