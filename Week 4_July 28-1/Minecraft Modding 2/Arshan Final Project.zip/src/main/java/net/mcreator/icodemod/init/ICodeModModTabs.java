/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.icodemod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.icodemod.ICodeModMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class ICodeModModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ICodeModMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(ICodeModModItems.DOLLERBILL.get());
			tabData.accept(ICodeModModItems.TENDOLLERBILL.get());
			tabData.accept(ICodeModModItems.HUNDREDDOLLERBILL.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(ICodeModModBlocks.ROADBLOCK.get().asItem());
			tabData.accept(ICodeModModBlocks.EMMY.get().asItem());
			tabData.accept(ICodeModModBlocks.ATMBLOCK.get().asItem());
			tabData.accept(ICodeModModBlocks.BLOOK.get().asItem());
			tabData.accept(ICodeModModBlocks.BLEK.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(ICodeModModItems.PICAXE.get());
			tabData.accept(ICodeModModItems.SOWRD.get());
			tabData.accept(ICodeModModItems.MWA.get());
			tabData.accept(ICodeModModItems.RED.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(ICodeModModItems.MYMOB_SPAWN_EGG.get());
		}
	}
}