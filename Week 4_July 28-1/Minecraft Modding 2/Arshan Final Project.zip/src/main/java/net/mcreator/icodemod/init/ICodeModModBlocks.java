/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.icodemod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.icodemod.block.RoadblockBlock;
import net.mcreator.icodemod.block.EmmyBlock;
import net.mcreator.icodemod.block.BlookBlock;
import net.mcreator.icodemod.block.BlekBlock;
import net.mcreator.icodemod.block.AtmblockBlock;
import net.mcreator.icodemod.ICodeModMod;

import java.util.function.Function;

public class ICodeModModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(ICodeModMod.MODID);
	public static final DeferredBlock<Block> ROADBLOCK = register("roadblock", RoadblockBlock::new);
	public static final DeferredBlock<Block> EMMY = register("emmy", EmmyBlock::new);
	public static final DeferredBlock<Block> ATMBLOCK = register("atmblock", AtmblockBlock::new);
	public static final DeferredBlock<Block> BLOOK = register("blook", BlookBlock::new);
	public static final DeferredBlock<Block> BLEK = register("blek", BlekBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}