package net.mcreator.icode.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;

import net.mcreator.icode.init.IcodeModMenus;
import net.mcreator.icode.init.IcodeModItems;

public class AtmcodeProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if ((entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof IcodeModMenus.MenuAccessor _menu0 ? _menu0.getSlots().get(0).getItem() : ItemStack.EMPTY).getItem() == IcodeModItems.DOLLARBILL.get()) {
			if (getAmountInGUISlot(entity, 0) >= 10) {
				if (entity instanceof Player _player && _player.containerMenu instanceof IcodeModMenus.MenuAccessor _menu) {
					_menu.getSlots().get(0).remove(10);
					_player.containerMenu.broadcastChanges();
				}
				if (entity instanceof Player _player && _player.containerMenu instanceof IcodeModMenus.MenuAccessor _menu) {
					ItemStack _setstack = new ItemStack(IcodeModItems.TENDOLLA_RBILL.get()).copy();
					_setstack.setCount(1 + getAmountInGUISlot(entity, 1));
					_menu.getSlots().get(1).set(_setstack);
					_player.containerMenu.broadcastChanges();
				}
			}
		}
		if ((entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof IcodeModMenus.MenuAccessor _menu6 ? _menu6.getSlots().get(0).getItem() : ItemStack.EMPTY).getItem() == IcodeModItems.TENDOLLA_RBILL.get()) {
			if (getAmountInGUISlot(entity, 0) >= 10) {
				if (entity instanceof Player _player && _player.containerMenu instanceof IcodeModMenus.MenuAccessor _menu) {
					_menu.getSlots().get(0).remove(10);
					_player.containerMenu.broadcastChanges();
				}
				if (entity instanceof Player _player && _player.containerMenu instanceof IcodeModMenus.MenuAccessor _menu) {
					ItemStack _setstack = new ItemStack(IcodeModItems.HANDREDDOLLARBILL.get()).copy();
					_setstack.setCount(1 + getAmountInGUISlot(entity, 1));
					_menu.getSlots().get(1).set(_setstack);
					_player.containerMenu.broadcastChanges();
				}
			}
		}
	}

	private static int getAmountInGUISlot(Entity entity, int sltid) {
		if (entity instanceof Player player && player.containerMenu instanceof IcodeModMenus.MenuAccessor menuAccessor) {
			ItemStack stack = menuAccessor.getSlots().get(sltid).getItem();
			if (stack != null)
				return stack.getCount();
		}
		return 0;
	}
}