package net.mcreator.icode.item;

import net.minecraft.world.item.Item;

public class HandreddollarbillItem extends Item {
	public HandreddollarbillItem(Item.Properties properties) {
		super(properties);
	}
}