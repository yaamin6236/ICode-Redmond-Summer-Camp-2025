package net.mcreator.icode.item;

import net.minecraft.world.item.Item;

public class TendollaRBILLItem extends Item {
	public TendollaRBILLItem(Item.Properties properties) {
		super(properties);
	}
}