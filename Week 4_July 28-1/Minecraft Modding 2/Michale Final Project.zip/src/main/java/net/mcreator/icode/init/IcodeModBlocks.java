/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.icode.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.icode.block.SuperglasBlock;
import net.mcreator.icode.block.RodeblockBlock;
import net.mcreator.icode.block.RockglicheBlock;
import net.mcreator.icode.block.KjnBlock;
import net.mcreator.icode.block.GligerockBlock;
import net.mcreator.icode.block.BedrockrdeBlock;
import net.mcreator.icode.block.ATMBLOCKBlock;
import net.mcreator.icode.IcodeMod;

import java.util.function.Function;

public class IcodeModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(IcodeMod.MODID);
	public static final DeferredBlock<Block> RODEBLOCK = register("rodeblock", RodeblockBlock::new);
	public static final DeferredBlock<Block> KJN = register("kjn", KjnBlock::new);
	public static final DeferredBlock<Block> SUPERGLAS = register("superglas", SuperglasBlock::new);
	public static final DeferredBlock<Block> BEDROCKRDE = register("bedrockrde", BedrockrdeBlock::new);
	public static final DeferredBlock<Block> ROCKGLICHE = register("rockgliche", RockglicheBlock::new);
	public static final DeferredBlock<Block> GLIGEROCK = register("gligerock", GligerockBlock::new);
	public static final DeferredBlock<Block> ATMBLOCK = register("atmblock", ATMBLOCKBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}