/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.icode.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.icode.IcodeMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class IcodeModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, IcodeMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(IcodeModItems.DOLLARBILL.get());
			tabData.accept(IcodeModItems.TENDOLLA_RBILL.get());
			tabData.accept(IcodeModItems.HANDREDDOLLARBILL.get());
			tabData.accept(IcodeModItems.PECKAXE.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(IcodeModBlocks.RODEBLOCK.get().asItem());
			tabData.accept(IcodeModBlocks.ATMBLOCK.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(IcodeModItems.PECKAXE.get());
			tabData.accept(IcodeModItems.SOWRD.get());
			tabData.accept(IcodeModItems.RUBYSOWRD.get());
			tabData.accept(IcodeModItems.RUBYPICAXE.get());
			tabData.accept(IcodeModItems.RUBYPEAXE.get());
			tabData.accept(IcodeModItems.RUBYAXE.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(IcodeModItems.MYMOB_SPAWN_EGG.get());
		}
	}
}