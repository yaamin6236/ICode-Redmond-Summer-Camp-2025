/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.icode.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.icode.item.TendollaRBILLItem;
import net.mcreator.icode.item.SowrdItem;
import net.mcreator.icode.item.RubysowrdItem;
import net.mcreator.icode.item.RubypicaxeItem;
import net.mcreator.icode.item.RubypeaxeItem;
import net.mcreator.icode.item.RUBYAXEItem;
import net.mcreator.icode.item.PeckaxeItem;
import net.mcreator.icode.item.HandreddollarbillItem;
import net.mcreator.icode.item.DollarbillItem;
import net.mcreator.icode.IcodeMod;

import java.util.function.Function;

public class IcodeModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(IcodeMod.MODID);
	public static final DeferredItem<Item> DOLLARBILL = register("dollarbill", DollarbillItem::new);
	public static final DeferredItem<Item> RODEBLOCK = block(IcodeModBlocks.RODEBLOCK);
	public static final DeferredItem<Item> TENDOLLA_RBILL = register("tendolla_rbill", TendollaRBILLItem::new);
	public static final DeferredItem<Item> HANDREDDOLLARBILL = register("handreddollarbill", HandreddollarbillItem::new);
	public static final DeferredItem<Item> PECKAXE = register("peckaxe", PeckaxeItem::new);
	public static final DeferredItem<Item> KJN = block(IcodeModBlocks.KJN);
	public static final DeferredItem<Item> SUPERGLAS = block(IcodeModBlocks.SUPERGLAS);
	public static final DeferredItem<Item> BEDROCKRDE = block(IcodeModBlocks.BEDROCKRDE);
	public static final DeferredItem<Item> ROCKGLICHE = block(IcodeModBlocks.ROCKGLICHE);
	public static final DeferredItem<Item> GLIGEROCK = block(IcodeModBlocks.GLIGEROCK);
	public static final DeferredItem<Item> ATMBLOCK = block(IcodeModBlocks.ATMBLOCK);
	public static final DeferredItem<Item> MYMOB_SPAWN_EGG = register("mymob_spawn_egg", properties -> new SpawnEggItem(IcodeModEntities.MYMOB.get(), properties));
	public static final DeferredItem<Item> SOWRD = register("sowrd", SowrdItem::new);
	public static final DeferredItem<Item> RUBYSOWRD = register("rubysowrd", RubysowrdItem::new);
	public static final DeferredItem<Item> RUBYPICAXE = register("rubypicaxe", RubypicaxeItem::new);
	public static final DeferredItem<Item> RUBYPEAXE = register("rubypeaxe", RubypeaxeItem::new);
	public static final DeferredItem<Item> RUBYAXE = register("rubyaxe", RUBYAXEItem::new);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}