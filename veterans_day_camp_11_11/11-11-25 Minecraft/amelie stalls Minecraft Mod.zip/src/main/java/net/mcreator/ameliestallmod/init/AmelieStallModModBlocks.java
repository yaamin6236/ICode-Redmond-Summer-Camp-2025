/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.ameliestallmod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.ameliestallmod.block.RainbowBlock;
import net.mcreator.ameliestallmod.block.CoarlyBlock;
import net.mcreator.ameliestallmod.block.BlamzerBlock;
import net.mcreator.ameliestallmod.AmelieStallModMod;

import java.util.function.Function;

public class AmelieStallModModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(AmelieStallModMod.MODID);
	public static final DeferredBlock<Block> COARLY;
	public static final DeferredBlock<Block> RAINBOW;
	public static final DeferredBlock<Block> BLAMZER;
	static {
		COARLY = register("coarly", CoarlyBlock::new);
		RAINBOW = register("rainbow", RainbowBlock::new);
		BLAMZER = register("blamzer", BlamzerBlock::new);
	}

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier);
	}
}