package net.mcreator.ameliestallmod.block;

import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;

public class CoarlyBlock extends Block {
	public CoarlyBlock(BlockBehaviour.Properties properties) {
		super(properties.mapColor(MapColor.GOLD).sound(SoundType.CORAL_BLOCK).strength(1f, 10f));
	}

	@Override
	public int getLightBlock(BlockState state) {
		return 15;
	}
}