package net.mcreator.tutorialmod.block;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.FallingBlock;

import com.mojang.serialization.MapCodec;

public class ArdaniumblokBlock extends FallingBlock {
	public static final MapCodec<ArdaniumblokBlock> CODEC = simpleCodec(ArdaniumblokBlock::new);

	public MapCodec<ArdaniumblokBlock> codec() {
		return CODEC;
	}

	public ArdaniumblokBlock(BlockBehaviour.Properties properties) {
		super(properties.sound(SoundType.GRAVEL).strength(5f, 91f).requiresCorrectToolForDrops().replaceable());
	}

	@Override
	public int getLightBlock(BlockState state) {
		return 15;
	}
}