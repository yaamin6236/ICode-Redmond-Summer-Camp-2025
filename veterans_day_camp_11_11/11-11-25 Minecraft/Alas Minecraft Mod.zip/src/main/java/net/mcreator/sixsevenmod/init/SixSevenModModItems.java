/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.sixsevenmod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.fluids.capability.wrappers.FluidBucketWrapper;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.sixsevenmod.item.WwaatteerrItem;
import net.mcreator.sixsevenmod.SixSevenModMod;

import java.util.function.Function;

public class SixSevenModModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(SixSevenModMod.MODID);
	public static final DeferredItem<Item> FART;
	public static final DeferredItem<Item> POOP;
	public static final DeferredItem<Item> SIX;
	public static final DeferredItem<Item> SEVEN;
	public static final DeferredItem<Item> WWAATTEERR_BUCKET;
	static {
		FART = block(SixSevenModModBlocks.FART, new Item.Properties().stacksTo(99).fireResistant());
		POOP = block(SixSevenModModBlocks.POOP, new Item.Properties().stacksTo(83));
		SIX = block(SixSevenModModBlocks.SIX);
		SEVEN = block(SixSevenModModBlocks.SEVEN);
		WWAATTEERR_BUCKET = register("wwaatteerr_bucket", WwaatteerrItem::new);
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}

	@SubscribeEvent
	public static void registerCapabilities(RegisterCapabilitiesEvent event) {
		event.registerItem(Capabilities.FluidHandler.ITEM, (stack, context) -> new FluidBucketWrapper(stack), WWAATTEERR_BUCKET.get());
	}
}