package net.mcreator.sixsevenmod.fluid;

import org.apache.logging.log4j.core.util.Source;

import net.neoforged.neoforge.fluids.BaseFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;

import net.mcreator.sixsevenmod.init.SixSevenModModItems;
import net.mcreator.sixsevenmod.init.SixSevenModModFluids;
import net.mcreator.sixsevenmod.init.SixSevenModModFluidTypes;
import net.mcreator.sixsevenmod.init.SixSevenModModBlocks;

public abstract class WwaatteerrFluid extends BaseFlowingFluid {
	public static final BaseFlowingFluid.Properties PROPERTIES = new BaseFlowingFluid.Properties(() -> SixSevenModModFluidTypes.WWAATTEERR_TYPE.get(), () -> SixSevenModModFluids.WWAATTEERR.get(), () -> SixSevenModModFluids.FLOWING_WWAATTEERR.get())
			.explosionResistance(100f).tickRate(8).levelDecreasePerBlock(4).bucket(() -> SixSevenModModItems.WWAATTEERR_BUCKET.get()).block(() -> (LiquidBlock) SixSevenModModBlocks.WWAATTEERR.get());

	private WwaatteerrFluid() {
		super(PROPERTIES);
	}

	public static class Source extends WwaatteerrFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends WwaatteerrFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}