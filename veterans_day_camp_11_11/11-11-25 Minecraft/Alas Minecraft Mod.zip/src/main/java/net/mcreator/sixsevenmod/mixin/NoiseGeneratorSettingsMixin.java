package net.mcreator.sixsevenmod.mixin;

import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.level.levelgen.SurfaceRules;
import net.minecraft.world.level.levelgen.NoiseGeneratorSettings;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.core.Holder;

import net.mcreator.sixsevenmod.init.SixSevenModModBiomes;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;

@Mixin(NoiseGeneratorSettings.class)
public class NoiseGeneratorSettingsMixin implements SixSevenModModBiomes.SixSevenModModNoiseGeneratorSettings {
	@Unique
	private Holder<DimensionType> six_seven_mod_dimensionTypeReference;

	@WrapMethod(method = "surfaceRule")
	public SurfaceRules.RuleSource surfaceRule(Operation<SurfaceRules.RuleSource> original) {
		SurfaceRules.RuleSource retval = original.call();
		if (this.six_seven_mod_dimensionTypeReference != null) {
			retval = SixSevenModModBiomes.adaptSurfaceRule(retval, this.six_seven_mod_dimensionTypeReference);
		}
		return retval;
	}

	@Override
	public void setsix_seven_modDimensionTypeReference(Holder<DimensionType> dimensionType) {
		this.six_seven_mod_dimensionTypeReference = dimensionType;
	}
}