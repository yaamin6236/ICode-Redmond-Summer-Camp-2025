package net.mcreator.sixsevenmod.client.fluid;

import net.neoforged.neoforge.client.extensions.common.RegisterClientExtensionsEvent;
import net.neoforged.neoforge.client.extensions.common.IClientFluidTypeExtensions;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.sixsevenmod.init.SixSevenModModFluidTypes;

@EventBusSubscriber(Dist.CLIENT)
public class WwaatteerrFluidExtension {
	@SubscribeEvent
	public static void registerFluidTypeExtensions(RegisterClientExtensionsEvent event) {
		event.registerFluidType(new IClientFluidTypeExtensions() {
			private static final ResourceLocation STILL_TEXTURE = ResourceLocation.parse("six_seven_mod:block/yyyyy");
			private static final ResourceLocation FLOWING_TEXTURE = ResourceLocation.parse("six_seven_mod:block/jlj");

			@Override
			public ResourceLocation getStillTexture() {
				return STILL_TEXTURE;
			}

			@Override
			public ResourceLocation getFlowingTexture() {
				return FLOWING_TEXTURE;
			}
		}, SixSevenModModFluidTypes.WWAATTEERR_TYPE.get());
	}
}