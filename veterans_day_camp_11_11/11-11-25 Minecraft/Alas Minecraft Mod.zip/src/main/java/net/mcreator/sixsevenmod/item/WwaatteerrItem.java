package net.mcreator.sixsevenmod.item;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BucketItem;

import net.mcreator.sixsevenmod.init.SixSevenModModFluids;

public class WwaatteerrItem extends BucketItem {
	public WwaatteerrItem(Item.Properties properties) {
		super(SixSevenModModFluids.WWAATTEERR.get(), properties.craftRemainder(Items.BUCKET).stacksTo(1)

		);
	}
}