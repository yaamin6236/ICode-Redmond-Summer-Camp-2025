/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.sixsevenmod.init;

import net.neoforged.neoforge.registries.NeoForgeRegistries;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.fluids.FluidType;

import net.mcreator.sixsevenmod.fluid.types.WwaatteerrFluidType;
import net.mcreator.sixsevenmod.SixSevenModMod;

public class SixSevenModModFluidTypes {
	public static final DeferredRegister<FluidType> REGISTRY = DeferredRegister.create(NeoForgeRegistries.FLUID_TYPES, SixSevenModMod.MODID);
	public static final DeferredHolder<FluidType, FluidType> WWAATTEERR_TYPE = REGISTRY.register("wwaatteerr", () -> new WwaatteerrFluidType());
}