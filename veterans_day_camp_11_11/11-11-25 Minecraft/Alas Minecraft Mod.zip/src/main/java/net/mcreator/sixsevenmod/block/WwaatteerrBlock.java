package net.mcreator.sixsevenmod.block;

import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.LiquidBlock;

import net.mcreator.sixsevenmod.init.SixSevenModModFluids;

public class WwaatteerrBlock extends LiquidBlock {
	public WwaatteerrBlock(BlockBehaviour.Properties properties) {
		super(SixSevenModModFluids.WWAATTEERR.get(), properties.mapColor(MapColor.WATER).strength(100f).noCollission().noLootTable().liquid().pushReaction(PushReaction.DESTROY).sound(SoundType.EMPTY).replaceable());
	}
}