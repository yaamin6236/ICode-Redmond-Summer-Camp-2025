/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.sixsevenmod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.sixsevenmod.block.WwaatteerrBlock;
import net.mcreator.sixsevenmod.block.SixBlock;
import net.mcreator.sixsevenmod.block.SevenBlock;
import net.mcreator.sixsevenmod.block.PoopBlock;
import net.mcreator.sixsevenmod.block.FartBlock;
import net.mcreator.sixsevenmod.SixSevenModMod;

import java.util.function.Function;

public class SixSevenModModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(SixSevenModMod.MODID);
	public static final DeferredBlock<Block> FART;
	public static final DeferredBlock<Block> POOP;
	public static final DeferredBlock<Block> SIX;
	public static final DeferredBlock<Block> SEVEN;
	public static final DeferredBlock<Block> WWAATTEERR;
	static {
		FART = register("fart", FartBlock::new);
		POOP = register("poop", PoopBlock::new);
		SIX = register("six", SixBlock::new);
		SEVEN = register("seven", SevenBlock::new);
		WWAATTEERR = register("wwaatteerr", WwaatteerrBlock::new);
	}

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier);
	}
}