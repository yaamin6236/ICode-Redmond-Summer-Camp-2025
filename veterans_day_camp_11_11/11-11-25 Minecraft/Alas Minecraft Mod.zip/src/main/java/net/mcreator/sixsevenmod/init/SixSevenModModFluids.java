/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.sixsevenmod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.client.renderer.ItemBlockRenderTypes;

import net.mcreator.sixsevenmod.fluid.WwaatteerrFluid;
import net.mcreator.sixsevenmod.SixSevenModMod;

public class SixSevenModModFluids {
	public static final DeferredRegister<Fluid> REGISTRY = DeferredRegister.create(BuiltInRegistries.FLUID, SixSevenModMod.MODID);
	public static final DeferredHolder<Fluid, FlowingFluid> WWAATTEERR = REGISTRY.register("wwaatteerr", () -> new WwaatteerrFluid.Source());
	public static final DeferredHolder<Fluid, FlowingFluid> FLOWING_WWAATTEERR = REGISTRY.register("flowing_wwaatteerr", () -> new WwaatteerrFluid.Flowing());

	@EventBusSubscriber(Dist.CLIENT)
	public static class FluidsClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			ItemBlockRenderTypes.setRenderLayer(WWAATTEERR.get(), ChunkSectionLayer.TRANSLUCENT);
			ItemBlockRenderTypes.setRenderLayer(FLOWING_WWAATTEERR.get(), ChunkSectionLayer.TRANSLUCENT);
		}
	}
}