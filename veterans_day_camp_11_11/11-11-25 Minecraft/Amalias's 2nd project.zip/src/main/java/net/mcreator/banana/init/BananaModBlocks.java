/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.banana.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.banana.BananaMod;

import java.util.function.Function;

public class BananaModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(BananaMod.MODID);
	public static final DeferredBlock<Block> ARDANIUMBLOCK = register("ardaniumblock", ARDANIUMBLOCKBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}