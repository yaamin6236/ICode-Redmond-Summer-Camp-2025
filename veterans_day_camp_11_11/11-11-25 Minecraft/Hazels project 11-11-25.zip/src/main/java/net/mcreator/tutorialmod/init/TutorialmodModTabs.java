/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.tutorialmod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.tutorialmod.TutorialmodMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class TutorialmodModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, TutorialmodMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(TutorialmodModItems.PINK_HELMET.get());
			tabData.accept(TutorialmodModItems.PINK_CHESTPLATE.get());
			tabData.accept(TutorialmodModItems.PINK_LEGGINGS.get());
			tabData.accept(TutorialmodModItems.PINK_BOOTS.get());
			tabData.accept(TutorialmodModItems.CHEERY_HELMET.get());
			tabData.accept(TutorialmodModItems.CHEERY_CHESTPLATE.get());
			tabData.accept(TutorialmodModItems.CHEERY_LEGGINGS.get());
			tabData.accept(TutorialmodModItems.CHEERY_BOOTS.get());
			tabData.accept(TutorialmodModItems.HAZEL.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(TutorialmodModItems.HAZEL.get());
			tabData.accept(TutorialmodModItems.PPIINNKK.get());
			tabData.accept(TutorialmodModItems.SWORDD.get());
		}
	}
}