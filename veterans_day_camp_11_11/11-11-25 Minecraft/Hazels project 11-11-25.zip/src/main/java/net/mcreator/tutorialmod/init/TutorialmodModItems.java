/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.tutorialmod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.tutorialmod.item.SworddItem;
import net.mcreator.tutorialmod.item.PpiinnkkItem;
import net.mcreator.tutorialmod.item.PinkItem;
import net.mcreator.tutorialmod.item.HazelItem;
import net.mcreator.tutorialmod.item.CheeryItem;
import net.mcreator.tutorialmod.TutorialmodMod;

import java.util.function.Function;

public class TutorialmodModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(TutorialmodMod.MODID);
	public static final DeferredItem<Item> PINK_HELMET = register("pink_helmet", PinkItem.Helmet::new);
	public static final DeferredItem<Item> PINK_CHESTPLATE = register("pink_chestplate", PinkItem.Chestplate::new);
	public static final DeferredItem<Item> PINK_LEGGINGS = register("pink_leggings", PinkItem.Leggings::new);
	public static final DeferredItem<Item> PINK_BOOTS = register("pink_boots", PinkItem.Boots::new);
	public static final DeferredItem<Item> CHEERY_HELMET = register("cheery_helmet", CheeryItem.Helmet::new);
	public static final DeferredItem<Item> CHEERY_CHESTPLATE = register("cheery_chestplate", CheeryItem.Chestplate::new);
	public static final DeferredItem<Item> CHEERY_LEGGINGS = register("cheery_leggings", CheeryItem.Leggings::new);
	public static final DeferredItem<Item> CHEERY_BOOTS = register("cheery_boots", CheeryItem.Boots::new);
	public static final DeferredItem<Item> HAZEL = register("hazel", HazelItem::new);
	public static final DeferredItem<Item> ARDANIUMBLOCK = block(TutorialmodModBlocks.ARDANIUMBLOCK);
	public static final DeferredItem<Item> PPIINNKK = register("ppiinnkk", PpiinnkkItem::new);
	public static final DeferredItem<Item> SWORDD = register("swordd", SworddItem::new);
	public static final DeferredItem<Item> SMILEY = block(TutorialmodModBlocks.SMILEY);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}