package net.mcreator.tutorialmod.mixin;

import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.level.levelgen.SurfaceRules;
import net.minecraft.world.level.levelgen.NoiseGeneratorSettings;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.core.Holder;

import net.mcreator.tutorialmod.init.TutorialmodModBiomes;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;

@Mixin(NoiseGeneratorSettings.class)
public class NoiseGeneratorSettingsMixin implements TutorialmodModBiomes.TutorialmodModNoiseGeneratorSettings {
	@Unique
	private Holder<DimensionType> tutorialmod_dimensionTypeReference;

	@WrapMethod(method = "surfaceRule")
	public SurfaceRules.RuleSource surfaceRule(Operation<SurfaceRules.RuleSource> original) {
		SurfaceRules.RuleSource retval = original.call();
		if (this.tutorialmod_dimensionTypeReference != null) {
			retval = TutorialmodModBiomes.adaptSurfaceRule(retval, this.tutorialmod_dimensionTypeReference);
		}
		return retval;
	}

	@Override
	public void settutorialmodDimensionTypeReference(Holder<DimensionType> dimensionType) {
		this.tutorialmod_dimensionTypeReference = dimensionType;
	}
}