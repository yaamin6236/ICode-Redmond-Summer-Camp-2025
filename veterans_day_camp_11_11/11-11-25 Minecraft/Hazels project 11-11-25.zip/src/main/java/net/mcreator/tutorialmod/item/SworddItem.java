package net.mcreator.tutorialmod.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

public class SworddItem extends SwordItem {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_NETHERITE_TOOL, 100000, 500f, 0, 500, TagKey.create(Registries.ITEM, ResourceLocation.parse("tutorialmod:swordd_repair_items")));

	public SworddItem(Item.Properties properties) {
		super(TOOL_MATERIAL, 499f, 6f, properties);
	}
}