package net.mcreator.tutorialmod.block;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.FallingBlock;

import com.mojang.serialization.MapCodec;

public class ArdaniumblockBlock extends FallingBlock {
	public static final MapCodec<ArdaniumblockBlock> CODEC = simpleCodec(ArdaniumblockBlock::new);

	public MapCodec<ArdaniumblockBlock> codec() {
		return CODEC;
	}

	public ArdaniumblockBlock(BlockBehaviour.Properties properties) {
		super(properties.sound(SoundType.GRAVEL).strength(5f, 30f));
	}

	@Override
	public int getLightBlock(BlockState state) {
		return 15;
	}
}