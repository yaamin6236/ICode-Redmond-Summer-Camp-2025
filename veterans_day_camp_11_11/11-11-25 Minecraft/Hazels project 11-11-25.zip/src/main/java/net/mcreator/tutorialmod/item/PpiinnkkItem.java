package net.mcreator.tutorialmod.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

public class PpiinnkkItem extends PickaxeItem {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_NETHERITE_TOOL, 10000, 500f, 0, 500, TagKey.create(Registries.ITEM, ResourceLocation.parse("tutorialmod:ppiinnkk_repair_items")));

	public PpiinnkkItem(Item.Properties properties) {
		super(TOOL_MATERIAL, 3f, -3f, properties.fireResistant());
	}
}