
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.tutorialmod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.tutorialmod.block.YyyyBlock;
import net.mcreator.tutorialmod.block.YBlock;
import net.mcreator.tutorialmod.block.OuhuoBlock;
import net.mcreator.tutorialmod.block.Hhgfde4yhuBlock;
import net.mcreator.tutorialmod.block.HbBlock;
import net.mcreator.tutorialmod.block.DgBlock;
import net.mcreator.tutorialmod.block.BiBlock;
import net.mcreator.tutorialmod.block.ArdaniumblockBlock;
import net.mcreator.tutorialmod.TutorialmodMod;

import java.util.function.Function;

public class TutorialmodModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(TutorialmodMod.MODID);
	public static final DeferredBlock<Block> ARDANIUMBLOCK = register("ardaniumblock", ArdaniumblockBlock::new);
	public static final DeferredBlock<Block> OUHUO = register("ouhuo", OuhuoBlock::new);
	public static final DeferredBlock<Block> BI = register("bi", BiBlock::new);
	public static final DeferredBlock<Block> YYYY = register("yyyy", YyyyBlock::new);
	public static final DeferredBlock<Block> DG = register("dg", DgBlock::new);
	public static final DeferredBlock<Block> HB = register("hb", HbBlock::new);
	public static final DeferredBlock<Block> Y = register("y", YBlock::new);
	public static final DeferredBlock<Block> HHGFDE_4YHU = register("hhgfde_4yhu", Hhgfde4yhuBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}
