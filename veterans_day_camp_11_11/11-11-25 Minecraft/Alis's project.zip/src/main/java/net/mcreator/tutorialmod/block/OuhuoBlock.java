
package net.mcreator.tutorialmod.block;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.FallingBlock;
import net.minecraft.world.item.context.BlockPlaceContext;

import com.mojang.serialization.MapCodec;

public class OuhuoBlock extends FallingBlock {
	public static final MapCodec<OuhuoBlock> CODEC = simpleCodec(OuhuoBlock::new);

	public MapCodec<OuhuoBlock> codec() {
		return CODEC;
	}

	public OuhuoBlock(BlockBehaviour.Properties properties) {
		super(properties.sound(SoundType.GRAVEL).strength(5f, 30f).noCollission().hasPostProcess((bs, br, bp) -> true).emissiveRendering((bs, br, bp) -> true));
	}

	@Override
	public int getLightBlock(BlockState state) {
		return 15;
	}

	@Override
	public boolean canBeReplaced(BlockState state, BlockPlaceContext context) {
		return context.getItemInHand().getItem() != this.asItem();
	}
}
