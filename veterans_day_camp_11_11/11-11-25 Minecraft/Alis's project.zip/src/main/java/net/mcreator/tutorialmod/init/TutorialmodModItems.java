
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.tutorialmod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.tutorialmod.item.Vy4Item;
import net.mcreator.tutorialmod.item.IhItem;
import net.mcreator.tutorialmod.item.BEDROCKTOOLItem;
import net.mcreator.tutorialmod.TutorialmodMod;

import java.util.function.Function;

public class TutorialmodModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(TutorialmodMod.MODID);
	public static final DeferredItem<Item> BEDROCKTOOL = register("bedrocktool", BEDROCKTOOLItem::new);
	public static final DeferredItem<Item> IH = register("ih", IhItem::new);
	public static final DeferredItem<Item> VY_4 = register("vy_4", Vy4Item::new);
	public static final DeferredItem<Item> ARDANIUMBLOCK = block(TutorialmodModBlocks.ARDANIUMBLOCK);
	public static final DeferredItem<Item> OUHUO = block(TutorialmodModBlocks.OUHUO);
	public static final DeferredItem<Item> BI = block(TutorialmodModBlocks.BI);
	public static final DeferredItem<Item> YYYY = block(TutorialmodModBlocks.YYYY);
	public static final DeferredItem<Item> DG = block(TutorialmodModBlocks.DG);
	public static final DeferredItem<Item> HB = block(TutorialmodModBlocks.HB);
	public static final DeferredItem<Item> Y = block(TutorialmodModBlocks.Y);
	public static final DeferredItem<Item> HHGFDE_4YHU = block(TutorialmodModBlocks.HHGFDE_4YHU);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return REGISTRY.registerItem(block.getId().getPath(), properties -> new BlockItem(block.get(), properties), new Item.Properties());
	}
}
