
package net.mcreator.tutorialmod.block;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.FallingBlock;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.core.BlockPos;

import com.mojang.serialization.MapCodec;

public class ArdaniumblckBlock extends FallingBlock {
	public static final MapCodec<ArdaniumblckBlock> CODEC = simpleCodec(ArdaniumblckBlock::new);

	public MapCodec<ArdaniumblckBlock> codec() {
		return CODEC;
	}

	public ArdaniumblckBlock(BlockBehaviour.Properties ignored) {
		this();
	}

	public ArdaniumblckBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.GRAVEL).strength(5f, 30f).requiresCorrectToolForDrops());
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 15;
	}
}
