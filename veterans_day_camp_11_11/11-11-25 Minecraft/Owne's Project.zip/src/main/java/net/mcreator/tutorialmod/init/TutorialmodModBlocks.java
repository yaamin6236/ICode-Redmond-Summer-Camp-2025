
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.tutorialmod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.core.registries.BuiltInRegistries;

import net.mcreator.tutorialmod.TutorialmodMod;

public class TutorialmodModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(BuiltInRegistries.BLOCK, TutorialmodMod.MODID);
	public static final DeferredHolder<Block, Block> ARDANIUMBLCK = REGISTRY.register("ardaniumblck", () -> new ArdaniumblckBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
