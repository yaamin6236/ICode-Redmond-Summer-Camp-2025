/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.dgftfgrtfrgtfrtfrg.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.dgftfgrtfrgtfrtfrg.block.Iron2Block;
import net.mcreator.dgftfgrtfrgtfrtfrg.DgftfgrtfrgtfrtfrgMod;

import java.util.function.Function;

public class DgftfgrtfrgtfrtfrgModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(DgftfgrtfrgtfrtfrgMod.MODID);
	public static final DeferredBlock<Block> IRON_2;
	static {
		IRON_2 = register("iron_2", Iron2Block::new);
	}

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier);
	}
}