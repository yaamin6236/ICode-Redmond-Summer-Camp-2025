
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.tutorialmod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.bus.api.IEventBus;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraft.core.registries.BuiltInRegistries;

import net.mcreator.tutorialmod.item.RyItem;
import net.mcreator.tutorialmod.TutorialmodMod;

public class TutorialmodModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(BuiltInRegistries.ITEM, TutorialmodMod.MODID);
	public static final DeferredHolder<Item, Item> RY = REGISTRY.register("ry", () -> new RyItem());
	public static final DeferredHolder<Item, Item> TU = block(TutorialmodModBlocks.TU);
	public static final DeferredHolder<Item, Item> J = block(TutorialmodModBlocks.J);
	public static final DeferredHolder<Item, Item> TOM = block(TutorialmodModBlocks.TOM);
	public static final DeferredHolder<Item, Item> H = block(TutorialmodModBlocks.H);
	public static final DeferredHolder<Item, Item> MN = block(TutorialmodModBlocks.MN);
	public static final DeferredHolder<Item, Item> M = block(TutorialmodModBlocks.M);
	public static final DeferredHolder<Item, Item> ARDANIUMBIOCK = block(TutorialmodModBlocks.ARDANIUMBIOCK);

	// Start of user code block custom items
	// End of user code block custom items
	public static void register(IEventBus bus) {
		REGISTRY.register(bus);
	}

	private static DeferredHolder<Item, Item> block(DeferredHolder<Block, Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
