
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.tutorialmod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.core.registries.BuiltInRegistries;

import net.mcreator.tutorialmod.block.TuBlock;
import net.mcreator.tutorialmod.block.TOMBlock;
import net.mcreator.tutorialmod.block.MnBlock;
import net.mcreator.tutorialmod.block.MBlock;
import net.mcreator.tutorialmod.block.JBlock;
import net.mcreator.tutorialmod.block.HBlock;
import net.mcreator.tutorialmod.block.ArdaniumbiockBlock;
import net.mcreator.tutorialmod.TutorialmodMod;

public class TutorialmodModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(BuiltInRegistries.BLOCK, TutorialmodMod.MODID);
	public static final DeferredHolder<Block, Block> TU = REGISTRY.register("tu", () -> new TuBlock());
	public static final DeferredHolder<Block, Block> J = REGISTRY.register("j", () -> new JBlock());
	public static final DeferredHolder<Block, Block> TOM = REGISTRY.register("tom", () -> new TOMBlock());
	public static final DeferredHolder<Block, Block> H = REGISTRY.register("h", () -> new HBlock());
	public static final DeferredHolder<Block, Block> MN = REGISTRY.register("mn", () -> new MnBlock());
	public static final DeferredHolder<Block, Block> M = REGISTRY.register("m", () -> new MBlock());
	public static final DeferredHolder<Block, Block> ARDANIUMBIOCK = REGISTRY.register("ardaniumbiock", () -> new ArdaniumbiockBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
