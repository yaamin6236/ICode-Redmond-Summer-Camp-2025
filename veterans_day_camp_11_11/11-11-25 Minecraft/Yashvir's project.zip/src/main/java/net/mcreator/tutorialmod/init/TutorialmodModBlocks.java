/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.tutorialmod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.tutorialmod.block.MikeBlock;
import net.mcreator.tutorialmod.block.IndiablockBlock;
import net.mcreator.tutorialmod.block.ArdaniumblockBlock;
import net.mcreator.tutorialmod.TutorialmodMod;

import java.util.function.Function;

public class TutorialmodModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(TutorialmodMod.MODID);
	public static final DeferredBlock<Block> ARDANIUMBLOCK = register("ardaniumblock", ArdaniumblockBlock::new);
	public static final DeferredBlock<Block> MIKE = register("mike", MikeBlock::new);
	public static final DeferredBlock<Block> INDIABLOCK = register("indiablock", IndiablockBlock::new);
	public static final DeferredBlock<Block> ARDANIUM = register("ardanium", ArdaniumBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}