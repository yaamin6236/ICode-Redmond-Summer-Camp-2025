/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.gabe.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.gabe.block.WindowBlockBlock;
import net.mcreator.gabe.block.PathwayBlockBlock;
import net.mcreator.gabe.block.CityBlockBlock;
import net.mcreator.gabe.block.ATMBlockBlock;
import net.mcreator.gabe.GabeMod;

import java.util.function.Function;

public class GabeModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(GabeMod.MODID);
	public static final DeferredBlock<Block> PATHWAY_BLOCK = register("pathway_block", PathwayBlockBlock::new);
	public static final DeferredBlock<Block> WINDOW_BLOCK = register("window_block", WindowBlockBlock::new);
	public static final DeferredBlock<Block> CITY_BLOCK = register("city_block", CityBlockBlock::new);
	public static final DeferredBlock<Block> ATM_BLOCK = register("atm_block", ATMBlockBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}