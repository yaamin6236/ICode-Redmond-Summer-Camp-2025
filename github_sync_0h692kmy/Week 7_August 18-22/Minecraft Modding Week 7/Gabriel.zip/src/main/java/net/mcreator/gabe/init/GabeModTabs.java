/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.gabe.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.gabe.GabeMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class GabeModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, GabeMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
			tabData.accept(GabeModItems.DOLLAR_BILL.get());
			tabData.accept(GabeModItems.ONE_HUNDRED_DOLLER_BILL.get());
			tabData.accept(GabeModItems.TEN_DOLLAR_BILL.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(GabeModBlocks.PATHWAY_BLOCK.get().asItem());
			tabData.accept(GabeModBlocks.WINDOW_BLOCK.get().asItem());
			tabData.accept(GabeModBlocks.CITY_BLOCK.get().asItem());
			tabData.accept(GabeModBlocks.ATM_BLOCK.get().asItem());
		}
	}
}