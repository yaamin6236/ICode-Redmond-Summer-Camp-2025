/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.gabe.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.gabe.item.TenDollarBillItem;
import net.mcreator.gabe.item.OneHundredDollerBillItem;
import net.mcreator.gabe.item.DollarBillItem;
import net.mcreator.gabe.GabeMod;

import java.util.function.Function;

public class GabeModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(GabeMod.MODID);
	public static final DeferredItem<Item> DOLLAR_BILL = register("dollar_bill", DollarBillItem::new);
	public static final DeferredItem<Item> PATHWAY_BLOCK = block(GabeModBlocks.PATHWAY_BLOCK);
	public static final DeferredItem<Item> ONE_HUNDRED_DOLLER_BILL = register("one_hundred_doller_bill", OneHundredDollerBillItem::new);
	public static final DeferredItem<Item> TEN_DOLLAR_BILL = register("ten_dollar_bill", TenDollarBillItem::new);
	public static final DeferredItem<Item> WINDOW_BLOCK = block(GabeModBlocks.WINDOW_BLOCK);
	public static final DeferredItem<Item> CITY_BLOCK = block(GabeModBlocks.CITY_BLOCK);
	public static final DeferredItem<Item> ATM_BLOCK = block(GabeModBlocks.ATM_BLOCK);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}