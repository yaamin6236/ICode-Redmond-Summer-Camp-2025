package net.mcreator.gabe.item;

import net.minecraft.world.item.Item;

public class OneHundredDollerBillItem extends Item {
	public OneHundredDollerBillItem(Item.Properties properties) {
		super(properties);
	}
}