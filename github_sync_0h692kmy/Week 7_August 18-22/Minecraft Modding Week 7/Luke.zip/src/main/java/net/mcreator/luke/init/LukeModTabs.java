
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.luke.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.luke.LukeMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class LukeModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, LukeMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(LukeModBlocks.PATHWAY_BLOCK.get().asItem());
			tabData.accept(LukeModBlocks.CITY_BLOCK.get().asItem());
			tabData.accept(LukeModBlocks.WINDOW_BLOCK.get().asItem());
			tabData.accept(LukeModBlocks.HOME_PLATE_BLOCK.get().asItem());
			tabData.accept(LukeModBlocks.ATM_BLOCK.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
			tabData.accept(LukeModItems.DOLLAR_BILL.get());
			tabData.accept(LukeModItems.TEN_DOLLAR_BILL.get());
			tabData.accept(LukeModItems.HUNDRED_DOLLAR.get());
		}
	}
}
