
package net.mcreator.luke.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class HundredDollarItem extends Item {
	public HundredDollarItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
