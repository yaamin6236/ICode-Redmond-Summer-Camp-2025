
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.luke.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.bus.api.IEventBus;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraft.core.registries.BuiltInRegistries;

import net.mcreator.luke.item.TenDollarBillItem;
import net.mcreator.luke.item.HundredDollarItem;
import net.mcreator.luke.item.DollarBillItem;
import net.mcreator.luke.LukeMod;

public class LukeModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(BuiltInRegistries.ITEM, LukeMod.MODID);
	public static final DeferredHolder<Item, Item> DOLLAR_BILL = REGISTRY.register("dollar_bill", () -> new DollarBillItem());
	public static final DeferredHolder<Item, Item> PATHWAY_BLOCK = block(LukeModBlocks.PATHWAY_BLOCK);
	public static final DeferredHolder<Item, Item> TEN_DOLLAR_BILL = REGISTRY.register("ten_dollar_bill", () -> new TenDollarBillItem());
	public static final DeferredHolder<Item, Item> HUNDRED_DOLLAR = REGISTRY.register("hundred_dollar", () -> new HundredDollarItem());
	public static final DeferredHolder<Item, Item> CITY_BLOCK = block(LukeModBlocks.CITY_BLOCK);
	public static final DeferredHolder<Item, Item> WINDOW_BLOCK = block(LukeModBlocks.WINDOW_BLOCK);
	public static final DeferredHolder<Item, Item> HOME_PLATE_BLOCK = block(LukeModBlocks.HOME_PLATE_BLOCK);
	public static final DeferredHolder<Item, Item> ATM_BLOCK = block(LukeModBlocks.ATM_BLOCK);

	// Start of user code block custom items
	// End of user code block custom items
	public static void register(IEventBus bus) {
		REGISTRY.register(bus);
	}

	private static DeferredHolder<Item, Item> block(DeferredHolder<Block, Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
