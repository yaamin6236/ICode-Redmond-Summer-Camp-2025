
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.luke.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.core.registries.BuiltInRegistries;

import net.mcreator.luke.block.WindowBlockBlock;
import net.mcreator.luke.block.PathwayBlockBlock;
import net.mcreator.luke.block.HomePlateBlockBlock;
import net.mcreator.luke.block.CityBlockBlock;
import net.mcreator.luke.block.AtmBlockBlock;
import net.mcreator.luke.LukeMod;

public class LukeModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(BuiltInRegistries.BLOCK, LukeMod.MODID);
	public static final DeferredHolder<Block, Block> PATHWAY_BLOCK = REGISTRY.register("pathway_block", () -> new PathwayBlockBlock());
	public static final DeferredHolder<Block, Block> CITY_BLOCK = REGISTRY.register("city_block", () -> new CityBlockBlock());
	public static final DeferredHolder<Block, Block> WINDOW_BLOCK = REGISTRY.register("window_block", () -> new WindowBlockBlock());
	public static final DeferredHolder<Block, Block> HOME_PLATE_BLOCK = REGISTRY.register("home_plate_block", () -> new HomePlateBlockBlock());
	public static final DeferredHolder<Block, Block> ATM_BLOCK = REGISTRY.register("atm_block", () -> new AtmBlockBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
