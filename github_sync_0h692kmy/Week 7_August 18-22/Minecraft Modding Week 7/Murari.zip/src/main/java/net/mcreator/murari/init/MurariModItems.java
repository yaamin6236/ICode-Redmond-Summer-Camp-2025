
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.murari.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.bus.api.IEventBus;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraft.core.registries.BuiltInRegistries;

import net.mcreator.murari.item.TenDollarbillItem;
import net.mcreator.murari.item.HundredDollarBillItem;
import net.mcreator.murari.item.DollarBillItem;
import net.mcreator.murari.MurariMod;

public class MurariModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(BuiltInRegistries.ITEM, MurariMod.MODID);
	public static final DeferredHolder<Item, Item> DOLLAR_BILL = REGISTRY.register("dollar_bill", () -> new DollarBillItem());
	public static final DeferredHolder<Item, Item> PATHWAY_BLOCK = block(MurariModBlocks.PATHWAY_BLOCK);
	public static final DeferredHolder<Item, Item> CITY_BLOCK = block(MurariModBlocks.CITY_BLOCK);
	public static final DeferredHolder<Item, Item> WINDOW_BLOCK = block(MurariModBlocks.WINDOW_BLOCK);
	public static final DeferredHolder<Item, Item> TEN_DOLLARBILL = REGISTRY.register("ten_dollarbill", () -> new TenDollarbillItem());
	public static final DeferredHolder<Item, Item> HUNDRED_DOLLAR_BILL = REGISTRY.register("hundred_dollar_bill", () -> new HundredDollarBillItem());
	public static final DeferredHolder<Item, Item> ATM_BLOCK = block(MurariModBlocks.ATM_BLOCK);

	// Start of user code block custom items
	// End of user code block custom items
	public static void register(IEventBus bus) {
		REGISTRY.register(bus);
	}

	private static DeferredHolder<Item, Item> block(DeferredHolder<Block, Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
