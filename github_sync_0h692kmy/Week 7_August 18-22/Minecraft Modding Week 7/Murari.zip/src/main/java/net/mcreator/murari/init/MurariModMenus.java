
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.murari.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;

import net.minecraft.world.inventory.MenuType;
import net.minecraft.core.registries.Registries;

import net.mcreator.murari.world.inventory.ATMGUIMenu;
import net.mcreator.murari.MurariMod;

public class MurariModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(Registries.MENU, MurariMod.MODID);
	public static final DeferredHolder<MenuType<?>, MenuType<ATMGUIMenu>> ATMGUI = REGISTRY.register("atmgui", () -> IMenuTypeExtension.create(ATMGUIMenu::new));
}
