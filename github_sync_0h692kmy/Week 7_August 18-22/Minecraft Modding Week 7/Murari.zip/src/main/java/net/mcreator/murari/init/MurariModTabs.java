
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.murari.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.murari.MurariMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class MurariModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MurariMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(MurariModBlocks.PATHWAY_BLOCK.get().asItem());
			tabData.accept(MurariModBlocks.CITY_BLOCK.get().asItem());
			tabData.accept(MurariModBlocks.WINDOW_BLOCK.get().asItem());
			tabData.accept(MurariModBlocks.ATM_BLOCK.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
			tabData.accept(MurariModItems.DOLLAR_BILL.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(MurariModItems.TEN_DOLLARBILL.get());
			tabData.accept(MurariModItems.HUNDRED_DOLLAR_BILL.get());
		}
	}
}
