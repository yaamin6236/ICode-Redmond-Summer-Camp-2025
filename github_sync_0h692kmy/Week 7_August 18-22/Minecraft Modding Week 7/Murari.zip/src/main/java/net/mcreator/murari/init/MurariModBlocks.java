
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.murari.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.core.registries.BuiltInRegistries;

import net.mcreator.murari.block.WindowBlockBlock;
import net.mcreator.murari.block.PathwayBlockBlock;
import net.mcreator.murari.block.CityBlockBlock;
import net.mcreator.murari.block.AtmBlockBlock;
import net.mcreator.murari.MurariMod;

public class MurariModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(BuiltInRegistries.BLOCK, MurariMod.MODID);
	public static final DeferredHolder<Block, Block> PATHWAY_BLOCK = REGISTRY.register("pathway_block", () -> new PathwayBlockBlock());
	public static final DeferredHolder<Block, Block> CITY_BLOCK = REGISTRY.register("city_block", () -> new CityBlockBlock());
	public static final DeferredHolder<Block, Block> WINDOW_BLOCK = REGISTRY.register("window_block", () -> new WindowBlockBlock());
	public static final DeferredHolder<Block, Block> ATM_BLOCK = REGISTRY.register("atm_block", () -> new AtmBlockBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
