/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.vihaan.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;

import net.mcreator.vihaan.entity.ReterEntity;
import net.mcreator.vihaan.entity.FfffffewWE6AEntity;
import net.mcreator.vihaan.entity.EweeeeeeeeeeertfweeeeeeEntity;
import net.mcreator.vihaan.VihaanMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class VihaanModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(Registries.ENTITY_TYPE, VihaanMod.MODID);
	public static final DeferredHolder<EntityType<?>, EntityType<ReterEntity>> RETER = register("reter",
			EntityType.Builder.<ReterEntity>of(ReterEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.sized(1f, 1f));
	public static final DeferredHolder<EntityType<?>, EntityType<EweeeeeeeeeeertfweeeeeeEntity>> EWEEEEEEEEEEERTFWEEEEEE = register("eweeeeeeeeeeertfweeeeee",
			EntityType.Builder.<EweeeeeeeeeeertfweeeeeeEntity>of(EweeeeeeeeeeertfweeeeeeEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.sized(0.6f, 1.95f));
	public static final DeferredHolder<EntityType<?>, EntityType<FfffffewWE6AEntity>> FFFFFFEW_WE_6_A = register("ffffffew_we_6_a",
			EntityType.Builder.<FfffffewWE6AEntity>of(FfffffewWE6AEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.sized(1f, 1f));

	// Start of user code block custom entities
	// End of user code block custom entities
	private static <T extends Entity> DeferredHolder<EntityType<?>, EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(ResourceKey.create(Registries.ENTITY_TYPE, ResourceLocation.fromNamespaceAndPath(VihaanMod.MODID, registryname))));
	}

	@SubscribeEvent
	public static void init(RegisterSpawnPlacementsEvent event) {
		ReterEntity.init(event);
		EweeeeeeeeeeertfweeeeeeEntity.init(event);
		FfffffewWE6AEntity.init(event);
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(RETER.get(), ReterEntity.createAttributes().build());
		event.put(EWEEEEEEEEEEERTFWEEEEEE.get(), EweeeeeeeeeeertfweeeeeeEntity.createAttributes().build());
		event.put(FFFFFFEW_WE_6_A.get(), FfffffewWE6AEntity.createAttributes().build());
	}
}