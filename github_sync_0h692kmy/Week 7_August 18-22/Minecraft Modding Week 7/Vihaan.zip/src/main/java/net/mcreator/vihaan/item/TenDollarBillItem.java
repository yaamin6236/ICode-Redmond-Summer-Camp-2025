package net.mcreator.vihaan.item;

import net.minecraft.world.item.Item;

public class TenDollarBillItem extends Item {
	public TenDollarBillItem(Item.Properties properties) {
		super(properties);
	}
}