/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.vihaan.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.vihaan.client.renderer.ReterRenderer;
import net.mcreator.vihaan.client.renderer.FfffffewWE6ARenderer;
import net.mcreator.vihaan.client.renderer.EweeeeeeeeeeertfweeeeeeRenderer;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class VihaanModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(VihaanModEntities.RETER.get(), ReterRenderer::new);
		event.registerEntityRenderer(VihaanModEntities.EWEEEEEEEEEEERTFWEEEEEE.get(), EweeeeeeeeeeertfweeeeeeRenderer::new);
		event.registerEntityRenderer(VihaanModEntities.FFFFFFEW_WE_6_A.get(), FfffffewWE6ARenderer::new);
	}
}