/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.vihaan.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.vihaan.block.WindowblockBlock;
import net.mcreator.vihaan.block.PathwayBlockBlock;
import net.mcreator.vihaan.block.CityBlockBlock;
import net.mcreator.vihaan.block.AtmBlockBlock;
import net.mcreator.vihaan.VihaanMod;

import java.util.function.Function;

public class VihaanModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(VihaanMod.MODID);
	public static final DeferredBlock<Block> PATHWAY_BLOCK = register("pathway_block", PathwayBlockBlock::new);
	public static final DeferredBlock<Block> CITY_BLOCK = register("city_block", CityBlockBlock::new);
	public static final DeferredBlock<Block> WINDOWBLOCK = register("windowblock", WindowblockBlock::new);
	public static final DeferredBlock<Block> ATM_BLOCK = register("atm_block", AtmBlockBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}