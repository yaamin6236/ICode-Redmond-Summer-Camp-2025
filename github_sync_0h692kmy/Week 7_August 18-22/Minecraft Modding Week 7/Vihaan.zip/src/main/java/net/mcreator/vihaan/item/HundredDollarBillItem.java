package net.mcreator.vihaan.item;

import net.minecraft.world.item.Item;

public class HundredDollarBillItem extends Item {
	public HundredDollarBillItem(Item.Properties properties) {
		super(properties);
	}
}