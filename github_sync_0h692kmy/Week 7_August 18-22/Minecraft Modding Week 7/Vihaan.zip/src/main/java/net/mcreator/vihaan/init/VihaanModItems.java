/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.vihaan.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.vihaan.item.TenDollarBillItem;
import net.mcreator.vihaan.item.HundredDollarBillItem;
import net.mcreator.vihaan.item.DollarBillItem;
import net.mcreator.vihaan.VihaanMod;

import java.util.function.Function;

public class VihaanModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(VihaanMod.MODID);
	public static final DeferredItem<Item> DOLLAR_BILL = register("dollar_bill", DollarBillItem::new);
	public static final DeferredItem<Item> PATHWAY_BLOCK = block(VihaanModBlocks.PATHWAY_BLOCK);
	public static final DeferredItem<Item> TEN_DOLLAR_BILL = register("ten_dollar_bill", TenDollarBillItem::new);
	public static final DeferredItem<Item> HUNDRED_DOLLAR_BILL = register("hundred_dollar_bill", HundredDollarBillItem::new);
	public static final DeferredItem<Item> CITY_BLOCK = block(VihaanModBlocks.CITY_BLOCK);
	public static final DeferredItem<Item> WINDOWBLOCK = block(VihaanModBlocks.WINDOWBLOCK);
	public static final DeferredItem<Item> ATM_BLOCK = block(VihaanModBlocks.ATM_BLOCK);
	public static final DeferredItem<Item> RETER_SPAWN_EGG = register("reter_spawn_egg", properties -> new SpawnEggItem(VihaanModEntities.RETER.get(), properties));
	public static final DeferredItem<Item> EWEEEEEEEEEEERTFWEEEEEE_SPAWN_EGG = register("eweeeeeeeeeeertfweeeeee_spawn_egg", properties -> new SpawnEggItem(VihaanModEntities.EWEEEEEEEEEEERTFWEEEEEE.get(), properties));
	public static final DeferredItem<Item> FFFFFFEW_WE_6_A_SPAWN_EGG = register("ffffffew_we_6_a_spawn_egg", properties -> new SpawnEggItem(VihaanModEntities.FFFFFFEW_WE_6_A.get(), properties));

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}