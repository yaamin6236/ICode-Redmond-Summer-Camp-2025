/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.vihaan.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.vihaan.VihaanMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class VihaanModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, VihaanMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
			tabData.accept(VihaanModItems.DOLLAR_BILL.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(VihaanModBlocks.PATHWAY_BLOCK.get().asItem());
			tabData.accept(VihaanModBlocks.CITY_BLOCK.get().asItem());
			tabData.accept(VihaanModBlocks.WINDOWBLOCK.get().asItem());
			tabData.accept(VihaanModBlocks.ATM_BLOCK.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(VihaanModItems.RETER_SPAWN_EGG.get());
			tabData.accept(VihaanModItems.EWEEEEEEEEEEERTFWEEEEEE_SPAWN_EGG.get());
			tabData.accept(VihaanModItems.FFFFFFEW_WE_6_A_SPAWN_EGG.get());
		}
	}
}