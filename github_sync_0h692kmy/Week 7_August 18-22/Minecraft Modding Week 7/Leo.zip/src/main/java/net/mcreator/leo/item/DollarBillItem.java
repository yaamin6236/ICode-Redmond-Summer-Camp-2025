package net.mcreator.leo.item;

import net.minecraft.world.item.Item;

public class DollarBillItem extends Item {
	public DollarBillItem(Item.Properties properties) {
		super(properties);
	}
}