package net.mcreator.leo.block;

import org.checkerframework.checker.units.qual.s;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

public class PathwayBlockBlock extends Block {
	public PathwayBlockBlock(BlockBehaviour.Properties properties) {
		super(properties.strength(50f, 1f).lightLevel(s -> 5));
	}

	@Override
	public int getLightBlock(BlockState state) {
		return 15;
	}
}