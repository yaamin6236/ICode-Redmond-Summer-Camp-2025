/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.daniel.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.DoubleHighBlockItem;
import net.minecraft.world.item.BlockItem;

import net.mcreator.daniel.item.ThousenddollarbillItem;
import net.mcreator.daniel.item.TendollarbillItem;
import net.mcreator.daniel.item.PpencilItem;
import net.mcreator.daniel.item.OilItem;
import net.mcreator.daniel.item.MouseItem;
import net.mcreator.daniel.item.JobaplicatenItem;
import net.mcreator.daniel.item.HundreddollarbillItem;
import net.mcreator.daniel.item.DollerbillItem;
import net.mcreator.daniel.DanielMod;

import java.util.function.Function;

public class DanielModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(DanielMod.MODID);
	public static final DeferredItem<Item> DOLLERBILL = register("dollerbill", DollerbillItem::new);
	public static final DeferredItem<Item> HUNDREDDOLLARBILL = register("hundreddollarbill", HundreddollarbillItem::new);
	public static final DeferredItem<Item> TENDOLLARBILL = register("tendollarbill", TendollarbillItem::new);
	public static final DeferredItem<Item> WINDOW_BLOCK = block(DanielModBlocks.WINDOW_BLOCK);
	public static final DeferredItem<Item> CITYBLOCK = block(DanielModBlocks.CITYBLOCK);
	public static final DeferredItem<Item> CHELF = block(DanielModBlocks.CHELF);
	public static final DeferredItem<Item> ATM_BLOCK = block(DanielModBlocks.ATM_BLOCK);
	public static final DeferredItem<Item> THOUSENDDOLLARBILL = register("thousenddollarbill", ThousenddollarbillItem::new);
	public static final DeferredItem<Item> OIL_BUCKET = register("oil_bucket", OilItem::new);
	public static final DeferredItem<Item> OFFICEDOOR = doubleBlock(DanielModBlocks.OFFICEDOOR);
	public static final DeferredItem<Item> MOUSE = register("mouse", MouseItem::new);
	public static final DeferredItem<Item> COMPUTER = block(DanielModBlocks.COMPUTER);
	public static final DeferredItem<Item> PPENCIL = register("ppencil", PpencilItem::new);
	public static final DeferredItem<Item> JOBAPLICATEN = register("jobaplicaten", JobaplicatenItem::new);
	public static final DeferredItem<Item> SEET = block(DanielModBlocks.SEET, new Item.Properties().rarity(Rarity.EPIC));
	public static final DeferredItem<Item> RFD_SPAWN_EGG = register("rfd_spawn_egg", properties -> new SpawnEggItem(DanielModEntities.RFD.get(), properties));
	public static final DeferredItem<Item> SUS = block(DanielModBlocks.SUS, new Item.Properties().rarity(Rarity.EPIC));

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}

	private static DeferredItem<Item> doubleBlock(DeferredHolder<Block, Block> block) {
		return doubleBlock(block, new Item.Properties());
	}

	private static DeferredItem<Item> doubleBlock(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new DoubleHighBlockItem(block.get(), prop), properties);
	}
}