/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.daniel.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.daniel.block.WindowBlockBlock;
import net.mcreator.daniel.block.SusBlock;
import net.mcreator.daniel.block.SeetBlock;
import net.mcreator.daniel.block.OilBlock;
import net.mcreator.daniel.block.OfficedoorBlock;
import net.mcreator.daniel.block.ComputerBlock;
import net.mcreator.daniel.block.CityblockBlock;
import net.mcreator.daniel.block.ChelfBlock;
import net.mcreator.daniel.block.AtmBlockBlock;
import net.mcreator.daniel.DanielMod;

import java.util.function.Function;

public class DanielModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(DanielMod.MODID);
	public static final DeferredBlock<Block> WINDOW_BLOCK = register("window_block", WindowBlockBlock::new);
	public static final DeferredBlock<Block> CITYBLOCK = register("cityblock", CityblockBlock::new);
	public static final DeferredBlock<Block> CHELF = register("chelf", ChelfBlock::new);
	public static final DeferredBlock<Block> ATM_BLOCK = register("atm_block", AtmBlockBlock::new);
	public static final DeferredBlock<Block> OIL = register("oil", OilBlock::new);
	public static final DeferredBlock<Block> OFFICEDOOR = register("officedoor", OfficedoorBlock::new);
	public static final DeferredBlock<Block> COMPUTER = register("computer", ComputerBlock::new);
	public static final DeferredBlock<Block> SEET = register("seet", SeetBlock::new);
	public static final DeferredBlock<Block> SUS = register("sus", SusBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}