package net.mcreator.daniel.item;

import net.minecraft.world.item.Item;

public class HundreddollarbillItem extends Item {
	public HundreddollarbillItem(Item.Properties properties) {
		super(properties);
	}
}