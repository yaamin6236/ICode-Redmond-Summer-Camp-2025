package net.mcreator.daniel.item;

import net.minecraft.world.item.Item;

public class DollerbillItem extends Item {
	public DollerbillItem(Item.Properties properties) {
		super(properties);
	}
}