package net.mcreator.daniel.item;

import net.minecraft.world.item.Item;

public class ThousenddollarbillItem extends Item {
	public ThousenddollarbillItem(Item.Properties properties) {
		super(properties);
	}
}