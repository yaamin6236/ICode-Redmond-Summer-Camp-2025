/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.daniel.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.daniel.DanielMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class DanielModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, DanielMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
			tabData.accept(DanielModItems.DOLLERBILL.get());
			tabData.accept(DanielModItems.HUNDREDDOLLARBILL.get());
			tabData.accept(DanielModItems.TENDOLLARBILL.get());
			tabData.accept(DanielModItems.THOUSENDDOLLARBILL.get());
			tabData.accept(DanielModBlocks.SUS.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(DanielModBlocks.WINDOW_BLOCK.get().asItem());
			tabData.accept(DanielModBlocks.CITYBLOCK.get().asItem());
			tabData.accept(DanielModBlocks.CHELF.get().asItem());
			tabData.accept(DanielModBlocks.ATM_BLOCK.get().asItem());
			tabData.accept(DanielModBlocks.OFFICEDOOR.get().asItem());
			tabData.accept(DanielModBlocks.COMPUTER.get().asItem());
			tabData.accept(DanielModBlocks.SEET.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(DanielModItems.OIL_BUCKET.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(DanielModItems.MOUSE.get());
			tabData.accept(DanielModItems.PPENCIL.get());
			tabData.accept(DanielModItems.JOBAPLICATEN.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(DanielModItems.PPENCIL.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(DanielModItems.RFD_SPAWN_EGG.get());
		}
	}
}