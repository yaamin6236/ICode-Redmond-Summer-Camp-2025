package net.mcreator.daniel.item;

import net.minecraft.world.item.Item;

public class TendollarbillItem extends Item {
	public TendollarbillItem(Item.Properties properties) {
		super(properties);
	}
}