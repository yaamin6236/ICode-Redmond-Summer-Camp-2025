package net.mcreator.daniel.item;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BucketItem;

import net.mcreator.daniel.init.DanielModFluids;

public class OilItem extends BucketItem {
	public OilItem(Item.Properties properties) {
		super(DanielModFluids.OIL.get(), properties.craftRemainder(Items.BUCKET).stacksTo(1)

		);
	}
}