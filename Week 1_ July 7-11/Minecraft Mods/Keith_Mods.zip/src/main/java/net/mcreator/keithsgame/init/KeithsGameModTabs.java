/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.keithsgame.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.keithsgame.KeithsGameMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class KeithsGameModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, KeithsGameMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(KeithsGameModItems.ONEDOLLAR.get());
			tabData.accept(KeithsGameModItems.HUNDOOOOOTEXT.get());
			tabData.accept(KeithsGameModItems.TENDOLLER.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(KeithsGameModBlocks.SUPERBLOCK.get().asItem());
			tabData.accept(KeithsGameModItems.TABLE.get());
			tabData.accept(KeithsGameModBlocks.DEB.get().asItem());
			tabData.accept(KeithsGameModBlocks.HUG.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(KeithsGameModItems.SUPERBAZCA.get());
			tabData.accept(KeithsGameModItems.G_8UH.get());
			tabData.accept(KeithsGameModItems.TOOLS.get());
			tabData.accept(KeithsGameModItems.TOLLTEXT.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
			tabData.accept(KeithsGameModBlocks.ATM.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(KeithsGameModItems.NUM_SPAWN_EGG.get());
		}
	}
}