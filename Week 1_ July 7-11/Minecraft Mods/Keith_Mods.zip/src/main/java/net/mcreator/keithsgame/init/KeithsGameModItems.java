/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.keithsgame.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.keithsgame.item.ToolsItem;
import net.mcreator.keithsgame.item.TolltextItem;
import net.mcreator.keithsgame.item.TendollerItem;
import net.mcreator.keithsgame.item.TableItem;
import net.mcreator.keithsgame.item.SuperbazcaItem;
import net.mcreator.keithsgame.item.OnedollarItem;
import net.mcreator.keithsgame.item.HundoooootextItem;
import net.mcreator.keithsgame.item.HatItem;
import net.mcreator.keithsgame.item.G8uhItem;
import net.mcreator.keithsgame.KeithsGameMod;

import java.util.function.Function;

public class KeithsGameModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(KeithsGameMod.MODID);
	public static final DeferredItem<Item> ONEDOLLAR = register("onedollar", OnedollarItem::new);
	public static final DeferredItem<Item> SUPERBLOCK = block(KeithsGameModBlocks.SUPERBLOCK);
	public static final DeferredItem<Item> TABLE = register("table", TableItem::new);
	public static final DeferredItem<Item> HUNDOOOOOTEXT = register("hundoooootext", HundoooootextItem::new);
	public static final DeferredItem<Item> TENDOLLER = register("tendoller", TendollerItem::new);
	public static final DeferredItem<Item> SUPERBAZCA = register("superbazca", SuperbazcaItem::new);
	public static final DeferredItem<Item> ATM = block(KeithsGameModBlocks.ATM);
	public static final DeferredItem<Item> KINGBLOCK = block(KeithsGameModBlocks.KINGBLOCK);
	public static final DeferredItem<Item> NUM_SPAWN_EGG = register("num_spawn_egg", properties -> new SpawnEggItem(KeithsGameModEntities.NUM.get(), properties));
	public static final DeferredItem<Item> HUM = block(KeithsGameModBlocks.HUM);
	public static final DeferredItem<Item> HAT = register("hat", HatItem::new);
	public static final DeferredItem<Item> DEB = block(KeithsGameModBlocks.DEB);
	public static final DeferredItem<Item> HUG = block(KeithsGameModBlocks.HUG);
	public static final DeferredItem<Item> G_8UH = register("g_8uh", G8uhItem::new);
	public static final DeferredItem<Item> TOOLS = register("tools", ToolsItem::new);
	public static final DeferredItem<Item> TOLLTEXT = register("tolltext", TolltextItem::new);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}