/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.keithsgame.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.keithsgame.block.SuperblockBlock;
import net.mcreator.keithsgame.block.KingblockBlock;
import net.mcreator.keithsgame.block.HugBlock;
import net.mcreator.keithsgame.block.HUMBlock;
import net.mcreator.keithsgame.block.G8uhPortalBlock;
import net.mcreator.keithsgame.block.DebBlock;
import net.mcreator.keithsgame.block.BlockseBlock;
import net.mcreator.keithsgame.block.AtmBlock;
import net.mcreator.keithsgame.KeithsGameMod;

import java.util.function.Function;

public class KeithsGameModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(KeithsGameMod.MODID);
	public static final DeferredBlock<Block> SUPERBLOCK = register("superblock", SuperblockBlock::new);
	public static final DeferredBlock<Block> ATM = register("atm", AtmBlock::new);
	public static final DeferredBlock<Block> KINGBLOCK = register("kingblock", KingblockBlock::new);
	public static final DeferredBlock<Block> HUM = register("hum", HUMBlock::new);
	public static final DeferredBlock<Block> DEB = register("deb", DebBlock::new);
	public static final DeferredBlock<Block> HUG = register("hug", HugBlock::new);
	public static final DeferredBlock<Block> G_8UH_PORTAL = register("g_8uh_portal", G8uhPortalBlock::new);
	public static final DeferredBlock<Block> BLOCKSE = register("blockse", BlockseBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}