package net.mcreator.keithsgame.item;

import net.minecraft.world.item.Item;

public class TendollerItem extends Item {
	public TendollerItem(Item.Properties properties) {
		super(properties);
	}
}