package net.mcreator.keithsgame.item;

import net.minecraft.world.item.Item;

public class OnedollarItem extends Item {
	public OnedollarItem(Item.Properties properties) {
		super(properties);
	}
}