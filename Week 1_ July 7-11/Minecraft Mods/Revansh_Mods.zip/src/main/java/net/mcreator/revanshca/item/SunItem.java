package net.mcreator.revanshca.item;

import net.minecraft.world.item.Item;

public class SunItem extends Item {
	public SunItem(Item.Properties properties) {
		super(properties);
	}
}