package net.mcreator.revanshca.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.state.CreeperRenderState;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.CreeperModel;

import net.mcreator.revanshca.entity.UltimatemobEntity;

import com.mojang.blaze3d.vertex.PoseStack;

public class UltimatemobRenderer extends MobRenderer<UltimatemobEntity, CreeperRenderState, CreeperModel> {
	private UltimatemobEntity entity = null;

	public UltimatemobRenderer(EntityRendererProvider.Context context) {
		super(context, new CreeperModel(context.bakeLayer(ModelLayers.CREEPER)), 0.5f);
	}

	@Override
	public CreeperRenderState createRenderState() {
		return new CreeperRenderState();
	}

	@Override
	public void extractRenderState(UltimatemobEntity entity, CreeperRenderState state, float partialTicks) {
		super.extractRenderState(entity, state, partialTicks);
		this.entity = entity;
	}

	@Override
	public ResourceLocation getTextureLocation(CreeperRenderState state) {
		return ResourceLocation.parse("revanshca:textures/entities/image-removebg-preview_1.png");
	}

	@Override
	protected void scale(CreeperRenderState state, PoseStack poseStack) {
		poseStack.scale(entity.getAgeScale(), entity.getAgeScale(), entity.getAgeScale());
	}
}