package net.mcreator.revanshca.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.state.GhastRenderState;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.GhastModel;

import net.mcreator.revanshca.entity.DragonEntity;

public class DragonRenderer extends MobRenderer<DragonEntity, GhastRenderState, GhastModel> {
	private DragonEntity entity = null;

	public DragonRenderer(EntityRendererProvider.Context context) {
		super(context, new GhastModel(context.bakeLayer(ModelLayers.GHAST)), 0.5f);
	}

	@Override
	public GhastRenderState createRenderState() {
		return new GhastRenderState();
	}

	@Override
	public void extractRenderState(DragonEntity entity, GhastRenderState state, float partialTicks) {
		super.extractRenderState(entity, state, partialTicks);
		this.entity = entity;
	}

	@Override
	public ResourceLocation getTextureLocation(GhastRenderState state) {
		return ResourceLocation.parse("revanshca:textures/entities/image-removebg-preview_1.png");
	}
}