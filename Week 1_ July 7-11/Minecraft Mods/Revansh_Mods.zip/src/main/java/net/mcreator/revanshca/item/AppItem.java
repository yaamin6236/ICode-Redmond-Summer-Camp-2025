package net.mcreator.revanshca.item;

import net.minecraft.world.item.Item;

public class AppItem extends Item {
	public AppItem(Item.Properties properties) {
		super(properties);
	}
}