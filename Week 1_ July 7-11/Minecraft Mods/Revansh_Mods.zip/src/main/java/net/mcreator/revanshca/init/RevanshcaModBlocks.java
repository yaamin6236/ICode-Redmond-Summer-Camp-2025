/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.revanshca.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.revanshca.block.SpawnerblockBlock;
import net.mcreator.revanshca.block.SaltBlock;
import net.mcreator.revanshca.block.GabBlock;
import net.mcreator.revanshca.block.CafBlock;
import net.mcreator.revanshca.block.BambamBlock;
import net.mcreator.revanshca.block.AtmBlock;
import net.mcreator.revanshca.RevanshcaMod;

import java.util.function.Function;

public class RevanshcaModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(RevanshcaMod.MODID);
	public static final DeferredBlock<Block> SPAWNERBLOCK = register("spawnerblock", SpawnerblockBlock::new);
	public static final DeferredBlock<Block> CAF = register("caf", CafBlock::new);
	public static final DeferredBlock<Block> ATM = register("atm", AtmBlock::new);
	public static final DeferredBlock<Block> GAB = register("gab", GabBlock::new);
	public static final DeferredBlock<Block> BAMBAM = register("bambam", BambamBlock::new);
	public static final DeferredBlock<Block> SALT = register("salt", SaltBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}