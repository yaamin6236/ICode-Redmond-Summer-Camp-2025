/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.revanshca.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.revanshca.item.TendollarbillItem;
import net.mcreator.revanshca.item.SunItem;
import net.mcreator.revanshca.item.SniperItem;
import net.mcreator.revanshca.item.OnedollarItem;
import net.mcreator.revanshca.item.Kfi04jmgItem;
import net.mcreator.revanshca.item.HundreddollarbillItem;
import net.mcreator.revanshca.item.AppItem;
import net.mcreator.revanshca.RevanshcaMod;

import java.util.function.Function;

public class RevanshcaModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(RevanshcaMod.MODID);
	public static final DeferredItem<Item> ONEDOLLAR = register("onedollar", OnedollarItem::new);
	public static final DeferredItem<Item> SPAWNERBLOCK = block(RevanshcaModBlocks.SPAWNERBLOCK, new Item.Properties().stacksTo(89).fireResistant());
	public static final DeferredItem<Item> CAF = block(RevanshcaModBlocks.CAF, new Item.Properties().fireResistant());
	public static final DeferredItem<Item> TENDOLLARBILL = register("tendollarbill", TendollarbillItem::new);
	public static final DeferredItem<Item> HUNDREDDOLLARBILL = register("hundreddollarbill", HundreddollarbillItem::new);
	public static final DeferredItem<Item> SNIPER = register("sniper", SniperItem::new);
	public static final DeferredItem<Item> ATM = block(RevanshcaModBlocks.ATM);
	public static final DeferredItem<Item> APP = register("app", AppItem::new);
	public static final DeferredItem<Item> GAB = block(RevanshcaModBlocks.GAB, new Item.Properties().fireResistant());
	public static final DeferredItem<Item> ULTIMATEMOB_SPAWN_EGG = register("ultimatemob_spawn_egg", properties -> new SpawnEggItem(RevanshcaModEntities.ULTIMATEMOB.get(), properties));
	public static final DeferredItem<Item> BAMBAM = block(RevanshcaModBlocks.BAMBAM);
	public static final DeferredItem<Item> SUN = register("sun", SunItem::new);
	public static final DeferredItem<Item> DRAGON_SPAWN_EGG = register("dragon_spawn_egg", properties -> new SpawnEggItem(RevanshcaModEntities.DRAGON.get(), properties));
	public static final DeferredItem<Item> SALT = block(RevanshcaModBlocks.SALT);
	public static final DeferredItem<Item> KFI_04JMG = register("kfi_04jmg", Kfi04jmgItem::new);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}