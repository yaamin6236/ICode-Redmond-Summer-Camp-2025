/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.revanshca.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.revanshca.RevanshcaMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class RevanshcaModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, RevanshcaMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(RevanshcaModItems.ONEDOLLAR.get());
			tabData.accept(RevanshcaModItems.TENDOLLARBILL.get());
			tabData.accept(RevanshcaModItems.HUNDREDDOLLARBILL.get());
			tabData.accept(RevanshcaModItems.SUN.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(RevanshcaModBlocks.SPAWNERBLOCK.get().asItem());
			tabData.accept(RevanshcaModBlocks.CAF.get().asItem());
			tabData.accept(RevanshcaModBlocks.GAB.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(RevanshcaModItems.SNIPER.get());
			tabData.accept(RevanshcaModItems.KFI_04JMG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
			tabData.accept(RevanshcaModBlocks.ATM.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(RevanshcaModItems.ULTIMATEMOB_SPAWN_EGG.get());
			tabData.accept(RevanshcaModItems.DRAGON_SPAWN_EGG.get());
		}
	}
}