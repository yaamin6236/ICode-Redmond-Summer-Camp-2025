/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.dylan.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.dylan.item.YakkItem;
import net.mcreator.dylan.item.TendollarItem;
import net.mcreator.dylan.item.T9090Item;
import net.mcreator.dylan.item.SuperemeraldItem;
import net.mcreator.dylan.item.SlimebotsItem;
import net.mcreator.dylan.item.RobyItem;
import net.mcreator.dylan.item.OnehundredbillItem;
import net.mcreator.dylan.item.OnehondredItem;
import net.mcreator.dylan.item.OnedollarItem;
import net.mcreator.dylan.item.ONESAWTHOONDItem;
import net.mcreator.dylan.item.NifItem;
import net.mcreator.dylan.item.MastrswordItem;
import net.mcreator.dylan.item.GonItem;
import net.mcreator.dylan.item.DswordItem;
import net.mcreator.dylan.item.DiscoItem;
import net.mcreator.dylan.item.DimendappolItem;
import net.mcreator.dylan.item.BLOCItem;
import net.mcreator.dylan.item.APPOLItem;
import net.mcreator.dylan.item.A2000Item;
import net.mcreator.dylan.DylanMod;

import java.util.function.Function;

public class DylanModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(DylanMod.MODID);
	public static final DeferredItem<Item> ONEDOLLAR = register("onedollar", OnedollarItem::new);
	public static final DeferredItem<Item> ENDBLOC = block(DylanModBlocks.ENDBLOC);
	public static final DeferredItem<Item> SUPEREMERALD = register("superemerald", SuperemeraldItem::new);
	public static final DeferredItem<Item> FOOL = block(DylanModBlocks.FOOL, new Item.Properties().fireResistant());
	public static final DeferredItem<Item> IDDDOP = block(DylanModBlocks.IDDDOP);
	public static final DeferredItem<Item> YAKK = register("yakk", YakkItem::new);
	public static final DeferredItem<Item> MASTRSWORD = register("mastrsword", MastrswordItem::new);
	public static final DeferredItem<Item> DIMENDAPPOL = register("dimendappol", DimendappolItem::new);
	public static final DeferredItem<Item> DSWORD = register("dsword", DswordItem::new);
	public static final DeferredItem<Item> SLIMEBOTS = register("slimebots", SlimebotsItem::new);
	public static final DeferredItem<Item> A_2000 = register("a_2000", A2000Item::new);
	public static final DeferredItem<Item> APPOL = register("appol", APPOLItem::new);
	public static final DeferredItem<Item> T_9090 = register("t_9090", T9090Item::new);
	public static final DeferredItem<Item> BLOC = register("bloc", BLOCItem::new);
	public static final DeferredItem<Item> TENDOLLAR = register("tendollar", TendollarItem::new);
	public static final DeferredItem<Item> ONEHONDRED = register("onehondred", OnehondredItem::new);
	public static final DeferredItem<Item> ONEHUNDREDBILL = register("onehundredbill", OnehundredbillItem::new);
	public static final DeferredItem<Item> GON = register("gon", GonItem::new);
	public static final DeferredItem<Item> ATM = block(DylanModBlocks.ATM);
	public static final DeferredItem<Item> KILLR_SPAWN_EGG = register("killr_spawn_egg", properties -> new SpawnEggItem(DylanModEntities.KILLR.get(), properties));
	public static final DeferredItem<Item> BLOCKOFAPPOL = block(DylanModBlocks.BLOCKOFAPPOL);
	public static final DeferredItem<Item> NIF = register("nif", NifItem::new);
	public static final DeferredItem<Item> ROBY = register("roby", RobyItem::new);
	public static final DeferredItem<Item> ONESAWTHOOND = register("onesawthoond", ONESAWTHOONDItem::new);
	public static final DeferredItem<Item> DISCO = register("disco", DiscoItem::new);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}