/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.dylan.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.dylan.DylanMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class DylanModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, DylanMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(DylanModItems.ONEDOLLAR.get());
			tabData.accept(DylanModItems.TENDOLLAR.get());
			tabData.accept(DylanModItems.ONEHONDRED.get());
			tabData.accept(DylanModItems.ONEHUNDREDBILL.get());
			tabData.accept(DylanModItems.ROBY.get());
			tabData.accept(DylanModItems.ONESAWTHOOND.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(DylanModBlocks.ENDBLOC.get().asItem());
			tabData.accept(DylanModItems.SUPEREMERALD.get());
			tabData.accept(DylanModBlocks.FOOL.get().asItem());
			tabData.accept(DylanModBlocks.IDDDOP.get().asItem());
			tabData.accept(DylanModItems.YAKK.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(DylanModBlocks.IDDDOP.get().asItem());
			tabData.accept(DylanModItems.YAKK.get());
			tabData.accept(DylanModItems.MASTRSWORD.get());
			tabData.accept(DylanModItems.SLIMEBOTS.get());
			tabData.accept(DylanModItems.ONEHONDRED.get());
			tabData.accept(DylanModItems.ONEHUNDREDBILL.get());
			tabData.accept(DylanModItems.GON.get());
			tabData.accept(DylanModItems.NIF.get());
			tabData.accept(DylanModItems.DISCO.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(DylanModItems.MASTRSWORD.get());
			tabData.accept(DylanModItems.DSWORD.get());
			tabData.accept(DylanModItems.A_2000.get());
			tabData.accept(DylanModItems.T_9090.get());
			tabData.accept(DylanModItems.BLOC.get());
			tabData.accept(DylanModItems.NIF.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.FOOD_AND_DRINKS) {
			tabData.accept(DylanModItems.DIMENDAPPOL.get());
			tabData.accept(DylanModItems.APPOL.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
			tabData.accept(DylanModBlocks.ATM.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(DylanModItems.KILLR_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.COLORED_BLOCKS) {
			tabData.accept(DylanModBlocks.BLOCKOFAPPOL.get().asItem());
		}
	}
}