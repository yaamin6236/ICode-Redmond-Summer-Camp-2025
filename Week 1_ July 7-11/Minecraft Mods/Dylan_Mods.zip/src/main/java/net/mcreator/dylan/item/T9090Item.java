package net.mcreator.dylan.item;

import net.minecraft.world.item.Item;

public class T9090Item extends Item {
	public T9090Item(Item.Properties properties) {
		super(properties);
	}
}