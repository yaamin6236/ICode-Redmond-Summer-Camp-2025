package net.mcreator.dylan.item;

import net.minecraft.world.item.Item;

public class A2000Item extends Item {
	public A2000Item(Item.Properties properties) {
		super(properties);
	}
}