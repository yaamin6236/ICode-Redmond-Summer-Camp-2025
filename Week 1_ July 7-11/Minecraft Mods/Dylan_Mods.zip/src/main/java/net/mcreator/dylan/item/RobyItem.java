package net.mcreator.dylan.item;

import net.minecraft.world.item.Item;

public class RobyItem extends Item {
	public RobyItem(Item.Properties properties) {
		super(properties);
	}
}