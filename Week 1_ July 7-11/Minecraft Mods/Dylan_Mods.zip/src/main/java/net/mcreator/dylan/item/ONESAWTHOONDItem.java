package net.mcreator.dylan.item;

import net.minecraft.world.item.Item;

public class ONESAWTHOONDItem extends Item {
	public ONESAWTHOONDItem(Item.Properties properties) {
		super(properties);
	}
}