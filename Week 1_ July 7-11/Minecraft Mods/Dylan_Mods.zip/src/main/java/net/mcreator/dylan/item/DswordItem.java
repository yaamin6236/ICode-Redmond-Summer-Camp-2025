package net.mcreator.dylan.item;

import net.minecraft.world.item.Item;

public class DswordItem extends Item {
	public DswordItem(Item.Properties properties) {
		super(properties);
	}
}