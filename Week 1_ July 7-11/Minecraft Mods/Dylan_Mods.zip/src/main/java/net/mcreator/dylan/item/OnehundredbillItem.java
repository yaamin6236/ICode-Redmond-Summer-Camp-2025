package net.mcreator.dylan.item;

import net.minecraft.world.item.Item;

public class OnehundredbillItem extends Item {
	public OnehundredbillItem(Item.Properties properties) {
		super(properties);
	}
}