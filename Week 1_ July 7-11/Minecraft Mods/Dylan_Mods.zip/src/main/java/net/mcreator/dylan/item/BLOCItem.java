package net.mcreator.dylan.item;

import net.minecraft.world.item.Item;

public class BLOCItem extends Item {
	public BLOCItem(Item.Properties properties) {
		super(properties);
	}
}