package net.mcreator.dylan.item;

import net.minecraft.world.item.Item;

public class YakkItem extends Item {
	public YakkItem(Item.Properties properties) {
		super(properties);
	}
}