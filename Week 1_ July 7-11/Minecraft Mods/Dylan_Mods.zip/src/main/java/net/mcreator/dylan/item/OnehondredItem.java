package net.mcreator.dylan.item;

import net.minecraft.world.item.Item;

public class OnehondredItem extends Item {
	public OnehondredItem(Item.Properties properties) {
		super(properties);
	}
}