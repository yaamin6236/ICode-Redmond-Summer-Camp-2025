package net.mcreator.dylan.mixin;

import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.level.levelgen.SurfaceRules;
import net.minecraft.world.level.levelgen.NoiseGeneratorSettings;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.core.Holder;

import net.mcreator.dylan.init.DylanModBiomes;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;

@Mixin(NoiseGeneratorSettings.class)
public class NoiseGeneratorSettingsMixin implements DylanModBiomes.DylanModNoiseGeneratorSettings {
	@Unique
	private Holder<DimensionType> dylan__dimensionTypeReference;

	@WrapMethod(method = "surfaceRule")
	public SurfaceRules.RuleSource surfaceRule(Operation<SurfaceRules.RuleSource> original) {
		SurfaceRules.RuleSource retval = original.call();
		if (this.dylan__dimensionTypeReference != null) {
			retval = DylanModBiomes.adaptSurfaceRule(retval, this.dylan__dimensionTypeReference);
		}
		return retval;
	}

	@Override
	public void setdylan_DimensionTypeReference(Holder<DimensionType> dimensionType) {
		this.dylan__dimensionTypeReference = dimensionType;
	}
}