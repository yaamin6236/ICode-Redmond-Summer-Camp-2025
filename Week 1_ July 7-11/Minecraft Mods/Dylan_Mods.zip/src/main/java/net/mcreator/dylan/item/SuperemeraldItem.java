package net.mcreator.dylan.item;

import net.minecraft.world.item.Item;

public class SuperemeraldItem extends Item {
	public SuperemeraldItem(Item.Properties properties) {
		super(properties);
	}
}