package net.mcreator.dylan.item;

import net.minecraft.world.item.Item;

public class APPOLItem extends Item {
	public APPOLItem(Item.Properties properties) {
		super(properties);
	}
}