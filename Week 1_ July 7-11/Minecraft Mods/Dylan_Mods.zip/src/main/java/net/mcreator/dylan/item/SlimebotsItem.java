package net.mcreator.dylan.item;

import net.minecraft.world.item.Item;

public class SlimebotsItem extends Item {
	public SlimebotsItem(Item.Properties properties) {
		super(properties);
	}
}