package net.mcreator.dylan.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

public class NifItem extends PickaxeItem {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_WOODEN_TOOL, 144, 4f, 0, 4, TagKey.create(Registries.ITEM, ResourceLocation.parse("dylan_:nif_repair_items")));

	public NifItem(Item.Properties properties) {
		super(TOOL_MATERIAL, 294f, -1.6f, properties.fireResistant());
	}
}