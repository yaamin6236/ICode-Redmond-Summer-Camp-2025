/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.dylan.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.dylan.block.IdddopBlock;
import net.mcreator.dylan.block.FoolBlock;
import net.mcreator.dylan.block.EndblocBlock;
import net.mcreator.dylan.block.DiscoPortalBlock;
import net.mcreator.dylan.block.BlockofappolBlock;
import net.mcreator.dylan.block.AtmBlock;
import net.mcreator.dylan.DylanMod;

import java.util.function.Function;

public class DylanModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(DylanMod.MODID);
	public static final DeferredBlock<Block> ENDBLOC = register("endbloc", EndblocBlock::new);
	public static final DeferredBlock<Block> FOOL = register("fool", FoolBlock::new);
	public static final DeferredBlock<Block> IDDDOP = register("idddop", IdddopBlock::new);
	public static final DeferredBlock<Block> ATM = register("atm", AtmBlock::new);
	public static final DeferredBlock<Block> BLOCKOFAPPOL = register("blockofappol", BlockofappolBlock::new);
	public static final DeferredBlock<Block> DISCO_PORTAL = register("disco_portal", DiscoPortalBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}