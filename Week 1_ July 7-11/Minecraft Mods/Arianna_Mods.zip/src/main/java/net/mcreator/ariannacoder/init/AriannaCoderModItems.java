/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.ariannacoder.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.ariannacoder.item.TenDollarItem;
import net.mcreator.ariannacoder.item.TeddyBearItem;
import net.mcreator.ariannacoder.item.TeddyBear2Item;
import net.mcreator.ariannacoder.item.RainbowSwordItem;
import net.mcreator.ariannacoder.item.OnedollarItem;
import net.mcreator.ariannacoder.item.HundredDollarBillItem;
import net.mcreator.ariannacoder.item.HundooItem;
import net.mcreator.ariannacoder.AriannaCoderMod;

import java.util.function.Function;

public class AriannaCoderModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(AriannaCoderMod.MODID);
	public static final DeferredItem<Item> ONEDOLLAR = register("onedollar", OnedollarItem::new);
	public static final DeferredItem<Item> VILLAGE_BLOCK = block(AriannaCoderModBlocks.VILLAGE_BLOCK);
	public static final DeferredItem<Item> TEN_DOLLAR = register("ten_dollar", TenDollarItem::new);
	public static final DeferredItem<Item> HUNDRED_DOLLAR_BILL = register("hundred_dollar_bill", HundredDollarBillItem::new);
	public static final DeferredItem<Item> HUNDOO = register("hundoo", HundooItem::new);
	public static final DeferredItem<Item> RAINBOW_SWORD = register("rainbow_sword", RainbowSwordItem::new);
	public static final DeferredItem<Item> MEADOW_PLANT = block(AriannaCoderModBlocks.MEADOW_PLANT);
	public static final DeferredItem<Item> ATM = block(AriannaCoderModBlocks.ATM);
	public static final DeferredItem<Item> LETTER_BLOCK = block(AriannaCoderModBlocks.LETTER_BLOCK);
	public static final DeferredItem<Item> LETTER_BLOCK_B = block(AriannaCoderModBlocks.LETTER_BLOCK_B);
	public static final DeferredItem<Item> BODYGUARD_SPAWN_EGG = register("bodyguard_spawn_egg", properties -> new SpawnEggItem(AriannaCoderModEntities.BODYGUARD.get(), properties));
	public static final DeferredItem<Item> LETTER_BLOCK_C = block(AriannaCoderModBlocks.LETTER_BLOCK_C);
	public static final DeferredItem<Item> TEDDY_BEAR = register("teddy_bear", TeddyBearItem::new);
	public static final DeferredItem<Item> TEDDY_BEAR_2 = register("teddy_bear_2", TeddyBear2Item::new);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}