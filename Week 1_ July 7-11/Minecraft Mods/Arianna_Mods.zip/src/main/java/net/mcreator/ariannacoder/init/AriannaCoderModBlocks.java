/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.ariannacoder.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.ariannacoder.block.VillageBlockBlock;
import net.mcreator.ariannacoder.block.MeadowPlantBlock;
import net.mcreator.ariannacoder.block.LetterBlockCBlock;
import net.mcreator.ariannacoder.block.LetterBlockBlock;
import net.mcreator.ariannacoder.block.LetterBlockBBlock;
import net.mcreator.ariannacoder.block.AtmBlock;
import net.mcreator.ariannacoder.AriannaCoderMod;

import java.util.function.Function;

public class AriannaCoderModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(AriannaCoderMod.MODID);
	public static final DeferredBlock<Block> VILLAGE_BLOCK = register("village_block", VillageBlockBlock::new);
	public static final DeferredBlock<Block> MEADOW_PLANT = register("meadow_plant", MeadowPlantBlock::new);
	public static final DeferredBlock<Block> ATM = register("atm", AtmBlock::new);
	public static final DeferredBlock<Block> LETTER_BLOCK = register("letter_block", LetterBlockBlock::new);
	public static final DeferredBlock<Block> LETTER_BLOCK_B = register("letter_block_b", LetterBlockBBlock::new);
	public static final DeferredBlock<Block> LETTER_BLOCK_C = register("letter_block_c", LetterBlockCBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}