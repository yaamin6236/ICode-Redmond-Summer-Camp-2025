package net.mcreator.ariannacoder.item;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

public class TenDollarItem extends Item {
	public TenDollarItem(Item.Properties properties) {
		super(properties);
	}

	@Override
	public boolean isCorrectToolForDrops(ItemStack itemstack, BlockState state) {
		return true;
	}
}