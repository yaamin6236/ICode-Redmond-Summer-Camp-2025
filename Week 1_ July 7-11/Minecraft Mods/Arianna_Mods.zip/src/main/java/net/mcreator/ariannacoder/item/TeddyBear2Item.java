package net.mcreator.ariannacoder.item;

import net.minecraft.world.item.Item;

public class TeddyBear2Item extends Item {
	public TeddyBear2Item(Item.Properties properties) {
		super(properties);
	}
}