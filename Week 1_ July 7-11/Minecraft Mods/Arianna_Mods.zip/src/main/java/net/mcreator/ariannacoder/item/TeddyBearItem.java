package net.mcreator.ariannacoder.item;

import net.minecraft.world.item.Item;

public class TeddyBearItem extends Item {
	public TeddyBearItem(Item.Properties properties) {
		super(properties);
	}
}