/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.ariannacoder.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.ariannacoder.AriannaCoderMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class AriannaCoderModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, AriannaCoderMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(AriannaCoderModItems.ONEDOLLAR.get());
			tabData.accept(AriannaCoderModItems.TEN_DOLLAR.get());
			tabData.accept(AriannaCoderModItems.HUNDRED_DOLLAR_BILL.get());
			tabData.accept(AriannaCoderModItems.HUNDOO.get());
			tabData.accept(AriannaCoderModItems.TEDDY_BEAR.get());
			tabData.accept(AriannaCoderModItems.TEDDY_BEAR_2.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(AriannaCoderModBlocks.VILLAGE_BLOCK.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(AriannaCoderModItems.RAINBOW_SWORD.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(AriannaCoderModBlocks.MEADOW_PLANT.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
			tabData.accept(AriannaCoderModBlocks.ATM.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.COLORED_BLOCKS) {
			tabData.accept(AriannaCoderModBlocks.LETTER_BLOCK.get().asItem());
			tabData.accept(AriannaCoderModBlocks.LETTER_BLOCK_B.get().asItem());
			tabData.accept(AriannaCoderModBlocks.LETTER_BLOCK_C.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(AriannaCoderModItems.BODYGUARD_SPAWN_EGG.get());
		}
	}
}