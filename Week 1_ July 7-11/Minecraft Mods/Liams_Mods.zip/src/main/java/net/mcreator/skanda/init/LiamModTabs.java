/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.skanda.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.skanda.LiamMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class LiamModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, LiamMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(LiamModItems.ONEDOLLAR.get());
			tabData.accept(LiamModItems.TENDOLLARBILL.get());
			tabData.accept(LiamModItems.HUNDOOO.get());
			tabData.accept(LiamModItems.TENDOOLLAR.get());
			tabData.accept(LiamModItems.HUNDOO.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(LiamModBlocks.SUPABLOCK.get().asItem());
			tabData.accept(LiamModItems.CHEES.get());
			tabData.accept(LiamModItems.TABEL.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(LiamModItems.TENDOLLARBILL.get());
			tabData.accept(LiamModItems.HUNDOOO.get());
			tabData.accept(LiamModItems.TENDOOLLAR.get());
			tabData.accept(LiamModItems.HUNDOO.get());
			tabData.accept(LiamModItems.KATANA.get());
			tabData.accept(LiamModItems.DARCKPLANS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
			tabData.accept(LiamModBlocks.ATM.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(LiamModItems.DRAGEN_SPAWN_EGG.get());
		}
	}
}