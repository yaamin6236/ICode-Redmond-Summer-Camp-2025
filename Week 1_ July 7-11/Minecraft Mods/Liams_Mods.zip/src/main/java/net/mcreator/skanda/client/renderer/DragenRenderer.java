package net.mcreator.skanda.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.state.PiglinRenderState;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.PiglinModel;

import net.mcreator.skanda.entity.DragenEntity;

import com.mojang.blaze3d.vertex.PoseStack;

public class DragenRenderer extends MobRenderer<DragenEntity, PiglinRenderState, PiglinModel> {
	private DragenEntity entity = null;

	public DragenRenderer(EntityRendererProvider.Context context) {
		super(context, new PiglinModel(context.bakeLayer(ModelLayers.PIGLIN)), 1f);
	}

	@Override
	public PiglinRenderState createRenderState() {
		return new PiglinRenderState();
	}

	@Override
	public void extractRenderState(DragenEntity entity, PiglinRenderState state, float partialTicks) {
		super.extractRenderState(entity, state, partialTicks);
		this.entity = entity;
	}

	@Override
	public ResourceLocation getTextureLocation(PiglinRenderState state) {
		return ResourceLocation.parse("liam:textures/entities/image-removebg-preview.png");
	}

	@Override
	protected void scale(PiglinRenderState state, PoseStack poseStack) {
		poseStack.scale(10f, 10f, 10f);
	}
}