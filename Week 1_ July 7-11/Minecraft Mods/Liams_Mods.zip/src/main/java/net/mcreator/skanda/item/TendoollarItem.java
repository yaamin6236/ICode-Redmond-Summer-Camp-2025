package net.mcreator.skanda.item;

import net.minecraft.world.item.Item;

public class TendoollarItem extends Item {
	public TendoollarItem(Item.Properties properties) {
		super(properties);
	}
}