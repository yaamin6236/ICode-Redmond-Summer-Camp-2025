/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.skanda.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.skanda.item.TendoollarItem;
import net.mcreator.skanda.item.TendollarbillItem;
import net.mcreator.skanda.item.TABELItem;
import net.mcreator.skanda.item.OnedollarItem;
import net.mcreator.skanda.item.KatanaItem;
import net.mcreator.skanda.item.HundoooItem;
import net.mcreator.skanda.item.HundooItem;
import net.mcreator.skanda.item.DARCKPLANSItem;
import net.mcreator.skanda.item.CHEESItem;
import net.mcreator.skanda.LiamMod;

import java.util.function.Function;

public class LiamModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(LiamMod.MODID);
	public static final DeferredItem<Item> ONEDOLLAR = register("onedollar", OnedollarItem::new);
	public static final DeferredItem<Item> SUPABLOCK = block(LiamModBlocks.SUPABLOCK);
	public static final DeferredItem<Item> TENDOLLARBILL = register("tendollarbill", TendollarbillItem::new);
	public static final DeferredItem<Item> HUNDOOO = register("hundooo", HundoooItem::new);
	public static final DeferredItem<Item> TENDOOLLAR = register("tendoollar", TendoollarItem::new);
	public static final DeferredItem<Item> HUNDOO = register("hundoo", HundooItem::new);
	public static final DeferredItem<Item> KATANA = register("katana", KatanaItem::new);
	public static final DeferredItem<Item> ATM = block(LiamModBlocks.ATM);
	public static final DeferredItem<Item> DRAGEN_SPAWN_EGG = register("dragen_spawn_egg", properties -> new SpawnEggItem(LiamModEntities.DRAGEN.get(), properties));
	public static final DeferredItem<Item> CHEES = register("chees", CHEESItem::new);
	public static final DeferredItem<Item> TABEL = register("tabel", TABELItem::new);
	public static final DeferredItem<Item> DARCKPLANS = register("darckplans", DARCKPLANSItem::new);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}