/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.skanda.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.skanda.block.SupablockBlock;
import net.mcreator.skanda.block.DARCKPLANSPortalBlock;
import net.mcreator.skanda.block.ATMBlock;
import net.mcreator.skanda.LiamMod;

import java.util.function.Function;

public class LiamModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(LiamMod.MODID);
	public static final DeferredBlock<Block> SUPABLOCK = register("supablock", SupablockBlock::new);
	public static final DeferredBlock<Block> ATM = register("atm", ATMBlock::new);
	public static final DeferredBlock<Block> DARCKPLANS_PORTAL = register("darckplans_portal", DARCKPLANSPortalBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}