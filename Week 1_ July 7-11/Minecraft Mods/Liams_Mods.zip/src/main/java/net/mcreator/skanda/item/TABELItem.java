package net.mcreator.skanda.item;

import net.minecraft.world.item.Item;

public class TABELItem extends Item {
	public TABELItem(Item.Properties properties) {
		super(properties);
	}
}