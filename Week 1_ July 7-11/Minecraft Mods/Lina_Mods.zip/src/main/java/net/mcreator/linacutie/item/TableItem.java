package net.mcreator.linacutie.item;

import net.minecraft.world.item.Item;

public class TableItem extends Item {
	public TableItem(Item.Properties properties) {
		super(properties);
	}
}