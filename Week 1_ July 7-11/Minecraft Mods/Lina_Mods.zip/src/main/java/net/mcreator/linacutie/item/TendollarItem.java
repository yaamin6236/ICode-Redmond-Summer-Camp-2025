package net.mcreator.linacutie.item;

import net.minecraft.world.item.Item;

public class TendollarItem extends Item {
	public TendollarItem(Item.Properties properties) {
		super(properties);
	}
}