package net.mcreator.linacutie.item;

import net.minecraft.world.item.Item;

public class RoesbearItem extends Item {
	public RoesbearItem(Item.Properties properties) {
		super(properties);
	}
}