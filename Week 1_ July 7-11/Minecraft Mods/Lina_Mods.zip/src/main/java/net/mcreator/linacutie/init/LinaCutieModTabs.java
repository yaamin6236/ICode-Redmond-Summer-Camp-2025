/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.linacutie.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.linacutie.LinaCutieMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class LinaCutieModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, LinaCutieMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(LinaCutieModItems.ONEDOLLER.get());
			tabData.accept(LinaCutieModItems.TENDOLLAR.get());
			tabData.accept(LinaCutieModItems.HUNDOO.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(LinaCutieModBlocks.PREATYPURPLEBLOCK.get().asItem());
			tabData.accept(LinaCutieModItems.TABLE.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(LinaCutieModItems.KITTYSWORDD.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
			tabData.accept(LinaCutieModBlocks.PREATYBLOCK.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(LinaCutieModItems.KITTYOWNER_SPAWN_EGG.get());
		}
	}
}