/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.linacutie.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.linacutie.item.TendollarItem;
import net.mcreator.linacutie.item.TableItem;
import net.mcreator.linacutie.item.RoesbearItem;
import net.mcreator.linacutie.item.OnedollerItem;
import net.mcreator.linacutie.item.KittysworddItem;
import net.mcreator.linacutie.item.HundooItem;
import net.mcreator.linacutie.LinaCutieMod;

import java.util.function.Function;

public class LinaCutieModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(LinaCutieMod.MODID);
	public static final DeferredItem<Item> ONEDOLLER = register("onedoller", OnedollerItem::new);
	public static final DeferredItem<Item> PREATYPURPLEBLOCK = block(LinaCutieModBlocks.PREATYPURPLEBLOCK);
	public static final DeferredItem<Item> TABLE = register("table", TableItem::new);
	public static final DeferredItem<Item> TENDOLLAR = register("tendollar", TendollarItem::new);
	public static final DeferredItem<Item> HUNDOO = register("hundoo", HundooItem::new);
	public static final DeferredItem<Item> KITTYSWORDD = register("kittyswordd", KittysworddItem::new);
	public static final DeferredItem<Item> PREATYBLOCK = block(LinaCutieModBlocks.PREATYBLOCK);
	public static final DeferredItem<Item> KITTYBLOCK = block(LinaCutieModBlocks.KITTYBLOCK);
	public static final DeferredItem<Item> KITTYOWNER_SPAWN_EGG = register("kittyowner_spawn_egg", properties -> new SpawnEggItem(LinaCutieModEntities.KITTYOWNER.get(), properties));
	public static final DeferredItem<Item> HEARTBLOCK = block(LinaCutieModBlocks.HEARTBLOCK);
	public static final DeferredItem<Item> ROESBEAR = register("roesbear", RoesbearItem::new);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}