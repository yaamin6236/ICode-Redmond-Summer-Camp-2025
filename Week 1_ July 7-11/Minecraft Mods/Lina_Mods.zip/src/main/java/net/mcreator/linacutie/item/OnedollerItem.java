package net.mcreator.linacutie.item;

import net.minecraft.world.item.Item;

public class OnedollerItem extends Item {
	public OnedollerItem(Item.Properties properties) {
		super(properties);
	}
}