/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.linacutie.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.linacutie.block.PreatypurpleblockBlock;
import net.mcreator.linacutie.block.PreatyblockBlock;
import net.mcreator.linacutie.block.KittyblockBlock;
import net.mcreator.linacutie.block.HeartblockBlock;
import net.mcreator.linacutie.LinaCutieMod;

import java.util.function.Function;

public class LinaCutieModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(LinaCutieMod.MODID);
	public static final DeferredBlock<Block> PREATYPURPLEBLOCK = register("preatypurpleblock", PreatypurpleblockBlock::new);
	public static final DeferredBlock<Block> PREATYBLOCK = register("preatyblock", PreatyblockBlock::new);
	public static final DeferredBlock<Block> KITTYBLOCK = register("kittyblock", KittyblockBlock::new);
	public static final DeferredBlock<Block> HEARTBLOCK = register("heartblock", HeartblockBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}