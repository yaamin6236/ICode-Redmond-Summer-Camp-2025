package net.mcreator.linacutie.item;

import net.minecraft.world.item.Item;

public class HundooItem extends Item {
	public HundooItem(Item.Properties properties) {
		super(properties);
	}
}