/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.deanking.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.deanking.block.ZombieblockBlock;
import net.mcreator.deanking.block.WoodblockBlock;
import net.mcreator.deanking.block.PoperBlock;
import net.mcreator.deanking.block.PaintedwoodBlock;
import net.mcreator.deanking.block.GlowblockBlock;
import net.mcreator.deanking.block.AtmBlock;
import net.mcreator.deanking.DeanKingMod;

import java.util.function.Function;

public class DeanKingModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(DeanKingMod.MODID);
	public static final DeferredBlock<Block> POPER = register("poper", PoperBlock::new);
	public static final DeferredBlock<Block> ATM = register("atm", AtmBlock::new);
	public static final DeferredBlock<Block> GLOWBLOCK = register("glowblock", GlowblockBlock::new);
	public static final DeferredBlock<Block> PAINTEDWOOD = register("paintedwood", PaintedwoodBlock::new);
	public static final DeferredBlock<Block> WOODBLOCK = register("woodblock", WoodblockBlock::new);
	public static final DeferredBlock<Block> ZOMBIEBLOCK = register("zombieblock", ZombieblockBlock::new);
	public static final DeferredBlock<Block> TOPER = register("toper", ToperBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}