package net.mcreator.deanking.block;

import org.checkerframework.checker.units.qual.s;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.FallingBlock;

import com.mojang.serialization.MapCodec;

public class ZombieblockBlock extends FallingBlock {
	public static final MapCodec<ZombieblockBlock> CODEC = simpleCodec(ZombieblockBlock::new);

	public MapCodec<ZombieblockBlock> codec() {
		return CODEC;
	}

	public ZombieblockBlock(BlockBehaviour.Properties properties) {
		super(properties.sound(SoundType.GRAVEL).strength(-1, 3600000).lightLevel(s -> 10).hasPostProcess((bs, br, bp) -> true).emissiveRendering((bs, br, bp) -> true).replaceable());
	}

	@Override
	public int getLightBlock(BlockState state) {
		return 15;
	}
}