package net.mcreator.deanking.item;

import net.minecraft.world.item.Item;

public class PopItem extends Item {
	public PopItem(Item.Properties properties) {
		super(properties);
	}
}