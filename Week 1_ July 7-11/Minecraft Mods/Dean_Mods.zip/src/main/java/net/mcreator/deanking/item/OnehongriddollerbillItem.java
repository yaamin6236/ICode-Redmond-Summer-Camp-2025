package net.mcreator.deanking.item;

import net.minecraft.world.item.Item;

public class OnehongriddollerbillItem extends Item {
	public OnehongriddollerbillItem(Item.Properties properties) {
		super(properties);
	}
}