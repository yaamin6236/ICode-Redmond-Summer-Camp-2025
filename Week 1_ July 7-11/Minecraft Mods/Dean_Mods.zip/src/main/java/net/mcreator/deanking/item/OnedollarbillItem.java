package net.mcreator.deanking.item;

import net.minecraft.world.item.Item;

public class OnedollarbillItem extends Item {
	public OnedollarbillItem(Item.Properties properties) {
		super(properties);
	}
}