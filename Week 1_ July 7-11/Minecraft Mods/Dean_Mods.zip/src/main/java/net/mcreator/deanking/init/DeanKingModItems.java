/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.deanking.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.deanking.item.WoodtableItem;
import net.mcreator.deanking.item.TendollarItem;
import net.mcreator.deanking.item.TableItem;
import net.mcreator.deanking.item.PopItem;
import net.mcreator.deanking.item.OnehundoooItem;
import net.mcreator.deanking.item.OnehongriddollerbillItem;
import net.mcreator.deanking.item.OnedollarbillItem;
import net.mcreator.deanking.item.GunnnItem;
import net.mcreator.deanking.DeanKingMod;

import java.util.function.Function;

public class DeanKingModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(DeanKingMod.MODID);
	public static final DeferredItem<Item> ONEDOLLARBILL = register("onedollarbill", OnedollarbillItem::new);
	public static final DeferredItem<Item> POPER = block(DeanKingModBlocks.POPER);
	public static final DeferredItem<Item> TABLE = register("table", TableItem::new);
	public static final DeferredItem<Item> POP = register("pop", PopItem::new);
	public static final DeferredItem<Item> TENDOLLAR = register("tendollar", TendollarItem::new);
	public static final DeferredItem<Item> ONEHONGRIDDOLLERBILL = register("onehongriddollerbill", OnehongriddollerbillItem::new);
	public static final DeferredItem<Item> ONEHUNDOOO = register("onehundooo", OnehundoooItem::new);
	public static final DeferredItem<Item> GUNNN = register("gunnn", GunnnItem::new);
	public static final DeferredItem<Item> ATM = block(DeanKingModBlocks.ATM);
	public static final DeferredItem<Item> GLOWBLOCK = block(DeanKingModBlocks.GLOWBLOCK, new Item.Properties().fireResistant());
	public static final DeferredItem<Item> ZOMBIEPRISONER_SPAWN_EGG = register("zombieprisoner_spawn_egg", properties -> new SpawnEggItem(DeanKingModEntities.ZOMBIEPRISONER.get(), properties));
	public static final DeferredItem<Item> PAINTEDWOOD = block(DeanKingModBlocks.PAINTEDWOOD);
	public static final DeferredItem<Item> WOODTABLE = register("woodtable", WoodtableItem::new);
	public static final DeferredItem<Item> WOODBLOCK = block(DeanKingModBlocks.WOODBLOCK);
	public static final DeferredItem<Item> ZOMBIEBLOCK = block(DeanKingModBlocks.ZOMBIEBLOCK, new Item.Properties().fireResistant());
	public static final DeferredItem<Item> TOPER = block(DeanKingModBlocks.TOPER);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}