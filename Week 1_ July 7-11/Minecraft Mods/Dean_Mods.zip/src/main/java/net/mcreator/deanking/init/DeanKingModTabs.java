/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.deanking.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.deanking.DeanKingMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class DeanKingModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, DeanKingMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(DeanKingModItems.ONEDOLLARBILL.get());
			tabData.accept(DeanKingModItems.TENDOLLAR.get());
			tabData.accept(DeanKingModItems.ONEHONGRIDDOLLERBILL.get());
			tabData.accept(DeanKingModItems.ONEHUNDOOO.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(DeanKingModBlocks.POPER.get().asItem());
			tabData.accept(DeanKingModBlocks.GLOWBLOCK.get().asItem());
			tabData.accept(DeanKingModBlocks.PAINTEDWOOD.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.FOOD_AND_DRINKS) {
			tabData.accept(DeanKingModItems.POP.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(DeanKingModItems.ONEHUNDOOO.get());
			tabData.accept(DeanKingModItems.GUNNN.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
			tabData.accept(DeanKingModBlocks.ATM.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(DeanKingModItems.ZOMBIEPRISONER_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(DeanKingModBlocks.ZOMBIEBLOCK.get().asItem());
		}
	}
}