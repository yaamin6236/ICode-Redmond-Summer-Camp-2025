package net.mcreator.deanking.item;

import net.minecraft.world.item.Item;

public class WoodtableItem extends Item {
	public WoodtableItem(Item.Properties properties) {
		super(properties);
	}
}