package net.mcreator.deanking.item;

import net.minecraft.world.item.Item;

public class OnehundoooItem extends Item {
	public OnehundoooItem(Item.Properties properties) {
		super(properties);
	}
}