package net.mcreator.simon.item;

import net.minecraft.world.item.Item;

public class OnehunItem extends Item {
	public OnehunItem(Item.Properties properties) {
		super(properties);
	}
}