/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.simon.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.simon.block.SwordblockBlock;
import net.mcreator.simon.block.RedwoodlogBlock;
import net.mcreator.simon.block.RedwoodPlankBlock;
import net.mcreator.simon.block.RabedBlock;
import net.mcreator.simon.block.Hi2000Block;
import net.mcreator.simon.block.Ee3Block;
import net.mcreator.simon.block.DeblockBlock;
import net.mcreator.simon.block.BlocklavaBlock;
import net.mcreator.simon.block.AgoogooBlock;
import net.mcreator.simon.block.ATMBlock;
import net.mcreator.simon.block.A123456Block;
import net.mcreator.simon.SimonMod;

import java.util.function.Function;

public class SimonModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(SimonMod.MODID);
	public static final DeferredBlock<Block> BLOCKLAVA = register("blocklava", BlocklavaBlock::new);
	public static final DeferredBlock<Block> SWORDBLOCK = register("swordblock", SwordblockBlock::new);
	public static final DeferredBlock<Block> AGOOGOO = register("agoogoo", AgoogooBlock::new);
	public static final DeferredBlock<Block> RABED = register("rabed", RabedBlock::new);
	public static final DeferredBlock<Block> EE_3 = register("ee_3", Ee3Block::new);
	public static final DeferredBlock<Block> HI_2000 = register("hi_2000", Hi2000Block::new);
	public static final DeferredBlock<Block> ATM = register("atm", ATMBlock::new);
	public static final DeferredBlock<Block> DEBLOCK = register("deblock", DeblockBlock::new);
	public static final DeferredBlock<Block> A_123456 = register("a_123456", A123456Block::new);
	public static final DeferredBlock<Block> REDWOODLOG = register("redwoodlog", RedwoodlogBlock::new);
	public static final DeferredBlock<Block> REDWOOD_PLANK = register("redwood_plank", RedwoodPlankBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}