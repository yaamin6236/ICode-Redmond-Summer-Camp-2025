package net.mcreator.simon.item;

import net.minecraft.world.item.Item;

public class NoobswordItem extends Item {
	public NoobswordItem(Item.Properties properties) {
		super(properties);
	}
}