/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.simon.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.simon.item.VvstoordItem;
import net.mcreator.simon.item.TendollarItem;
import net.mcreator.simon.item.RedstonesworddItem;
import net.mcreator.simon.item.RedstoneswordItem;
import net.mcreator.simon.item.PhoneItem;
import net.mcreator.simon.item.OnehunItem;
import net.mcreator.simon.item.OnedollarItem;
import net.mcreator.simon.item.NoobswordItem;
import net.mcreator.simon.item.EeeeeoooaaaaaaaaaaaaaaItem;
import net.mcreator.simon.SimonMod;

import java.util.function.Function;

public class SimonModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(SimonMod.MODID);
	public static final DeferredItem<Item> ONEDOLLAR = register("onedollar", OnedollarItem::new);
	public static final DeferredItem<Item> BLOCKLAVA = block(SimonModBlocks.BLOCKLAVA);
	public static final DeferredItem<Item> SWORDBLOCK = block(SimonModBlocks.SWORDBLOCK);
	public static final DeferredItem<Item> AGOOGOO = block(SimonModBlocks.AGOOGOO);
	public static final DeferredItem<Item> TENDOLLAR = register("tendollar", TendollarItem::new);
	public static final DeferredItem<Item> RABED = block(SimonModBlocks.RABED);
	public static final DeferredItem<Item> EEEEEOOOAAAAAAAAAAAAAA = register("eeeeeoooaaaaaaaaaaaaaa", EeeeeoooaaaaaaaaaaaaaaItem::new);
	public static final DeferredItem<Item> EE_3 = block(SimonModBlocks.EE_3);
	public static final DeferredItem<Item> NOOBSWORD = register("noobsword", NoobswordItem::new);
	public static final DeferredItem<Item> VVSTOORD = register("vvstoord", VvstoordItem::new);
	public static final DeferredItem<Item> HI_2000 = block(SimonModBlocks.HI_2000);
	public static final DeferredItem<Item> ONEHUN = register("onehun", OnehunItem::new);
	public static final DeferredItem<Item> REDSTONESWORD = register("redstonesword", RedstoneswordItem::new);
	public static final DeferredItem<Item> REDSTONESWORDD = register("redstoneswordd", RedstonesworddItem::new);
	public static final DeferredItem<Item> ATM = block(SimonModBlocks.ATM);
	public static final DeferredItem<Item> DEBLOCK = block(SimonModBlocks.DEBLOCK);
	public static final DeferredItem<Item> ANOOB_SPAWN_EGG = register("anoob_spawn_egg", properties -> new SpawnEggItem(SimonModEntities.ANOOB.get(), properties));
	public static final DeferredItem<Item> A_123456 = block(SimonModBlocks.A_123456);
	public static final DeferredItem<Item> PHONE = register("phone", PhoneItem::new);
	public static final DeferredItem<Item> REDWOODLOG = block(SimonModBlocks.REDWOODLOG);
	public static final DeferredItem<Item> REDWOOD_PLANK = block(SimonModBlocks.REDWOOD_PLANK);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}