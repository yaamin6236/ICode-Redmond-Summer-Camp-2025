/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.simon.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.simon.SimonMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class SimonModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, SimonMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(SimonModItems.ONEDOLLAR.get());
			tabData.accept(SimonModItems.TENDOLLAR.get());
			tabData.accept(SimonModItems.EEEEEOOOAAAAAAAAAAAAAA.get());
			tabData.accept(SimonModItems.ONEHUN.get());
			tabData.accept(SimonModItems.PHONE.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(SimonModBlocks.BLOCKLAVA.get().asItem());
			tabData.accept(SimonModBlocks.SWORDBLOCK.get().asItem());
			tabData.accept(SimonModBlocks.AGOOGOO.get().asItem());
			tabData.accept(SimonModBlocks.RABED.get().asItem());
			tabData.accept(SimonModBlocks.EE_3.get().asItem());
			tabData.accept(SimonModBlocks.HI_2000.get().asItem());
			tabData.accept(SimonModBlocks.DEBLOCK.get().asItem());
			tabData.accept(SimonModBlocks.REDWOODLOG.get().asItem());
			tabData.accept(SimonModBlocks.REDWOOD_PLANK.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.COLORED_BLOCKS) {
			tabData.accept(SimonModBlocks.EE_3.get().asItem());
			tabData.accept(SimonModBlocks.HI_2000.get().asItem());
			tabData.accept(SimonModBlocks.DEBLOCK.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(SimonModItems.NOOBSWORD.get());
			tabData.accept(SimonModItems.VVSTOORD.get());
			tabData.accept(SimonModItems.REDSTONESWORDD.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(SimonModItems.REDSTONESWORD.get());
			tabData.accept(SimonModItems.REDSTONESWORDD.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
			tabData.accept(SimonModBlocks.ATM.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(SimonModItems.ANOOB_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(SimonModBlocks.A_123456.get().asItem());
			tabData.accept(SimonModBlocks.REDWOODLOG.get().asItem());
		}
	}
}