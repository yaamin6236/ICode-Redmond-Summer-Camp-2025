package net.mcreator.simon.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;

import net.mcreator.simon.init.SimonModMenus;
import net.mcreator.simon.init.SimonModItems;

public class ATMproProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if ((entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof SimonModMenus.MenuAccessor _menu0 ? _menu0.getSlots().get(0).getItem() : ItemStack.EMPTY).getItem() == SimonModItems.ONEDOLLAR.get()) {
			if (getAmountInGUISlot(entity, 0) >= 10) {
				if (entity instanceof Player _player && _player.containerMenu instanceof SimonModMenus.MenuAccessor _menu) {
					_menu.getSlots().get(0).remove(10);
					_player.containerMenu.broadcastChanges();
				}
				if (entity instanceof Player _player && _player.containerMenu instanceof SimonModMenus.MenuAccessor _menu) {
					ItemStack _setstack = new ItemStack(SimonModItems.TENDOLLAR.get()).copy();
					_setstack.setCount(1 + getAmountInGUISlot(entity, 0));
					_menu.getSlots().get(1).set(_setstack);
					_player.containerMenu.broadcastChanges();
				}
			}
		}
		if ((entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof SimonModMenus.MenuAccessor _menu6 ? _menu6.getSlots().get(0).getItem() : ItemStack.EMPTY).getItem() == SimonModItems.TENDOLLAR.get()) {
			if (getAmountInGUISlot(entity, 0) >= 10) {
				if (entity instanceof Player _player && _player.containerMenu instanceof SimonModMenus.MenuAccessor _menu) {
					_menu.getSlots().get(0).remove(10);
					_player.containerMenu.broadcastChanges();
				}
				if (entity instanceof Player _player && _player.containerMenu instanceof SimonModMenus.MenuAccessor _menu) {
					ItemStack _setstack = new ItemStack(SimonModItems.ONEHUN.get()).copy();
					_setstack.setCount(1 + getAmountInGUISlot(entity, 1));
					_menu.getSlots().get(1).set(_setstack);
					_player.containerMenu.broadcastChanges();
				}
			}
		}
	}

	private static int getAmountInGUISlot(Entity entity, int sltid) {
		if (entity instanceof Player player && player.containerMenu instanceof SimonModMenus.MenuAccessor menuAccessor) {
			ItemStack stack = menuAccessor.getSlots().get(sltid).getItem();
			if (stack != null)
				return stack.getCount();
		}
		return 0;
	}
}