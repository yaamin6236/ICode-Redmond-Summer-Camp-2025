package net.mcreator.simon.item;

import net.minecraft.world.item.Item;

public class PhoneItem extends Item {
	public PhoneItem(Item.Properties properties) {
		super(properties);
	}
}