package net.mcreator.simon.item;

import net.minecraft.world.item.Item;

public class EeeeeoooaaaaaaaaaaaaaaItem extends Item {
	public EeeeeoooaaaaaaaaaaaaaaItem(Item.Properties properties) {
		super(properties);
	}
}