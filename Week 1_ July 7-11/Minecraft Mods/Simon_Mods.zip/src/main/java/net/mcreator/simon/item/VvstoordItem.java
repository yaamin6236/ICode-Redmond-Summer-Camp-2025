package net.mcreator.simon.item;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

public class VvstoordItem extends Item {
	public VvstoordItem(Item.Properties properties) {
		super(properties.stacksTo(1).enchantable(10));
	}

	@Override
	public float getDestroySpeed(ItemStack itemstack, BlockState state) {
		return 2f;
	}
}