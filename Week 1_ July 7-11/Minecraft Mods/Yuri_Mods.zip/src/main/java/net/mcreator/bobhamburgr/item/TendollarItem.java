package net.mcreator.bobhamburgr.item;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

public class TendollarItem extends Item {
	public TendollarItem(Item.Properties properties) {
		super(properties);
	}

	@Override
	public ItemStack getCraftingRemainder(ItemStack itemstack) {
		return new ItemStack(this);
	}
}