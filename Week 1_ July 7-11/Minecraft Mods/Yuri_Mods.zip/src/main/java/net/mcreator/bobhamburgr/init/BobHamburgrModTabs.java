/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.bobhamburgr.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.bobhamburgr.BobHamburgrMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class BobHamburgrModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, BobHamburgrMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(BobHamburgrModItems.ONEDOLLAR.get());
			tabData.accept(BobHamburgrModItems.ONEHUNDREDDOLLERS.get());
			tabData.accept(BobHamburgrModItems.TENDOLLAR.get());
			tabData.accept(BobHamburgrModItems.TENO.get());
			tabData.accept(BobHamburgrModItems.HUNDOOO.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(BobHamburgrModBlocks.FUD.get().asItem());
			tabData.accept(BobHamburgrModItems.ONEHUNDREDDOLLERS.get());
			tabData.accept(BobHamburgrModItems.TENDOLLAR.get());
			tabData.accept(BobHamburgrModBlocks.FURRER.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(BobHamburgrModItems.TENO.get());
			tabData.accept(BobHamburgrModItems.HUNDOOO.get());
			tabData.accept(BobHamburgrModItems.FIRE_KATANA.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
			tabData.accept(BobHamburgrModBlocks.ATM.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(BobHamburgrModItems.SCARYO_2000_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(BobHamburgrModBlocks.HUNG.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.FOOD_AND_DRINKS) {
			tabData.accept(BobHamburgrModBlocks.HUNG.get().asItem());
		}
	}
}