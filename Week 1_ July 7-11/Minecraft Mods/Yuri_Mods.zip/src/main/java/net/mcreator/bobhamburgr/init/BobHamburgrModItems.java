/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.bobhamburgr.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.bobhamburgr.item.VerItem;
import net.mcreator.bobhamburgr.item.TenoItem;
import net.mcreator.bobhamburgr.item.TendollarItem;
import net.mcreator.bobhamburgr.item.OnehundreddollersItem;
import net.mcreator.bobhamburgr.item.OnedollarItem;
import net.mcreator.bobhamburgr.item.HundoooItem;
import net.mcreator.bobhamburgr.item.FireKatanaItem;
import net.mcreator.bobhamburgr.BobHamburgrMod;

import java.util.function.Function;

public class BobHamburgrModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(BobHamburgrMod.MODID);
	public static final DeferredItem<Item> ONEDOLLAR = register("onedollar", OnedollarItem::new);
	public static final DeferredItem<Item> FUD = block(BobHamburgrModBlocks.FUD);
	public static final DeferredItem<Item> ONEHUNDREDDOLLERS = register("onehundreddollers", OnehundreddollersItem::new);
	public static final DeferredItem<Item> TENDOLLAR = register("tendollar", TendollarItem::new);
	public static final DeferredItem<Item> TENO = register("teno", TenoItem::new);
	public static final DeferredItem<Item> HUNDOOO = register("hundooo", HundoooItem::new);
	public static final DeferredItem<Item> FIRE_KATANA = register("fire_katana", FireKatanaItem::new);
	public static final DeferredItem<Item> ATM = block(BobHamburgrModBlocks.ATM);
	public static final DeferredItem<Item> SCARYO_2000_SPAWN_EGG = register("scaryo_2000_spawn_egg", properties -> new SpawnEggItem(BobHamburgrModEntities.SCARYO_2000.get(), properties));
	public static final DeferredItem<Item> FURRER = block(BobHamburgrModBlocks.FURRER);
	public static final DeferredItem<Item> VER = register("ver", VerItem::new);
	public static final DeferredItem<Item> HUNG = block(BobHamburgrModBlocks.HUNG);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}