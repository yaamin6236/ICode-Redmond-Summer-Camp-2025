package net.mcreator.bobhamburgr.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.state.PiglinRenderState;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.PiglinModel;

import net.mcreator.bobhamburgr.entity.Scaryo2000Entity;

public class Scaryo2000Renderer extends MobRenderer<Scaryo2000Entity, PiglinRenderState, PiglinModel> {
	private Scaryo2000Entity entity = null;

	public Scaryo2000Renderer(EntityRendererProvider.Context context) {
		super(context, new PiglinModel(context.bakeLayer(ModelLayers.PIGLIN)), 1f);
	}

	@Override
	public PiglinRenderState createRenderState() {
		return new PiglinRenderState();
	}

	@Override
	public void extractRenderState(Scaryo2000Entity entity, PiglinRenderState state, float partialTicks) {
		super.extractRenderState(entity, state, partialTicks);
		this.entity = entity;
	}

	@Override
	public ResourceLocation getTextureLocation(PiglinRenderState state) {
		return ResourceLocation.parse("bob_hamburgr:textures/entities/image-removebg-preview_6.png");
	}
}