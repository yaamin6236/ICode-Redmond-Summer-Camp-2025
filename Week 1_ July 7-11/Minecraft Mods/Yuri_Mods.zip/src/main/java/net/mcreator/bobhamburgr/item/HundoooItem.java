package net.mcreator.bobhamburgr.item;

import net.minecraft.world.item.Item;

public class HundoooItem extends Item {
	public HundoooItem(Item.Properties properties) {
		super(properties);
	}
}