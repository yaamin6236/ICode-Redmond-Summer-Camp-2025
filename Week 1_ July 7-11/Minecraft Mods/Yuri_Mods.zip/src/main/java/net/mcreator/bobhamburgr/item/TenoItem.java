package net.mcreator.bobhamburgr.item;

import net.minecraft.world.item.Item;

public class TenoItem extends Item {
	public TenoItem(Item.Properties properties) {
		super(properties);
	}
}