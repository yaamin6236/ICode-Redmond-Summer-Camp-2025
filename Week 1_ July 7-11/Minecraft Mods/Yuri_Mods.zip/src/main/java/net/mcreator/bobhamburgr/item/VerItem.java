package net.mcreator.bobhamburgr.item;

import net.minecraft.world.item.Item;

public class VerItem extends Item {
	public VerItem(Item.Properties properties) {
		super(properties);
	}
}