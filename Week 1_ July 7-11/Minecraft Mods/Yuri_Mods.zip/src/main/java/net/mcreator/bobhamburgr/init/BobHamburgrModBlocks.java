/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.bobhamburgr.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.bobhamburgr.block.HungBlock;
import net.mcreator.bobhamburgr.block.FurrerBlock;
import net.mcreator.bobhamburgr.block.FUDBlock;
import net.mcreator.bobhamburgr.block.AtmBlock;
import net.mcreator.bobhamburgr.BobHamburgrMod;

import java.util.function.Function;

public class BobHamburgrModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(BobHamburgrMod.MODID);
	public static final DeferredBlock<Block> FUD = register("fud", FUDBlock::new);
	public static final DeferredBlock<Block> ATM = register("atm", AtmBlock::new);
	public static final DeferredBlock<Block> FURRER = register("furrer", FurrerBlock::new);
	public static final DeferredBlock<Block> HUNG = register("hung", HungBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}