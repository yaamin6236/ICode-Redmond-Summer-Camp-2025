package net.mcreator.bobhamburgr.block;

import org.checkerframework.checker.units.qual.s;

import net.neoforged.neoforge.common.util.DeferredSoundType;

import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.FlowerBlock;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

public class HungBlock extends FlowerBlock {
	public HungBlock(BlockBehaviour.Properties properties) {
		super(MobEffects.MOVEMENT_SPEED, 100, properties.mapColor(MapColor.PLANT)
				.sound(new DeferredSoundType(1.0f, 1.0f, () -> BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("ambient.soul_sand_valley.loop")),
						() -> BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("ambient.underwater.loop.additions.ultra_rare")), () -> BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("ambient.crimson_forest.additions")),
						() -> BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("block.anvil.land")), () -> BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("block.bamboo_sapling.break"))))
				.instabreak().lightLevel(s -> 15).noCollission().offsetType(BlockBehaviour.OffsetType.XZ).pushReaction(PushReaction.DESTROY));
	}

	@Override
	public int getFlammability(BlockState state, BlockGetter world, BlockPos pos, Direction face) {
		return 100;
	}

	@Override
	public int getFireSpreadSpeed(BlockState state, BlockGetter world, BlockPos pos, Direction face) {
		return 60;
	}
}